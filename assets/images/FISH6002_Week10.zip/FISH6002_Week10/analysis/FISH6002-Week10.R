# Week 10: Figures for Sci Comm - Animations
# FISH 6002
# 

# Started Nov 15, 2018
# Updated Nov 8 2019

library(tidyverse)
library(ggrepel)
library(lubridate)
library(gganimate)

# Documentation for magick: https://cloud.r-project.org/web/packages/magick/vignettes/intro.html
# For av: https://ropensci.org/technotes/2018/10/06/av-release/
# For ggrepel: https://slowkow.com/ggrepel/
# For gganimate: http://www.ggplot2-exts.org/gganimate.html

# Today's data from: http://derekogle.com/fishR/data/data-html/CiscoTL.html


##########################
# Load data              #
##########################

Cisco <- read.csv("./data/CiscoTL.csv")

# lakeid: Lake name (all TR=Trout Lake)
# year4: Year of capture
# sampledate: Date of capture
# gearid: Capture gear type
# spname: Species name (all CISCO)
# length: Total length (nearest mm) at capture
# weight: Weight (nearest 0.1 or 1 g) at capture
# sex: Sex (F=Female, I=Immature, M=Male)

##################################
# STEP 1: Did it load correctly? #
##################################

head(Cisco) #No extra columns
tail(Cisco) #No extra rows, but there are missing sex and weight values

#################################
# STEP 2: Check data types      #
#################################

sapply(Cisco, class)
# there is a date but it's recorded as a factor
# All others look good

# Turn date into Lubridate

head(Cisco$sampledate)

Cisco$sampledate <- mdy(Cisco$sampledate)

head(Cisco$sampledate) #good
sapply(Cisco, class) #wonderful

##################################################
# STEP 3: Check for missing or impossible values #
##################################################
# Check:
# year4: Year of capture
# sampledate: Date of capture
# length: Total length (nearest mm) at capture
# weight: Weight (nearest 0.1 or 1 g) at capture

plot(Cisco$year4)
range(Cisco$year4) #good

plot(Cisco$sampledate) # good
# Note that dots are still in mostly straight lines
# looks like this survey was done over very brief time periods over
# a number of years

range(Cisco$sampledate) # good

plot(Cisco$length) # There are some large values
range(Cisco$length)
# Hmm: Check Fishbase: http://www.fishbase.org/summary/Coregonus-artedi.html

# Max length ever recorded is 57.0 cm (570 mm)
# Is 395 reasonable? (I think so)

plot(Cisco$weight)
range(Cisco$weight) #oops some missing.
range(Cisco$weight, na.rm=TRUE) # Are values at extremes trustworthy?
# Low seems very low

# Check high values of length:
Cisco %>% filter(length>300) # The big fish all have reasonably big weights
# I'm satisfied

# Check low values of weight
Cisco %>% filter(weight < 1) # There is one fish with a weight of 0.38

Cisco %>% filter(weight < 4) # Hmm... other fish in the 70-80 mm range
# have weights > 2 g.

# I think 0.38 is an impossible value, in context.
# Decision time: Do we - 
# 1. Contact the author and find original data
# 2. Assume there was a predictable typo - e.g. assume 0.38 should be 3.80
# 3. Delete the fish?

# Discuss; Which, and why?

# I choose 3

#Instruction: 
# Keep fish with weight = NA
# Keep fish with weight > 0.38

# This will eliminate JUST the one fish with weight 0.38

Cisco <- Cisco %>%
  filter(is.na(weight) | weight > 0.38) 

##################################################
# STEP 4: Check for typos and broken factors     #
##################################################

# lakeid: Lake name (all TR=Trout Lake)
# gearid: Capture gear type
# spname: Species name (all CISCO)
# sex: Sex (F=Female, I=Immature, M=Male)

levels(Cisco$lakeid) #all one lake. 
# Correct, as per data documentation
levels(Cisco$gearid) # Given metadata do not allow us to interpret this
levels(Cisco$spname) # All are CISCO, makes sense
levels(Cisco$sex) # all good

###############
# BEGIN PLOTS #
###############

a <- ggplot(Cisco, aes(x=sampledate, y = length)) + 
  geom_point()

a

# Lots of data here. I'm curious about the different gear types

a <- ggplot(Cisco, aes(x=sampledate, y = length, colour=gearid)) + 
  geom_point()

a

#Unsatisfying. Let's summarize the mean annual length by gear type and try that

SummaryData <- Cisco %>%
  group_by(year4, gearid) %>% #Grouping by year AND gear
  summarise(avg=mean(length))


a <- ggplot(SummaryData, aes(x=gearid, y = avg)) + 
  geom_point(size=4) + 
  theme_bw() + 
  xlab("Study year") + 
  ylab("Average length of fish caught (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14),
        legend.position="none") 

a # We could use a boxplot. But let's try something more fun!

# Introducing gganimate https://github.com/thomasp85/gganimate

a + transition_time(year4) +
  labs(title = "Year: {frame_time}")

# With shadows

a + transition_time(year4) +
  labs(title = "Year: {frame_time}") + 
  shadow_wake(wake_length = 0.1, alpha = FALSE)

# With starting point highlighted

a + transition_time(year4) +
  labs(title = "Year: {frame_time}") + 
shadow_mark(alpha = 0.3, size = 0.5)

# Works for boxplots too
b <- ggplot(data = Cisco, aes(x = gearid, y=weight)) +
              geom_boxplot()

b + transition_time(year4) +
  labs(title = "Year: {frame_time}")



## OLD CODE######################################

a <- ggplot(SummaryData, aes(x=gearid, y = avg)) + 
  geom_point(aes(colour=year4), size=4) + 
   theme_bw() + 
  xlab("Study year") + 
  ylab("Average length of fish caught (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14),
        legend.position="none") + 
  geom_text_repel(label=SummaryData$year4)

a # Still not an effective plot, but at least we can
# make out the years.

# IMPORTANT POINT:
# IF you are using text AND the text is overlapping, 
# solution = geom_text_repel in the ggrepel package


####
# Animation with gganimate
####








a <- ggplot(SummaryData, aes(x=gearid, y = avg, frame=year4)) + 
  geom_point(size=2) + 
  scale_colour_brewer(palette="Set1") + 
  theme_bw() + 
  xlab("Study year") + 
  ylab("Average length of fish caught (mm)") + 
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

a 

p <- ggplotly(a)

p <- p %>%
  animation_opts(1000, easing="elastic", redraw=FALSE)
p

# Not a great plot, but you get the point.
# Better example: https://plot.ly/ggplot2/animations/#mulitple-trace-animations

# You can also use "gganimate" but the package is currently experimental. Most worked examples... 
# don't work anymore

# See also: https://d4tagirl.com/2017/05/how-to-plot-animated-maps-with-gganimate

