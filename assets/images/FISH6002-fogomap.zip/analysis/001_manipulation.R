# FISH 6002: Week 11: Project workflow
# 001_Manipulation
# Nov 19, 2017
##########

library(tidyverse)
library(raster)
library(maptools)
library(rgdal)

#######################
# Get a map of Canada #
#######################

# getData grabs administrative boundaries from the web
# See ?getData for full functionality

# Get level 0 (i.e. JUST hte contry boundary) data
Canada <- getData("GADM", country="CAN", level=0) # download CAN level 0 map 

# Get level 1 data: Provinces
Province <- getData("GADM", country="CAN", level = 1) 
# Select just NL
NL <- (Province[Province$NAME_1=="Newfoundland and Labrador",]) 

# Get level 2 data: Specific regions
Regional <- getData("GADM", country="CAN", level = 2)

# Select just Fogo
Fogo <-(Regional[Regional$NAME_1=="Newfoundland and Labrador",]) #See http://gadm.org/maps/CAN_2_5.html
Fogo <-(Fogo[Fogo$NAME_2=="Division No. 8",]) #See http://gadm.org/maps/CAN_2_5.html

###########################
# Load data for plotting  #
###########################
PotDeploy <- read.csv("data/potdata.csv")

# Data:
# FleetID: Identifier. One value per fleet
# PotID: Identifier for pot deployment
# PotName: Identifier for specific pot (i.e. most pots were deployed more than once).
# NOR pots are numbered. NL pots are lettered
# PotType: The pot type (NOR or NL)
# LatDeg: Latitude in degrees
# LatMinSec: Latitude in Minutes.seconds
# LongDeg: Longitude in degrees
# LongMinSec: Longitude in minutes.seconds

# Decimal Degrees = Degrees + minutes/60 + seconds/3600
# Latitudes are positive. Longitudes are negative here, because they're W rather than E. 

PotDeploy <- PotDeploy %>%
  mutate(LatDecDeg = LatDeg + (LatMinSec/60)) %>%
  mutate(LongDecDeg = -1 * (LongDeg + (LongMinSec/60)))

#############################################
# Load shapefiles for NAFO zones            #
#############################################

NAFO <- readOGR("data/shapefiles/Divisions.shp")

##################
