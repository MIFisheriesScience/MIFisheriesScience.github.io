# FISH 6002: Week 11: Project workflow
# 002_Visualization
# Nov 19, 2017
##########

summary(NAFO)

####################### 
# Projection example  #
#######################
 
# Produce a mercator projection map of Canada

a <- ggplot() +
  geom_polygon(data=Province, aes(long, lat, group=group)) +
  coord_map() # Alter the map projection. Mercator = default

# Cylindrical projection
b <- ggplot() +
  geom_polygon(data=Province, aes(long, lat, group=group)) +
  coord_map(projection="cylindrical") 

# Ortho projection
c <- ggplot() +
  geom_polygon(data=Province, aes(long, lat, group=group)) +
  coord_map(projection="ortho") 

# Have to use the png device with dev.off, rather than ggsave, due to 3 plots

png(filename = "plots/CanadaProjection.png", res=300, pointsize=12, width=5, height=15, units="in")
multiplot(a,b,c)
dev.off()

###################
# Plot the Arctic #
###################

# Make a stereographic projection of the Arctic

a <- ggplot() +
  geom_polygon(data=Province, aes(long, lat, group=group)) +
  coord_map(projection = "stereographic", 
            xlim = c(-100,-60), ylim=c(60,90)) 

a

ggsave("plots/ArcticMap.png", width=4, height=5)

# More info about projections: 
# https://rud.is/b/2015/07/24/a-path-towards-easier-map-projection-machinations-with-ggplot2/



##########################################
# Plot Fogo map data                     #
##########################################

# Establish minimum and maximum latitudes and longitudes

longmin <- -54.35
longmax <- -53.95
latmin <- 49.5
latmax <- 49.77


# Plot the data

a <- ggplot() +
  geom_polygon(data=Fogo, 
               aes(long,lat, group=group), 
               colour="grey10",fill="#fff7bc") + # From GADM data
  coord_map(xlim=c(longmin, longmax), # Set the axes max and min
            ylim=c(latmin+0.01, latmax)) +
  xlab("Longitude") +
  ylab("Latitude") +
  theme_bw() +
  theme(axis.text=element_text(size=12), axis.title = element_text(size=14)) +
  # Replace X and Y positives and negatives with degree N and degree W respectively
  scale_x_continuous(breaks=seq(longmin,longmax, 0.1),  # absolute value eliminates negative
                     labels=c(paste(abs(seq(longmin,longmax, 0.1)),"°W", sep=""))) + 
  scale_y_continuous(breaks=seq(latmin,latmax, 0.1), 
                      labels=c(paste(seq(latmin,latmax, 0.1), "°N", sep=""))) +
  scaleBar(lon=longmin+0.03, lat=latmin+0.015, 
           distanceLon=5, distanceLat=0.75, distanceLegend=1.25, 
           dist.unit="km") +
  scaleBar(lon=longmax-0.03, lat=latmax-.06, distanceLon=0, distanceLat=0, distanceLegend=0, dist.unit="km", 
           orientation=TRUE, arrow.length=4, arrow.distance=2, 
           legend.colour="white") +
  # Plot the location of Seldom, a town on Fogo (for visual reference)
  geom_point(size=3, aes(x=-54.173329, y=49.615394), size=2, colour="brown")+
  geom_text(label="Seldom", aes(x=-54.187, y=49.630394), colour="brown") +
  # Add PotDeploy.csv's data
  geom_point(size=3, data=PotDeploy, aes(LongDecDeg, LatDecDeg))

################################
# Prepare an inset             #
################################

b <- ggplot() +
  geom_polygon(data=NL, aes(long, lat, group=group), 
               colour="grey10",fill="#fff7bc") +
  coord_map(ylim=c(46, 61)) +
  theme_bw()+xlab("")+ylab("") +
  theme(axis.text.x=element_blank(),
        axis.text.y= element_blank(), 
        axis.ticks=element_blank(),
        axis.title.x =element_blank(),
        axis.title.y= element_blank(), 
        panel.grid.major=element_blank(), 
        panel.grid.minor=element_blank()) +
  theme(plot.margin=unit(c(0,0,0,0), "cm")) +
  labs(x=NULL, y=NULL) +
  geom_rect(aes(xmin = longmin-.33, xmax = longmax+.37, 
                ymin = latmin-.35, ymax = latmax+.35), 
            alpha = 0, colour="red", size = 2, linetype=1)

###########################
# Combine the plots       #
###########################


png(filename = "plots/fogomap.png", res=300, pointsize=12, width=6, height=7, units="in")

grid.newpage()

v1<-viewport(width = 1, height = 1, x = 0.5, y = 0.5)          #plot area for the main map
v2<-viewport(width = 0.25, height = 0.25, x = 0.87, y = 0.3)   #plot area for the inset map
print(a,vp=v1) 
print(b,vp=v2)

dev.off()



#####################
# NAFO ZONES        #
#####################

# Plot the NAFO zones with labels

a <- ggplot() +
  geom_polygon(data=NL, aes(long, lat, group=group)) +
  geom_path(data=NAFO, aes(long, lat, group=group)) +
  annotate("text", x = coordinates(NAFO)[,1], 
           y = coordinates(NAFO)[,2], 
           label=NAFO[["ZONE"]]) +
  coord_map() 

a

ggsave("plots/NAFOzones.png")

##########################################################
# Save workspace as an .Rdata file for Markdown plotting #
##########################################################

save.image(file="FogoMapImage.RData", compress=TRUE)


