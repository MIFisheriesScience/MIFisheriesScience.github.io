# Minimal reproducible example

# Dr. Brett Favaro
# Sept 23, 2019

# Here is a very simple script that has a bug:

require(tidyr)

cod <- c(1,1,3,1,2,5,2,3,2,1)
salmon <- c(2,3,5,1,3,5,2,3,1,4)

fishcatch <- data.frame(cod, salmon)

fishlong <- gather(fishcatch, 
                   species, 
                   number, 
                   cod:salmon)

plot(fishlong$number ~ fishlong$species)
 
# use the dput() command to turn the data frame into plain text that can be easily shared


dput(fishlong) # Allows for copy and paste of the whole dataset

dput(head(fishlong))

# Proof that this works

df <- dput(fishlong)

df

df == fishlong

# MINIMAL EXAMPLE starts here:

df <- structure(list(species = c("cod", "cod", "cod", "cod", "cod", 
                           "cod", "cod", "cod", "cod", "cod", "salmon", "salmon", "salmon", 
                           "salmon", "salmon", "salmon", "salmon", "salmon", "salmon", "salmon"
), number = c(1, 1, 3, 1, 2, 5, 2, 3, 2, 1, 2, 3, 5, 1, 3, 5, 2, 3, 1, 4)), row.names = c(NA, -20L), .Names = c("species", 
                                                                "number"), class = "data.frame")

plot(df$number ~ df$species)

# See slides for context. Make sure to talk about aritculating steps.
