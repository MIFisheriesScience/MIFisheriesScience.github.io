# R Code for Week 3: Markdown and Workflow
# FISH 6002
# Started Feb 27, 2017
# Edited Sept 23, 2018
# Edited again Sept 20, 2019

# Math operators are:
# + - * / ^ log(X) ()

# At the end of File 2 we will bring in data from a CSV file. 
# Normally, data are loaded right at the top of a script.

# For demonstration purposes only, here is the description
# of those data:

# DiceData.csv: This file contains sample data prepared by Brett Favaro for FISH 6002: Week 3 (Markdown and Workflow). This dataset describes a fictional study in which two six-sided dice were rolled ten times.  
# Variables:
# RollNum: The numerical label of the roll. (Number 1-10, as there were ten rolls of each die)
# Score: The score of the die (1-6)
# DiceName: The name of each die used. (Two levels; Die1, Die2)

# In R Studio, CTRL+ENTER runs a line of code
# Try this here

2

2+2

2*(2+2)

# Let's define a variable

X <- 1 # Define X, give it value of 1
X #What's the value of X?

#It's 1. 
# Now, let's ask some questions using logical operators.
# Logical operators are 
# < > == != <= >=

X == 2 # Does X equal 2?
#nope

X != 2 # Does X NOT equal 2?
#yes, because it's 1.

X + 1 # Let's add 1 to X
#Cool, it's 2!

X #What's the value of X again?
#What? Why is it 1?

X <- X + 1 
X #ahh, now it's 2. See the difference?

#Fun with variables
number_of_fish <- 1
number_of_fish + number_of_fish

fishname <- "Swimmy"

fishname + fishname #oops doesn't work. Why not?

# Okay, let's do a little script now. 
#Imagine rolling two regular six-sided dice

#First, let's make a variable for each one
Die1 <- 0 
Die2 <- 0

NumRolls <- 10 #Here, we specify number of rolls

Die1 <- sample(1:6, NumRolls, replace = T) 
Die2 <- sample(1:6, NumRolls, replace = T)

plot(Die1+Die2) #Basic plot command
# more later

# Woohoo! We've got cumulative dice value across ten rolls

#What's in each variable?
Die1
head(Die1)
summary(Die1)

#So Die1 is a VECTOR, with ten values. 
Die1[3] #What's in the FIRST position of Die1?

Die1
Die2
Die1 + Die2
Die1 * Die2
Die1 == Die2

#Die1 <- c(3,1,2,5,2,2,5,4,5,1) #Use if you want your plots to look the same as mine
#Die2 <- c(5,2,3,2,2,2,4,5,5,3)  

#Scenario 1: Build a data frame from above

RollNum <- c(1:NumRolls) #Let's make a counter for each roll
DiceData <- data.frame(RollNum, Die1,Die2) #Create a data frame with results of both sets of
#dice rolls
DiceData

#A quick data manipulation step to get it into 'long form' 
install.packages("tidyr")

require(tidyr)

DiceData_long <- gather(DiceData, 
                        DiceName, 
                        Score, 
                        Die1:Die2)
#In case you're curious this is:
#1) Declaring a new data frame called DiceData_long
#2) Assigning it the value of everything to the right of the arrow
#3) gather, from the tidyr package makes wide data long
#4) First parameter (DiceData) specifies the data frame to operate on
#5) Second parameter (DiceName) creates the new column, made from names of data columns
#6) Third parameter (Score) is the actual value column
#7) Fourth parameter specifies which columns to draw values from
# Result is a long-format dataframe that retains everything not specified above

head(DiceData_long) #did it work?
summary(DiceData_long)


