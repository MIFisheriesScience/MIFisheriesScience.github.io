# 6002 Part 2: Data manipulation

# Author: 

# This file will eventually contain all your code for Part 2
# of the Major Assignment