# Sample script

# I'm including this as an example of a basic script

fishdata <- read.csv("./data/sampledata.csv")

head(fishdata)

plot(length_cm ~ species, data=fishdata)
