# 6002 Part 3: Data display

# Author: 

# This file will eventually contain all your code for Part 2
# of the Major Assignment