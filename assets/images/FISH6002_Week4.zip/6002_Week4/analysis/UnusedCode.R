# Unused code from Fall 2017 version

############
# aside: xtable
############

# install.packages("xtable") # Run if needed

#library(xtable)

# xtable is a package that lets you create formatted output tables. 
# Most journals have specific formats required for this, but if you need 
# a quick, nice table (e.g. for a presentation) you can use this.

#WideFormatXtable <- xtable(WideFormat) #This gives you an xtable object

#Now, let's render this as an HTML file
#print.xtable(WideFormatXtable, typ="html", file="FormattedTable.html")  

# Navigate to your working directory and open that html file. 
# Boom, formatted table!
# You can now paste that into Word, Powerpoint, or whatever else. 


CombinedData <- TidyData %>%
  inner_join(TemperatureData, by="Deployment")

# See the pattern? 
# Piping can really clear up code, especially when running multiple operations. e.g.

PipedData <- TidyData %>%
  bind_rows(ExtraData) %>%
  inner_join(TemperatureData, by="Deployment")
