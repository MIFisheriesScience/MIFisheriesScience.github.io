## Code to pre-load minor assignment 1 data

# Started 21 Jan 2019
  
library(tidyverse)
library(lubridate)

source("../R/6003Functions.R")

# Data basics:
#Source: http://derekogle.com/fishR/data/data-html/YERockfish.html

#>A data frame with 159 observations on the following 5 variables.

#>date: Date fish was collected
#>length: Total length (cm)
#>age: Otolith age
#>maturity: Maturity state (Immature or Mature)
#>stage: Stage of maturity (1:Immature, 2:Maturing, 3:Mature, 4:Fertilized, 5:Ripe, 6:Spent, 7:Resting)

rockfish <- read.csv("./data/YERockfish.csv") 


##############
# PRE-CHECK  #
##############

# 1. Did it load?
head(rockfish)

###
# 2. Are data types correct?
str(rockfish)

# Let's make Date a lubridate item

rockfish$date <- mdy(rockfish$date)

str(rockfish)

###
# 3. Check impossible values

#date
#length
#age: Otolith age

plot(rockfish$date) # Note an observation from 2008. Not an *impossible* value so don't exclude here.
plot(rockfish$length) #Nothing impossible
plot(rockfish$age) #noting impossible 
# max reported age is 118 years so we're fine
# https://www.fishbase.ca/Summary/SpeciesSummary.php?ID=3996&AT=yelloweye+rockfish


###
# 4. Check factor levels

levels(rockfish$maturity) #good
levels(rockfish$stage) 
# Problem: both 8 and N/A

# Solution, for the purpose of exercise - remove 8 and N/A

rockfish <- rockfish %>%
  filter(stage!=8) %>%
  filter(stage!="N/A")

# Eliminates 3. I'm okay with that.

##############################
# DATA EXPLORATION BEGINS    #
##############################

### 1. Outliers Y and X

### 2. Homogeneity Y

### 3. Normality  Y

### 4. Zero trouble Y 

### 5. Collinearity X 

### 6. Relationships Y and X

### 7. Interactions

### 8. Independence Y



