# FISH 6003: Week 8: Mixed Effects

# Started 2 March 2018

library(tidyverse)
library(visreg)
library(lme4)

source("./R/6003Functions.R")

# Today's data are from a fictional study.

FishGrowth <- read.csv("./data/1-NestedInTanks.csv")

str(FishGrowth)
FishGrowth$Tank <- as.factor(FishGrowth$Tank)

# The study design is as follows:

# We have nine large aquariums. Each aquariums has ~ six fish. 
# We raised them for six months, feeding them either low food, medium food, or high food.
# At the end of six months, measure the fish once

plot(FishSize ~ Treatment, data=FishGrowth) # Nice and clean.

# But, is each piece of data truly independent?

a <- ggplot(data=FishGrowth, aes(x = Tank, y = FishSize, col=Treatment))

a + geom_point()
    
# We see a few things going on: 
# - There is more than one observation per tank.
# - There is a clear pattern - some tanks seem to be better than others. 

# So, there is dependency, and we can clearly see that dependency is affecting our results

# What to do?

# Option 1: Build a time machine and travel to the past. Put every fish in one tank, on its own.

# But that's often not feasible, desirable, or ethical (e.g. animal care requirements)

# Option 2: Take an average of each tank and model that.

# This code will reduce the dataset into means
ReducedDataset <- FishGrowth %>%
  group_by(Tank, Treatment) %>%
  summarise(MeanSize = mean(FishSize)) 

mod1 <- lm(MeanSize ~ Treatment, data=ReducedDataset)

summary(mod1)

# Here, the effect size was very strong. Lucky us. Despite N = 9, effect was statistically significant.

visreg(mod1) # But look at those confidence intervals. Three dots.

plot(residuals(mod1) ~ fitted(mod1))
abline(h=0, lty=2)

# Way too sparse. Not good.
# Rule of thumb = need 15 observations per covariate. 

########################################
# Option 3: Linear mixed effects model #
########################################

head(FishGrowth)

# Fixed effect: Treatment
# Random effect: TankID

mod2 <- lmer(FishSize ~ Treatment + (1 | Tank), data=FishGrowth)

summary(mod2)

visreg(mod2, "Treatment", by="Tank", re.form=~(1|Tank))

# Intraclass correlation

(3.506^2)/(3.506^2 + 3.910^2)

###############################
# Part 2: Repeated measures   #
###############################

RepeatedMeasures <- read.csv("./data/2-MultipleObservations.csv")

str(RepeatedMeasures)

RepeatedMeasures$Tank <- as.factor(RepeatedMeasures$Tank)
RepeatedMeasures$FishID <- as.factor(RepeatedMeasures$FishID)

mod3 <- lmer(FishSize ~ Treatment + Month +  (1 | Tank/FishID), data=RepeatedMeasures)

summary(mod3)

#####################################
# Part 3: Measurement repeatability #
#####################################

Repeatability <- read.csv("./data/3-MeasurementError.csv")

RepeatabilityLong <- Repeatability %>%
  gather("MeasurementNum", "Size", 4:5) 
  
mod4  <- lmer(Size ~ 1 + (1 | FishID),
  data=RepeatabilityLong)

summary(mod4)

110.281 / (110.281 + 9.769)




