# Code for FISH 6003 Week 5 lecture: Exercise 2 - Model Selection

# Brett Favaro
# Started Feb 2, 2018

# MUST RUN LIONFISHDATASETUP.R

# Data from: Peiffer et al 2017
# https://peerj.com/articles/3818.pdf

# Recall:
# 
# TransectID: Unique identifier for Transect Number
# Culling: Were lionfish culled? Yes/no
# PercentageCover: Percentage hard coral cover
# SubstrateHeight: Metric of topographic complexity (in cm)
# PreyDensity: Density in fish per hectare of prey fish species, as defined by being < 15 cm
# PredDensity: Density in fish per hectare of predator fish species. 
# ShannonW: The shannon-weiner index for that transect. Bigger = more diverse. 

# DO NOT USE:
# Site: Factor with six levels - WHERE the transects took place
# Richness: # of PREY FISH species observed on a transect
# LF_Density: Density in lionfish per hectare (invasive predator)


library(MuMIn)


# Let's specify a model:

# Y: Prey Density
# X: Culling, ShannonW, PredDensity, PercentageCover, 
# SubstrateHeight, and an interaction between Culling and PercentageCover 

# Recall that we eliminated interaction between Culling and ShannonW due to VIF score

# First, standardize covariates

LF_Transects$PercentageCover_scale <- scale(LF_Transects$PercentageCover)
LF_Transects$ShannonW_scale <- scale(LF_Transects$ShannonW)
LF_Transects$PredDensity_scale <- scale(LF_Transects$PredDensity)
LF_Transects$SubstrateHeight_scale <- scale(LF_Transects$SubstrateHeight)

mod <- lm(PreyDensity ~ Culling + ShannonW_scale + PredDensity_scale + PercentageCover_scale + SubstrateHeight_scale 
           + Culling*PercentageCover_scale,
           data=LF_Transects)

summary(mod)

# Option 1: Leave it as is. 

# Option 2: Hypothesis testing

# via t-value:
# Drop shannon_W

mod2 <- lm(PreyDensity ~ Culling + PredDensity_scale + PercentageCover_scale + SubstrateHeight_scale 
          + Culling*PercentageCover_scale,
          data=LF_Transects)

summary(mod2) 

#Can't drop percente cover because there's a significant interaction
# Drop preddensity
mod3 <- lm(PreyDensity ~ Culling + PercentageCover_scale + SubstrateHeight_scale 
           + Culling*PercentageCover_scale,
           data=LF_Transects)

summary(mod3)

# drop substrate height

mod4 <- lm(PreyDensity ~ Culling + PercentageCover_scale +  
           Culling*PercentageCover_scale,
           data=LF_Transects)

summary(mod4)

# Option 2 via F-test

drop1(mod, test="F")

mod2 <- lm(PreyDensity ~ Culling + PredDensity_scale + PercentageCover_scale + SubstrateHeight_scale 
           + Culling*PercentageCover_scale,
           data=LF_Transects)

drop1(mod2, test="F")

mod3 <- lm(PreyDensity ~ Culling + PercentageCover_scale + SubstrateHeight_scale 
           + Culling*PercentageCover_scale,
           data=LF_Transects)

drop1(mod3, test="F")

mod4 <- lm(PreyDensity ~ Culling + PercentageCover_scale +  
             Culling*PercentageCover_scale,
           data=LF_Transects)

drop1(mod4, test="F")

# alternate
anova(mod)

# Option 3 via AIC

# mod is a full model
# mod 2 is reduced
# mod 3 is not nested - it's a different model altogether

mod <- lm(PreyDensity ~ Culling + 
            ShannonW_scale + 
            PredDensity_scale + 
            PercentageCover_scale + 
            SubstrateHeight_scale 
          + Culling*PercentageCover_scale,
          data=LF_Transects)

mod2 <- lm(PreyDensity ~ Culling + 
             PercentageCover_scale + 
             SubstrateHeight_scale +
           Culling*PercentageCover_scale,
          data=LF_Transects)

mod3 <- lm(PreyDensity ~ Culling + Site, data=LF_Transects)

AIC(mod, mod2, mod3)
AICc(mod, mod2, mod3)

# You may want to use AICc - AIC for small sample sizes
# Note that it gives a different answer.

# Option 4 via IT approach

# Hypothesis 1: Prey density increases with culling
mod <- lm(PreyDensity ~ Culling,
          data=LF_Transects)

# Hypothesis 2: Prey density increases with culling, but is mediated by coral cover
mod2 <- lm(PreyDensity ~ Culling * PercentageCover_scale,
          data=LF_Transects)


# Hypothesis 3: Prey density is explained only by site
mod3 <- lm(PreyDensity ~ Site,
          data=LF_Transects)

# Hypothesis 4: Prey density increases with culling and substrate height

mod4 <- lm(PreyDensity ~ Culling +
            SubstrateHeight_scale,
          data=LF_Transects)

# Hypothesis 5: Prey density increases with culling, 
#but decreases with predator density (the two do not interact)
mod5 <- lm(PreyDensity ~ Culling +
            PredDensity_scale,
          data=LF_Transects)

AICc(mod, mod2, mod3, 
     mod4, mod5)
