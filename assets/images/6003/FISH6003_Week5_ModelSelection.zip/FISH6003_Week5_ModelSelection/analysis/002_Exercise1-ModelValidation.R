# Code for FISH 6003 Week 5 lecture: Exercise 1 - Model Validation

# Brett Favaro
# Started Jan 31, 2018

library(standardize)
library(car)
library(visreg)

# MUST RUN LIONFISHDATASETUP.R

# Data from: Peiffer et al 2017
# https://peerj.com/articles/3818.pdf

# Recall:
# 
# TransectID: Unique identifier for Transect Number
# Culling: Were lionfish culled? Yes/no
# PercentageCover: Percentage hard coral cover
# SubstrateHeight: Metric of topographic complexity (in cm)
# PreyDensity: Density in fish per hectare of prey fish species, as defined by being < 15 cm
# PredDensity: Density in fish per hectare of predator fish species. 
# ShannonW: The shannon-weiner index for that transect. Bigger = more diverse. 

# DO NOT USE:
# Site: Factor with six levels - WHERE the transects took place
# Richness: # of PREY FISH species observed on a transect
# LF_Density: Density in lionfish per hectare (invasive predator)


# Let's specify a model:

# Y: Prey Density
# X: Culling, ShannonW, PredDensity, PercentageCover, SubstrateHeight, and an interaction between Culling and PercentageCover 
# (Maybe Culling has a different effect when there is more coral cover, as an example)

plot(LF_Transects$PredDensity)
plot(LF_Transects$PercentageCover)

mod <- lm(PreyDensity ~ Culling + ShannonW + PredDensity + 
            PercentageCover + SubstrateHeight + Culling*PercentageCover + Culling*ShannonW,
          data=LF_Transects)

summary(mod)

####################
# Assumption check #
####################

# Normality

hist(residuals(mod), breaks=15) # Looks a bit dodgy

plot(mod) # look at QQ plot.
# That looks okay

#Normality = pretty good

##
# Homogeneity
##

plot(residuals(mod) ~ fitted(mod))
abline(h=0) #pretty good

# Plot residuals against covariates that are, and are not, in the model

plot(residuals(mod) ~ Culling, data=LF_Transects)
plot(residuals(mod) ~ ShannonW, data=LF_Transects)
plot(residuals(mod) ~ PredDensity, data=LF_Transects)
plot(residuals(mod) ~ PercentageCover, data=LF_Transects)
plot(residuals(mod) ~ SubstrateHeight, data=LF_Transects)

# No obvious patterns in these, although 
# there's more variation in Culling=Yes sites

# In other words... the model fits worse in culling = yes sites


## 
# Independence
## 

# We know there are three transects per site, six sites
# Nested structure of study is not incorporated into this model. 

# Nor can it be. (Site is colinear with culling... 
# and too few levels of Site to add 'random effect' (see upcoming Mixed Effects Model lecture))

# We don't have sites where there was both culling and no culling
# - perhaps you CANT have both on one site because fish move

# Not much we can do, I'm afraid. Prepare to justify your decision

##
# Fixed X
##

# Culling: in the paper they seem pretty certain about culling. Fixed

# ShannonW: Lots of uncertainty here, most likely. (not fixed)

# PredDensity: I don't like that we're using density. Would be better to use count (Not fixed)

# PercentageCover: Definitely uncertainty here. (Not fixed)

# SubstrateHeight: Some uncertainty here (Not fixed)

# What to do?
# - Limit number of calculation steps (e.g. with Density.. just use count... but stay tuned for GLM lecture)
# - Try to quantify uncertainty in some way. 
# Particularly important: Is there a systematic bias (bad) or is it random (less bad)
# e.g. we know detection probability across species is not equal. 
# But if we always miss small fish when there's lots of coral cover, then we have a problem

# - Fancier stuff, beyond the scope of this exercise

##################################
# CONCLUSION: 
# 
# Zuur and Ieno. (2016) language: 
# 
# Methods:
# We verified model assumptions by plotting residuals versus fitted values,
# versus each covariate in the model and versus each covariate not in the model.
#
# *If you checked for temporal or spatial independence, say so. We didn't, so don't say it* 
#
# Results:
#
# Model validation indicated no problems 
# 
# Best practice (rarely done)
# Include an appendix with user-executable R code that walks them through the validation
# much like our exercises in this class
################################

###############################
# EXERCISE 1, PART 2:         #
#                             #
# vifs                        #
###############################

vif(mod) #need car library

# Remove Culling:PercentageCover interaction

mod2 <- lm(PreyDensity ~ Culling + ShannonW + PredDensity + 
            PercentageCover + SubstrateHeight + Culling*ShannonW,
          data=LF_Transects)

vif(mod2)

mod3 <- lm(PreyDensity ~ Culling + ShannonW + PredDensity + 
             PercentageCover + SubstrateHeight,
           data=LF_Transects)

vif(mod3)

# Re-validate based on mod3

summary(mod)
summary(mod2)
summary(mod3) # Note that culling is now 'significant'!

###############################
# EXERCISE 1, PART 3:         #
#                             #
# Standardization             #
###############################

LF_Transects$PercentageCover_scale <- scale(LF_Transects$PercentageCover)
LF_Transects$ShannonW_scale <- scale(LF_Transects$ShannonW)
LF_Transects$PredDensity_scale <- scale(LF_Transects$PredDensity)
LF_Transects$SubstrateHeight_scale <- scale(LF_Transects$SubstrateHeight)


range(LF_Transects$ShannonW_scale)
range(LF_Transects$PredDensity_scale)
range(LF_Transects$PercentageCover_scale)
range(LF_Transects$SubstrateHeight_scale)

mod4 <- lm(PreyDensity ~ Culling + ShannonW_scale + PredDensity_scale + PercentageCover_scale + SubstrateHeight_scale 
          + Culling*PercentageCover_scale + Culling*ShannonW_scale,
           data=LF_Transects)
  
summary(mod4)

# Still do VIF

vif(mod4)

mod5 <- lm(PreyDensity ~ Culling + ShannonW_scale + PredDensity_scale + PercentageCover_scale + SubstrateHeight_scale 
           + Culling*PercentageCover_scale,
           data=LF_Transects)

vif(mod5) #This time, we can keep the interaction in!

summary(mod5)

unstandardized_mod5 <- lm(PreyDensity ~ Culling + ShannonW + PredDensity + PercentageCover + SubstrateHeight 
                                  + Culling*PercentageCover,
                                  data=LF_Transects)

summary(unstandardized_mod5)
vif(unstandardized_mod5)

########
LF_Transects


# But, recall that ShannonW is colinear with a couple things in the model.

# What impact does it have on results if we remove its interaction?

mod2 <- lm(PreyDensity ~ Culling + ShannonW + PredDensity + PercentageCover + SubstrateHeight + Culling*PercentageCover,
           data=LF_Transects)

summary(mod2)

# and if we remove it entirely?

mod3 <- lm(PreyDensity ~ Culling + PredDensity + PercentageCover + SubstrateHeight + Culling*PercentageCover,
           data=LF_Transects)

summary(mod3)

# Takeaway: Lines of code needed to run model: 2
# Lines of code needed to prep data for model; 923 (with comments, that is)

# Ponder this as you lay out your spreadsheets. 