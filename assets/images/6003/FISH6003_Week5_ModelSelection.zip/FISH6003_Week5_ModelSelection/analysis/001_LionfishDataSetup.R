# FISH 6003: Week 5 Data Setup
# Lionfish example
# Data from: Peiffer et al 2017
# https://peerj.com/articles/3818.pdf

# This is identical to the Week 4 data setup

library(tidyverse)

source("./R/6003Functions.R")

# Load the data files
# Original data was in an Excel spreadsheet and had to be parsed out 
# as a number of CSVs as follows
# We will have to undergo extensive data preparations to use all variables. 

# Goal is to produce one large sheet, where one row is one observation of a fish

# Goal 2: Fully denormalize the dataset so that we can include all grouping and habitat variables in model

# Load files one at a time

# Data on Lionfish and Native Predators
predators <- read.csv("./data/LionFishNativePreds.csv")

# Check if it loaded
head(predators)
str(predators)

# One row is one species and size class. "Number" tells us how many individual fish fall within that species/size class.
# Leave it that way for now. Goal is one row per fish but we will do that at all at once

# It looks like we can figure out a unique Transect ID that cuts across datsets by going:
# Site X transect. (i.e. Transect 1, Site Dixies, is the same across all datasets)

# Since we're going to combine all these later, let's make a variable that clearly identifies whether these 
# are native predators, lionfish, or prey

levels(predators$Species) #Making sure Lionfish is always spelled the same

predators <- predators %>%
  mutate(Fish_type = ifelse(Species == "Lionfish", "Lionfish", "Native Predator"))

head(predators) # Worked

# Load second file

preyfish <- read.csv("./data/NativePreyFish.csv")

head(preyfish)
str(preyfish)

preyfish <- preyfish %>%
  mutate(Fish_type = "Prey") 

head(preyfish)

# Load third file

coralcover <- read.csv("./data/HardCoralCover.csv")

head(coralcover) # This one has some blank columns
str(coralcover)

# This is weird: The paper says they measured 12 types of coral cover:
# (i.e. hard coral, soft coral, dead coral, fire coral, gorgonian, sponge, macro-algae, 
# turf-algae, crustose, coralline algae, cyanobacteria, sand and rubble
# But only ONE, hard coral, is included in these data

# Options:
# - email author
# - Treat it is proportion hard coral, proprotion 'not hard coral' 
# I'm short of time, so let's do the second one.

# Remove blank columns:
coralcover <- coralcover %>%
  select(-X) %>%
  select(-X.1) 

# Load fourth file

topography <- read.csv("./data/TopographicComplexity.csv")

head(topography)
str(topography)

# Rename substrate height to something more sensible
topography <- topography %>%
  mutate(Substrate_height = Substrate.Height..cm.) %>%
  select(-Substrate.Height..cm.) 

# Data are loaded

# Combine by Transect and Site 

data <- bind_rows(preyfish, predators)

# Error messages are okay. 
# It's turning characters into factors. 
# We'll fix that later.

head(data)

# Add coral cover. But this requires a left join. 
# And that requires that we make sure 
# factor levels are same

levels(data$Site) #Careful - empty space on Fish Den
levels(coralcover$Site) # Divemaster is different.

# Different way to recode factor levels
data$Site <- recode(data$Site, "Fish Den " = "Fish Den")
levels(data$Site) # Good

coralcover$Site <- recode(coralcover$Site, "Divemaster's choice" = "Divemaster")

data <- left_join(data, coralcover, by=c("Site", "Transect"))

#head(temp)

# Culling was recorded in both datasets. Now we have Culling.X and Culling.Y
# Let's make sure they are same

table(data$Culling.x == data$Culling.y) # great!

# Drop one of them, rename the other

data <- data %>%
  select(-Culling.y) %>%
  mutate(Culling = Culling.x) %>%
  select(-Culling.x)

head(data)

# Cleanup of characters

data$Family <- as.factor(data$Family)
data$Site <- as.factor(data$Site)
data$Species <- as.factor(data$Species)
data$Scientific.name <- as.factor(data$Scientific.name)
data$Fish_type <- as.factor(data$Fish_type)


# Last thing, let's add topography

head(topography)
levels(topography$Site) # Fix divemaster
# Also change Lynn's Arena to Lynns Arena
# Also change Barry's Reef to Barrys Reef

topography$Site <- recode(topography$Site, "Divemaster's choice" = "Divemaster")
topography$Site <- recode(topography$Site, "Lynn's Arena" = "Lynns Arena")
topography$Site <- recode(topography$Site, "Barry's Reef" = "Barrys Reef")

topography$Site <- as.factor(topography$Site)

# What do we do with topography? Would be easier if there was just one observation per site

# From the paper: "Substratum height was recorded as a
# proxy for topographic complexity, every 5 m along the PITs by measuring the distance
# between lowest and highest point of the reef within a 1 m radius of the transect tape"

# The word "height" only appears three times. Once as above
# Once in figure 2, and once in table 1.

# It's not possible to figure out what they did from this. 

# It almost looks like they ran separate models, each as (for example):
# Y: Hard Coral Cover, X: Removal. Does removal predict 'hard coral cover?'
# Y: Substratum height, X: Removal. Does removal predict 'substratum height?'
# Y: Native predator biomass. X: Removal. Does removal predict 'native predator biomass?'

# I bet this is exactly what they did - they had one excel sheet with multiple sub-sheets. 
# I think they just did a bunch of one-way ANOVAs, looking at difference of means
# across removal / not removal for each of the above variables (and a few others)

# What's wrong with this?

# Hint: Multiple Comparisons problem

# Better approach: 

# Diversity or Abundance of prey fish ~ Removals + coral cover + substratum height + native_Predators

# So what do we do about topography?

# First, let's plot it
topography$Transect <- as.factor(topography$Transect)

a <- ggplot(data=topography, aes(y=Substrate_height, x=Transect)) +
  theme_bw() +
  facet_grid(. ~ Site) +
  geom_boxplot()

a

# All the transects had basically
# the same substrate height

# Here's a simplifying decision. Let's compute an average substrate height for each transect. 
# Rationale:

# Substrate height is supposed to be a proxy for topographic complexity
# Substrate height measured from lowest to highest point of reef within 1m radius of transect tape
# Use mean  because it's a continuous variable, and the distributions aren't all that skewed
# Distributions are roughly the same, so we're not missing much by not including all 12 observations
  
TopoMeans <- topography %>% 
  group_by(Site,Transect) %>%
  summarise(Substrate_height = mean(Substrate_height))

TopoMeans$TransectID <- seq.int(nrow(TopoMeans)) #Add a unique identifier for each transect. Could be useful later.

TopoMeans$Transect <- as.numeric(as.character(TopoMeans$Transect))

str(TopoMeans)


data <- left_join(data, TopoMeans, by= c("Site", "Transect"))

# Remove duplicates:

# data <- data %>%
#  select(-Substrate_height.y) %>%
# select(-TransectID.y) %>%
#  mutate(Substrate_height = Substrate_height.x) %>%
#  select(-Substrate_height.x) %>%
#  mutate(TransectID = TransectID.x) %>%
# select(-TransectID.x)

# Good news, we now have all variables in here!

#############################################
# Last:  We want one row to be one fish     #
#############################################

# Use the "Number" Variable to transform the dataset so that one row 
# = one fish
# This will be our working dataframe so let's call it something cool 
# (and easy to type)

lionfish <- data[rep(seq(nrow(data)), data$Number), 1:13]

# You will see we went from 285 rows to 1392. Is that correct?
# Let's sum up all the "Number" column in the original dataset
# This should be the total number of fish measured

sum(data$Number) #1392
# Great, our lionfish dataframe has 1392 rows, which is the correct number.
# One row now = one fish.
# Let's delete the now-useless "Number" column

lionfish <- lionfish %>%
  select(-Number)

#############################
# NEXT: Verify all data     #
#############################

# One row = one fish
# Reminder; Data were collected in transects. 
# These are all observations of individual fish along 50 x 5 m transects. Three transects per site.

str(lionfish)
# Our data are:
# 
# Site: Factor: One of a number of distinct sites in which data were collected
# Transect: Number: A number specifying which transect an observation occurred on.
# Family: Factor: Family name
# Species: Factor: Common name
# Scientific.name: Factor: Scientific name of species
# Size: Integer: Total length of each fish (cm)
# Fish_type: Factor: Lionfish (i.e. an invasive predator), Native Predator, or prey fish

# WARNING: Prey fish are defined as being < 15 cm. 
# In verification, make sure only small fish are prey!

# Category: Type of coral cover being measured. Only one value: Hard Coral. 
# Percentage.cover: Percentage of coral cover as measured on each transect. Everything else is 'not coral'
# Culling: Factor: THE MAJOR THING THEY MANIPULATED. Culling was either occurring "yes" or not "no." 
# Substrate_height: A metric of topographic complexity. See data preparation above
# TransectID: A unique identifier for each transect. 

# Before we begin data cleanup: Let's get rid of "Category" since the only category is hard coral

lionfish <- lionfish %>%
  select(-Category)

# Now:
# Are data types what they should be?
# Are there impossible values (numbers) or incorrect factor levels? (factors?)

# Site: 

levels(lionfish$Site) #Good

# Transect:

# Let's convert this to a factor. It is really a factor.

lionfish$Transect <- as.factor(lionfish$Transect)

levels(lionfish$Transect) # We're not really going to use this anyway. 
# If we included "Transect 1" in a model, it will be confounded by the fact that there is a
# transect 1 in each site. There is no MEANING to the transect number (it's not like "Transect 1's" are 
# somehow comparable to each other)

# Family: 

levels(lionfish$Family) # Looking for any slight misspellings or variants
# I see none. Good

# Species:
levels(lionfish$Species) #Again looking for spelling variants.

# Scientific.name: 
levels(lionfish$Scientific.name)

# There should be the same number of levels of common name and scientific name

unique(lionfish$Species)
unique(lionfish$Scientific.name)

#35 levels in each. Good.
# If you wanted to be REALLY meticulous, check to make sure the 
# right common name is associated with right scientific name!

# Size: 

plot(lionfish$Size) # Three major bands at 5, 10, and 15. Those must be the prey fish
plot(lionfish$Size, col=lionfish$Fish_type) # Looks that way
range(lionfish$Size)

# Fish_type: 

table(lionfish$Fish_type) #another way to check the factor levels while also
# checking count in each column

# Reminder: Prey fish were defined not by species, but size. All fish < 15 cm should be "Prey fish"

plot(lionfish$Size ~ lionfish$Fish_type)
abline(h=15, col="red") #good!

# Percentage.cover: Must be 0-100

plot(lionfish$Percentage.cover) 
range(lionfish$Percentage.cover)

# Culling: Factor: THE MAJOR THING THEY MANIPULATED. Culling was either occurring "yes" or not "no." 

table(lionfish$Culling) # Why more observations in yes?
# Because there were more fish in the culling sites

# Substrate_height: A metric of topographic complexity. See data preparation above

range(lionfish$Substrate_height)
plot(lionfish$Substrate_height)

# TransectID: A unique identifier for each transect. This should really be a factor.

lionfish$TransectID <- as.factor(lionfish$TransectID)

levels(lionfish$TransectID) # good. Numbers make sense too: 3 x 6 sites = 18

# I can sleep soundly.

#############################################################
# Derived value calculations                                #
#############################################################

# The authors frequently referred to "biomass"
# Presumably they converted the length of each fish into biomass using a 
# Von Bertalanffy growth curve

# This is problematic because, particularly for small fish, there will be
# uncertainty around actual biomass. This could violate our "Fixed X" rule

# Length-weight relationships work as follows:

# log(W) = log(a) + B*log(L) + error
# Where W is weight, L is length, and A and B are species-specific parameters

# In reality there is uncertainty in:
# - Transect size (Especially width)
# - Fish length (visually estimated to within 5 cm)
# - Detection probability of a fish (camoflaged fish more likely to be missed)
# - Length-weight relationship
 

# Note: In future versions of this course, maybe we can figure this out. For now, use density.

# Can we simplify further? Do we need fish SIZES too?

a <- ggplot(data=lionfish, aes(x=Species, y=Size)) + 
  geom_boxplot(aes(fill=Fish_type)) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

a

# - There is very little variation among body sizes within species. Almost none for prey fish
# - Authors have already decided that prey are defined by body size. Technically speaking, 
# size will be colinear with predator/prey (because predator/prey is DEFINED by size)

# Let's just eliminate size entirely from this, since we're not going to try and figure out biomass

# ALSO: 

# Some analyses require each row to be transect, not individual fish. Create a second dataframe

# New variables needed:
# Shannon weiner Sigma(P_i * log(P_i), for prey species only)

# (from the paper:)
# Transect-level data of prey fish density (individuals ha-1), as well as site-level data of
# taxonomic diversity (i.e. Shannon–Wiener index H) and richness were modelled as a
# function of removal treatment (fixed effect) and site as random effect
# (endquote). So it sounds like they did desnity, taxonomic diversity, and richness on prey fish only.

# Species richness (Just # of species on a transect)
# Prey density (little fish were on a 25 x 2 transect. Fish / hectare)
# Native predator density (big fish were on a 50 x 5 transect. Fish / hectare)
# Lionfish density (50 x 5 transect. Fish / hectare)

# Prepare the new dataframe
LF_Transects <- NULL

temp <- lionfish %>%
  filter(Fish_type == "Prey") %>%
  group_by(Species, TransectID) %>%
  mutate(NumPerTransect = n()) %>%
  group_by(TransectID) %>%
  mutate(Proportion = NumPerTransect/n())  %>%
  mutate(ShannonContribution = Proportion*log(Proportion)) %>% 
  mutate(Richness = n_distinct(Species)) %>%
  mutate(PreyDensity = n() / 0.005)
# Total area covered per transect for prey was 25 m x 2 m or 0.005 ha

temp2 <- temp %>%
  group_by(Species, TransectID) %>%
  summarise(Proportion = mean(Proportion), ShannonContribution = mean(ShannonContribution)) %>%
  group_by(TransectID) %>%
  mutate(ShannonW = -1*sum(ShannonContribution)) %>%
  select(-Proportion) %>%
  select(-ShannonContribution) %>%
  select(-Species) %>%
  summarise(ShannonW = mean(ShannonW))

PreyOnly <- left_join(temp, temp2, by="TransectID")

# Now we need to figure out predator density and lionfish density

PredOnly <- lionfish %>%
  filter(Fish_type == "Native Predator") %>%
  group_by(Species, TransectID) %>%
  mutate(NumPerTransect = n()) %>%
  group_by(TransectID) %>%
  mutate(PredDensity = n() / 0.025) 

LionFishOnly <- lionfish %>%
  filter(Fish_type == "Lionfish") %>%
  group_by(Species, TransectID) %>%
  mutate(NumPerTransect = n()) %>%
  group_by(TransectID) %>%
  mutate(LF_Density = n() / 0.025) 

AllData <- bind_rows(PreyOnly, PredOnly)
AllData <- bind_rows(AllData, LionFishOnly)

# Make the final data frame where one row = one transect
LF_Transects <- AllData %>%
  group_by(TransectID) %>%
  summarise(Site = first(Site),
            Culling = first(Culling),
            PercentageCover = first(Percentage.cover),
            SubstrateHeight = first(Substrate_height),
            Richness = first(Richness),
            PreyDensity = first(PreyDensity),
            PredDensity = median(PredDensity, na.rm=TRUE), 
            LF_Density = median(LF_Density, na.rm=TRUE),
            ShannonW = first(ShannonW)
  )

# Turn NAs into zeroes...
LF_Transects[c("PredDensity", "LF_Density")][is.na(LF_Transects[c("PredDensity", "LF_Density")])] <- 0

# 
LF_Transects # Horray! We now have two datasets to workwith:

# LF_Transects gives us transect-level data, and matches what they did in the paper
# AllData gives us fish-level data, and would allow us to go to biomass or work with individual fish and species

# Move on to exploration
