# Code for FISH 6003 Week 5 lecture

# Brett Favaro
# Started Jan 31, 2018

library(tidyverse)
source("./R/6003Functions.R")

terns <- read.csv("./data/6003_terns.csv")

# data from: https://peerj.com/articles/3287/

# wrecks = dead birds in a given two-week period
# hurricanes = # of hurricanes in a two week period

# Skip data verification because dataset is very simple

fit <- lm(wrecks ~ hurricanes, data=terns)
summary(fit)

CIs <- predict(fit, interval="confidence", level = 0.95)

lwr <- CIs[,2]
upr <- CIs[,3]

a <- ggplot(data=terns, aes(x=hurricanes, y=wrecks)) +
  theme_bw() +
  geom_point() +
  geom_smooth(method="lm", se=FALSE, color="darkgrey") 

a + geom_line(aes(y=upr, x=terns$hurricanes), col="red") + 
  geom_line(aes(y=lwr, x=terns$hurricanes), col="red") 

#####################
# Model validation  #
#####################

terns$residuals <- residuals(fit)
terns$fitted <- predict(fit)

#Side note:
terns$fitted2 <- fitted(fit)

# Predicted vs. fitted - what's the difference?
# - For lm - no difference
# - Later, when we do GLM's you will see:
#   - predict() - returns raw fitted values from a model
#   - fitted() - returns values after a link function is applied

# Meaning will become clear in a few weeks.

# NORMALITY:

# Test with a histogram or a qqplot
hist(terns$residuals, breaks=10)
plot(fit)

# HOMOGENEITY:

plot(terns$residuals ~ terns$fitted)
abline(h=0, lty=2)

# INDEPENDENCE

# Primarily assessed through study design. But also, plot each covariate against residuals

plot(terns$residuals ~ terns$hurricanes)
abline(h=0, lty=2)
# Not a great example

# Look for highly influential points:

# LEVERAGE

plot(cooks.distance(fit), type = "h", ylim = c(0, 1),
     xlab="Observation number",
     ylab="Cook's distance")
abline(h = 1, col = 2,lwd = 3)

#############
# Solutions #
#############

# for normality and homogeneity

lm(log(wrecks) ~ hurricanes, data=terns)
# Doesn't work. Why?

range(terns$wrecks) # there are zeroes
log(0) # ahh, right. Can't take log of zero

# Solution: Add a small (relative to data) constant).
# NB: NEVER LOG TRANSFORM COUNT DATA!! This is for illustration only

fitlog <- lm(log(wrecks+0.01) ~ hurricanes, data=terns)

summary(fitlog)

plot(log(wrecks+0.01) ~ hurricanes, data=terns, ylim=c(-4.5, 4.5))
abline(fitlog)

terns$logres <- residuals(fitlog)
terns$fitlog <- fitted(fitlog)

plot(logres ~ fitlog, data=terns, ylim=c(-3.5, 3.5), xlab="fitted",
     ylab="residuals of log-transformed model")
abline(h=0, lty=2)
############

fitquad <- lm(wrecks ~ hurricanes + I(hurricanes^2), data=terns)

newdat = data.frame(hurricanes = seq(min(terns$hurricanes), max(terns$hurricanes), length.out = 100))
newdat$pred = predict(fitquad, newdata = newdat)

plot(wrecks ~ hurricanes, data=terns)

lines(x=newdat$hurricanes, y=newdat$pred, col="red")

plot(residuals(fitquad) ~ predict(fitquad))
abline(h=0, lty=2)

summary(fitquad)

###

plot(wrecks ~ hurricanes, data=terns)

fit2 <- lm(wrecks ~ hurricanes + I(hurricanes^2), data=terns)
fit3 <- lm(wrecks ~ hurricanes + I(hurricanes^2) + I(hurricanes^3), data=terns)
fit4 <- lm(wrecks ~ hurricanes + I(hurricanes^2) + I(hurricanes^3) + I(hurricanes^4), data=terns)
fit5 <- lm(wrecks ~ hurricanes + I(hurricanes^2) + I(hurricanes^3) + I(hurricanes^4) + I(hurricanes^5), data=terns)
fit6 <- lm(wrecks ~ hurricanes + I(hurricanes^2) + I(hurricanes^3) + I(hurricanes^4) + I(hurricanes^5) + I(hurricanes^6), data=terns)

newdat = data.frame(hurricanes = seq(min(terns$hurricanes), max(terns$hurricanes), length.out = 100))

newdat$fit2 = predict(fit2, newdata = newdat)
newdat$fit3 = predict(fit3, newdata = newdat)
newdat$fit4 = predict(fit4, newdata = newdat)
newdat$fit5 = predict(fit4, newdata = newdat)
newdat$fit6 = predict(fit4, newdata = newdat)
lines(x=newdat$hurricanes, y=newdat$fit2, col="red")
lines(x=newdat$hurricanes, y=newdat$fit3, col="blue")
lines(x=newdat$hurricanes, y=newdat$fit4, col="purple")
lines(x=newdat$hurricanes, y=newdat$fit5, col="orange")
lines(x=newdat$hurricanes, y=newdat$fit6, col="darkgreen")
