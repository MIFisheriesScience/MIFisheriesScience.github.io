# Exercise2: Week6
# Lionfish offset example

library(visreg)

########################
# Offset example       #
########################

# Lionfish
# Best option: Convert density back to count, incorporate offset, use Poisson GLM
# Still need to check overdispersion tho

# Save for GLM-Poisson lecture

LF_Transects <- LF_Transects %>%
  mutate(PreyCount = PreyDensity*0.005) %>%
  mutate(area = 0.005)

LF_Transects$PercentageCover_scale <- scale(LF_Transects$PercentageCover)
LF_Transects$ShannonW_scale <- scale(LF_Transects$ShannonW)
LF_Transects$PredDensity_scale <- scale(LF_Transects$PredDensity)
LF_Transects$SubstrateHeight_scale <- scale(LF_Transects$SubstrateHeight)

# Specify full model a priori

full_mod <- glm(PreyCount ~ Culling + ShannonW_scale + PredDensity_scale + PercentageCover_scale + SubstrateHeight_scale 
                + Culling*PercentageCover_scale + offset(log(area)), family="poisson",
                data=LF_Transects)

# For comparison...
demo_mod <- glm(PreyDensity ~ Culling + ShannonW_scale + PredDensity_scale + PercentageCover_scale + SubstrateHeight_scale 
                + Culling*PercentageCover_scale, family="gaussian",
                data=LF_Transects)
AIC(full_mod, demo_mod) #Gaussian is what we did before. See AIC. Compare with Poisson GLM, using offset.
# Massive difference

#############################
# Begin model validation    #  
#############################

# What are assumptions of Poisson? 

# - Independence
# - Fixed X
# - No overdispersion
# - No patterns in residuals

# First, test overdispersion

E1 <- resid(full_mod, type = "pearson")
N  <- nrow(LF_Transects)
p  <- length(coef(full_mod))
sum(E1^2) / (N - p)

# 1.395 - minor overdispersion! No concern.

# Patterns in residuals?
###
# Plot Residuals vs. covariates in model

par(mfrow=c(2,3))
plot(residuals(full_mod) ~ Culling, data=LF_Transects)
abline(h=0, lty=2)
plot(residuals(full_mod) ~ ShannonW_scale, data=LF_Transects)
abline(h=0, lty=2)
plot(residuals(full_mod) ~ PredDensity_scale, data=LF_Transects)
abline(h=0, lty=2)
plot(residuals(full_mod) ~ PercentageCover_scale, data=LF_Transects)
abline(h=0, lty=2)
plot(residuals(full_mod) ~ SubstrateHeight_scale, data=LF_Transects)
abline(h=0, lty=2)
par(mfrow=c(1,1))

###
# Residuals vs. covariates NOT in model
plot(residuals(full_mod) ~ TransectID, data=LF_Transects)
abline(h=0, lty=2)
plot(residuals(full_mod) ~ Richness, data=LF_Transects)
abline(h=0, lty=2)

###
# Residuals vs time...

# NA - no time covariate in dataset

# ... and space 
# closest we have is Site
plot(residuals(full_mod) ~ Site, col=Culling, data=LF_Transects) 
#Definite Site pattern... 

# Hmm... The sites are definitely unique, and the model underpredicts 
# prey density in some, overpredicts in others. Suggests trouble.

###
# Plot residuals vs. fitted values

plot(residuals(full_mod) ~ fitted(full_mod))
abline(h=0, lty=2) #pretty good

####
# Conclude: 
# - Not overdispersed (Good)
# - But there is a pattern in these residuals driven by site

# Again, we struggle. Treatments not replicated across all sites

# This problem is unavoidable now.

# Proceed with model selection.
####

# I want to know: "What model best describes my data"?
# If the best model includes culling, conclude culling was effective and measure its effect

# Use: HYPOTHESIS TESTING, STEPWISE REDUCTION VIA Chi

drop1(full_mod, test="Chi") # Model is better if we drop SHannonW. Drop it
Reduced1 <- glm(PreyCount ~ Culling + PredDensity_scale + PercentageCover_scale + SubstrateHeight_scale 
                + Culling*PercentageCover_scale + offset(log(area)), family="poisson", data=LF_Transects)

drop1(Reduced1, test="Chi") # Model is better if we drop PredDensity. Just barely though
Reduced2 <- glm(PreyCount ~ Culling + PercentageCover_scale + SubstrateHeight_scale 
                + Culling*PercentageCover_scale + offset(log(area)), family="poisson", data=LF_Transects)

drop1(Reduced2, test="Chi") #Model better if we drop substrateheight
Reduced3 <- glm(PreyCount ~ Culling + PercentageCover_scale + 
                  Culling*PercentageCover_scale + offset(log(area)), family="poisson", data=LF_Transects)

drop1(Reduced3, test="Chi") # All terms significant. Use this model

Reduced_Model <- Reduced3 # for housekeeping

##################
# RE-VALIDATE    #
##################

summary(Reduced_Model)

# First, test overdispersion

E1 <- resid(Reduced_Model, type = "pearson")
N  <- nrow(LF_Transects)
p  <- length(coef(Reduced_Model))
sum(E1^2) / (N - p) #1.51. Right on the borderline. 
# We will say it's okay...

# Plot Residuals vs. covariates in model
par(mfrow=c(1,2))
plot(residuals(Reduced_Model) ~ Culling, data=LF_Transects)
abline(h=0, lty=2)

plot(residuals(Reduced_Model) ~ PercentageCover_scale, data=LF_Transects)
abline(h=0, lty=2)
par(mfrow=c(1,1))

###
# Residuals vs. covariates NOT in model
par(mfrow=c(2,3))
plot(residuals(Reduced_Model) ~ SubstrateHeight_scale, data=LF_Transects)
abline(h=0, lty=2)
plot(residuals(Reduced_Model) ~ ShannonW_scale, data=LF_Transects)
abline(h=0, lty=2)
plot(residuals(Reduced_Model) ~ PredDensity_scale, data=LF_Transects)
abline(h=0, lty=2)
plot(residuals(Reduced_Model) ~ TransectID, data=LF_Transects)
abline(h=0, lty=2)
plot(residuals(Reduced_Model) ~ Richness, data=LF_Transects)
abline(h=0, lty=2)
par(mfrow=c(1,1))

# Pretty good. May be minor trouble in PredDensity

###
# Residuals vs time...

# NA - no time covariate in dataset

# ... and space 
# closest we have is Site
plot(residuals(Reduced_Model) ~ Site, data=LF_Transects) 
# Trouble. Barry's Reef is a disaster - way different than the rest of the model
plot(residuals(Reduced_Model) ~ Site, col=Culling, data=LF_Transects) 

#Reminder:
plot(PreyDensity ~ Site,col=Culling,
     data=LF_Transects)

# I'm afraid there's not much we can do here. It is what it is
# Will need to write around this

summary(Reduced_Model)
par(mar=c(5,4,4,2))

# Visualize the model
Reduced_Model_Unscaled <- glm(PreyCount ~ Culling + PercentageCover + 
                                Culling*PercentageCover + offset(log(area)), family="poisson", data=LF_Transects)

visreg(Reduced_Model_Unscaled, "Culling", scale="response", by="PercentageCover", 
       xlab="Culling", ylab="Fish density", breaks=4, cond=list(area=1))
