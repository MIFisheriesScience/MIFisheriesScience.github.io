# FISH 6003 Week 6: Exercise 3: Binomial GLM

# Started 8 Feb, 2018

library(tidyverse)
library(car)
library(visreg)

source("./R/6003Functions.R")

# Data are from: 

# http://journals.plos.org/plosone/article?id=10.1371/journal.pone.0135348

#Alós J, Puiggrós A, Díaz-Gil C, Palmer M, Rosselló R, Arlinghaus R (2015) 
#Empirical evidence for species-specific export of fish naïveté 
#from a no-take marine protected area in a coastal recreational 
#hook and line fishery. PLOS ONE 10(8): e0135348. 
#https://doi.org/10.1371/journal.pone.0135348

# http://datadryad.org/resource/doi:10.5061/dryad.3b17f

# Load data

fish <- read.csv("./data/Alos2005.csv")

str(fish)

# Data are: 
# Species: Species of fish observed. These are fish targetted by anglers
# Event: 1 - Fish takes hook (would be killed). 0 - Fish does not take hook (would survive)
# Density_num: Density of other fish on video during biting attempt
# LT_s: Latency in Seconds between when the fish 
# Day: Density of other fish on video during biting attempt
# Distance_m: Density of other fish on video during biting attempt
# PCA 1 and 2 - These are principle components pertaining to habitat.
# Basically, mash together a bunch of habitat components into single covariates. 

# We're interested in:
# - Are fish in or near an MPA more likely to get killed than fish far away?

# Note: This isn't the exact same question they looked at in the paper.

head(fish)

# One row = One fish observation
# Observations are conducted with 10 minute underwater videos
# VideoID is not included in the dataset. But Day is.

fish$Day <- as.factor(fish$Day) # appropriate treatment of day

########################
# Verify all variables #
########################

# Are data types what they should be?
# Are there impossible values (numbers) or incorrect factor levels? (factors?)

# Species
levels(fish$Species) # good
# Are observations balanced?

table(fish$Species) # got at least 50 obs per species
# That's good - you need that for logistic regression

# Event
table(fish$Event) # good

# Density_num
plot(fish$Density_num) # Good
# Some weird patterns with later values. Were they ordered by density?

# LT_s
plot(fish$LT_s) #good

#Day  
plot(fish$Day) # Study apparently took place over four days


# confirmed by reading paper

# Distance_m
plot(fish$Distance_m)
abline(h=0)
# Per the paper: Negative values indicate INSIDE MPA. 
# 1000 m = 1000 m from the border on the outside
# -1000 m = 1000 m from the border on the INSIDE

# PCA 1 and 2
plot(fish$PCA1)
plot(fish$PCA2)

# Data verification complete. Proceed to exploration

#######################
# EXPLORATION         #
#######################

# Primary Q:

# Does distance from MPA border affect likelihood of the fish biting the hook?

# Potential things to put on X:

# - Species
# - Density_num
# - LT_s
# - Day
# - Distance_m
# - PCA 1 and 2

# Let's dump PCA 1 and 2 right off the bat because I have no ability to interpret them
# and it makes our example confusing.

#######################
# 1. Outliers Y and X #
#######################

#Y: event

dotchart(fish$Event) # no outliers b/c it's 1/0

# X:
par(mfrow=c(3,2))
plot(fish$Species)
dotchart(fish$Density_num)
dotchart(fish$LT_s)
dotchart(fish$Day)
dotchart(fish$Distance_m)
par(mfrow=c(1,1))
# No serious outliers

# 2. Homogeneity Y
# Check variance of Y against all categorical covariates
# (Site and Culling)

p <- ggplot(data=fish, aes(x=Day, y=Event)) +
  geom_boxplot() + facet_wrap(~Species)
p

#These data are zeroes and ones

# 3. Normality Y
hist(fish$Event) 
# These data are zeroes and ones

# 4. Zero trouble Y

sum(fish$Event == 0) #about half the data are zeroes
#... but data are zeroes and ones

# 5. Collinearity X

pairs(~ Species + Day + Density_num + LT_s + Distance_m, 
      lower.panel=panel.smooth, upper.panel=panel.cor, 
      #additional code to make function work
      data=fish) 
# Happy day - no collinearity

# 6. Relationships Y and X

# Plot all covariates against Y

p <- ggplot(data=fish, aes(x=Species, y=Event)) + geom_boxplot() 
q <- ggplot(data=fish, aes(x=Day, y=Event)) + geom_boxplot()
r <- ggplot(data=fish, aes(x=Density_num, y=Event)) + geom_point()+ stat_smooth()
s <- ggplot(data=fish, aes(x=LT_s, y=Event)) + geom_point()+ stat_smooth()
t <- ggplot(data=fish, aes(x=Distance_m, y=Event)) + geom_point()+ stat_smooth()

multiplot(p,q,r,s,t, cols = 3)
# Nothing obvious. Interesting dip in event vs. latency


# 7. Interactions

coplot(Event ~ Density_num | Species+Day,
       data=fish,
       panel=function(x,y,...) {
         panel.smooth(x,y,span=0.8,iter=5,...)
         abline(lm(y ~ x), col="blue") } )

coplot(Event ~ LT_s | Species+Day,
       data=fish,
       panel=function(x,y,...) {
         panel.smooth(x,y,span=0.8,iter=5,...)
         abline(lm(y ~ x), col="blue") } )

coplot(Event ~ Distance_m | Species+Day,
       data=fish,
       panel=function(x,y,...) {
         panel.smooth(x,y,span=0.8,iter=5,...)
         #abline(lm(y ~ x), 
         #col="blue") 
         } )
# A few things:
# - Some days are missing some species
# - Some day x species combos have way fewer observations than others
# Definite imbalance in X's across days and species

# 8. Independence Y

# There's no magical test for 'independence.' We need to consider the structure of our data.

# Sketch study design

# Observations nested within videos (can't account for that)
# - Not clear if one fish observation interacts with other fish observations in a video
# Videos nested within days

# We will incorporate Day into the model and hope for the best

# EXPLORATION CONCLUSIONS:
# - Y is 1/0
# - Proceed with binomial GLM

#######################
# END EXPLORATION     #
#######################

#######################
# BEGIN ANALYSIS      #
#######################

full_mod <- glm(Event ~ Species + Day + Density_num + LT_s + Distance_m, 
                family="binomial", data=fish)

summary(full_mod)

#######################
# Validate full model #
#######################

# - Fixed X: Yes
# - Independence: Account for this by maintaining "Day" in the model
# - Residuals vs fitted

# Plot residuals against covariates that are, and are not, in the model

plot(residuals(full_mod) ~ Species, data=fish) # Way less variation in first species
plot(residuals(full_mod) ~ Day, data=fish)
plot(residuals(full_mod) ~ LT_s, data=fish)
plot(residuals(full_mod) ~ Density_num, data=fish)
plot(residuals(full_mod) ~ Distance_m, data=fish)

# Commence backward selection

# Why? This is a case where we really don't know what is driving our system
# Model selection will exclude 'unimportant' variables

# IT's very hard to interpret these for logistic regression

# Proceed

drop1(full_mod, test="Chi") # Remove Density_num

Reduced1 <- glm(Event ~ Species + Day + LT_s + Distance_m, 
                family="binomial", data=fish)

drop1(Reduced1, test="Chi") # Day is NS
# Two options:
# Day is important because I say so. (i.e. I have an a priori reason
# to leave it in). 
# Drop Day

# We will drop it

Reduced2 <- glm(Event ~ Species + LT_s + Distance_m, 
                family="binomial", data=fish)

drop1(Reduced2, test="Chi") 

Reduced_Model <- Reduced2

##########################
# Validate Reduced_Model #
##########################

vif(Reduced_Model)

# - Fixed X: Yes
# - Independence: Day was found to be unimportant. Remove
# - Residuals vs fitted

# Plot residuals against covariates that are, and are not, in the model

#Are

plot(residuals(Reduced_Model) ~ Species, data=fish) # Way less variation in first species
plot(residuals(Reduced_Model) ~ LT_s, data=fish)
plot(residuals(Reduced_Model) ~ Distance_m, data=fish)

# Are not
plot(residuals(Reduced_Model) ~ Density_num, data=fish)

###
# Residuals vs time...
plot(residuals(Reduced_Model) ~ Day, data=fish) # Still happy to leave Day out?
# If this were a paper, I probably wouldn't leave it out
# Since this is an exercise and it makes interpretation easier, I
# will leave it out

# Residuals vs. fitted
plot(residuals(Reduced_Model) ~ fitted(Reduced_Model), data=fish)

##############
# Interpret  #
##############

summary(Reduced_Model)

(1-exp(-8.365e-5))*100

visreg(Reduced_Model, scale="response")


                          