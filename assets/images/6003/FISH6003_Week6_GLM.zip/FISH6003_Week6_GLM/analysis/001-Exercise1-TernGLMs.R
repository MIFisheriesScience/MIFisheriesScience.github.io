# Code for FISH 6003 Week 6 lecture

# Brett Favaro
# Started Feb 5, 2018

library(tidyverse)
library(MASS)
library(visreg)

source("./R/6003Functions.R")

terns <- read.csv("./data/6003_terns.csv")

# data from: https://peerj.com/articles/3287/

# wrecks = dead birds in a given two-week period
# hurricanes = # of hurricanes in a two week period

# Skip data verification because dataset is very simple

# Recall our LM

mod <- lm(wrecks ~ hurricanes, data=terns)
summary(mod)

a <- ggplot(data=terns, aes(x=hurricanes, y=wrecks)) +
  theme_bw() +
  geom_point() +
  geom_smooth(method="lm", se=TRUE, color="darkgrey") 

a

mean(terns$wrecks)

# Interlude: Plot a poisson distribution

par(mfrow=c(2,2))

x <- rpois(n=1000, lambda=1)
plot(table(x), xlab="Count", ylab="Frequency", main="Mean = 1")
x <- rpois(n=1000, lambda=3)
plot(table(x), xlab="Count", ylab="Frequency", main="Mean = 3")
x <- rpois(n=1000, lambda=5)
plot(table(x), xlab="Count", ylab="Frequency", main="Mean = 5")
x <- rpois(n=1000, lambda=15)
plot(table(x), xlab="Count", ylab="Frequency", main="Mean = 15")

par(mfrow=c(1,1))

# Fit a poisson GLM

mod2 <- glm(wrecks ~ hurricanes, data=terns,
            family="poisson")
summary(mod2)
exp(0.126)

confint(mod, level=0.95)
confint(mod2, level=0.95)

exp(confint(mod2, level=0.95))

exp(0.126)
#######
# Plot the poisson GLM
########

a <- ggplot(data=terns, aes(x=hurricanes, y=wrecks)) +
  theme_bw() +
  geom_point() +
  geom_smooth(method="glm", method.args=list(family="poisson"), 
              se=TRUE)

a

mod2.pois <- glm(wrecks ~ hurricanes, data=terns,
                 family="poisson")

SuperScatter(terns$hurricanes, terns$wrecks, ymin=-10, ymax=40, mod, distribution_type = "Gaussian")

SuperScatter(terns$hurricanes, terns$wrecks, ymin=-10, ymax=40, mod2.pois, distribution_type = "Poisson")

#Note:
AIC(mod, mod2.pois)

# poisson is already working better


####################
# VALIDATE POISSON #
####################

# Test for overdispersion
mod2.pois <- glm(wrecks ~ hurricanes, data=terns,
                 family="poisson")

# Explained deviance:

(125.619 - 45.249)/125.619




# Plot:
# Residuals vs covariates in the model

plot(residuals(mod2.pois) ~ terns$hurricanes)
abline(h=0, lty=2)

# Residuals vs covariates NOT in the model
#NA - can't do

# Residuals vs time/space
# NA - can't do

# Residuals vs fitted values
plot(residuals(mod2.pois) ~ fitted(mod2.pois))
abline(h=0, lty=2)


E1 <- resid(mod2.pois, type = "pearson")
N  <- nrow(terns)
p  <- length(coef(mod2.pois))
sum(E1^2) / (N - p) 

# Anything > 1 = overdispersed Ours is 3

# Why do we have overdispersion?
# A. Outliers Y
# B. Missing covariates?  
# C. Missing interactions?
# D. Zero inflation?     
# E. Dependency?     
# F. Non-linear patterns  
# G. Wrong link function   

###

# A. Outliers Y
# Should have already done this in data exploration

dotchart(terns$wrecks) # we could get rid of the biggest values...
# Why would we? Why would we not?

plot(cooks.distance(mod2.pois), type = "h", ylim = c(0, 1),
     xlab="Observation number",
     ylab="Cook's distance")
abline(h = 1, col = 2,lwd = 3)

# These two variables ARE highly influential on the model...

# For the sake of this exercise, let's say we do NOT want to remove these
# They are part of the process we want to measure. Therefore we don't remove.

# B. Misisng covariates?

# Possibly, but we don't have additional covariates to test

# C. Missing interactions?

# Possibly, but we don't have additional covariates to test

# D. Zero inflation?

table(terns$wrecks==0)

100 * sum(terns$wrecks==0) / nrow(terns)  #=18%

# 18% of our data are zeroes. Potential trouble
# Zuur et al. 2012 is a book that deals entirely with this

# E. Dependency

# Hope not... we can't check anyway

# F. Non-linear patterns

F1 <- fitted(mod2.pois)

plot(y = terns$wrecks, 
     x = F1,
     xlab = "Fitted values",
     ylab = "Observed data",
     cex.lab = 1.5,
     xlim = c(0,30), 
     ylim = c(0,30))
abline(coef = c(0, 1), lty = 2)   

# No non-linear patterns
# Note that we have fewer than 50 observations. a GAM won't work anyway

# G. Wrong link function

# No. This is Poisson so log-link is correct.

#CONCLUDE:

# Why do we have overdispersion?
# A. Outliers Y - Maybe. 
# B. Missing covariates? - N/A
# C. Missing interactions? - N/A
# D. Zero inflation? - Maybe
# E. Dependency? - N/A
# F. Non-linear patterns - No
# G. Wrong link function - No

# Actions;
# - Do not remove outliers
# - Use a model that can handle more zeroes:

# NEGATIVE BINOMIAL!!

# Note:

# Another option is to use a "quasi-poisson" model. HEre's what that looks like:

mod2.pois2 <- glm(wrecks ~ hurricanes, data=terns,
                  family="quasipoisson")
summary(mod2.pois2)

summary(mod2.pois)
# Quasipoisson adjusts the standard errors, not the coefficients.

# But overdispersion actually affects coefficients

# If overdispersion is low (<10) you may use quasipoisson if you have a very strong effect

0.154-(1.96*0.02825)

###################
# NegBin start    #
###################

# What's a negative binomial GLM?
#
par(mfrow=c(3,3))

x <- rnbinom(n=1000, size = 0.1, mu=3)
plot(table(x), xlab="Count", ylab="Frequency", main="mu = 3, theta = 0.1")
x <- rnbinom(n=1000, size = 1, mu=3)
plot(table(x), xlab="Count", ylab="Frequency", main="mu = 3, theta = 1")
x <- rnbinom(n=1000, size = 1000, mu=3)
plot(table(x), xlab="Count", ylab="Frequency", main="mu = 3, theta = 1000")

x <- rnbinom(n=1000, size = 0.1, mu=15)
plot(table(x), xlab="Count", ylab="Frequency", main="mu = 15, theta = 0.1")
x <- rnbinom(n=1000, size = 1, mu=15)
plot(table(x), xlab="Count", ylab="Frequency", main="mu = 15, theta = 1")
x <- rnbinom(n=1000, size = 1000, mu=15)
plot(table(x), xlab="Count", ylab="Frequency", main="mu = 15, theta = 1000")

x <- rnbinom(n=1000, size = 0.1, mu=50)
plot(table(x), xlab="Count", ylab="Frequency", main="mu = 50, theta = 0.1")
x <- rnbinom(n=1000, size = 1, mu=50)
plot(table(x), xlab="Count", ylab="Frequency", main="mu = 50, theta = 1")
x <- rnbinom(n=1000, size = 1000, mu=50)
plot(table(x), xlab="Count", ylab="Frequency", main="mu = 50, theta = 1000")

par(mfrow=c(1,1))

#################
# Run the model #
#################

mod3.nb <- glm.nb(wrecks ~ hurricanes, data=terns)
summary(mod3.nb)

(46.678-17.129)/47.678


a <- ggplot(data=terns, aes(x=hurricanes, y=wrecks)) +
  theme_bw() +
  geom_point() +
  geom_smooth(method = MASS::glm.nb, color=2, se = TRUE) 
# Note the NB smoother line is not built into GGPLOT2 by default

a

SuperScatter(terns$hurricanes, terns$wrecks, ymin=-10, ymax=40, mod3.nb, distribution_type = "NegBin")

# VALIDATION

# Residuals vs covariates in the model

plot(mod3.nb$residuals ~ terns$hurricanes)
abline(h=0, lty=2)

# Residuals vs covariates NOT in the model
#NA - can't do

# Residuals vs time/space
# NA - can't do

# Residuals vs fitted values
plot(mod3.nb$residuals ~ fitted(mod3.nb))
abline(h=0, lty=2)


#####################
# Compare models    #
#####################

AIC(mod, mod2.pois, mod3.nb)

exp(0.154)

exp(-0.006)

residuals(mod3.nb)
mod3.nb$resid





