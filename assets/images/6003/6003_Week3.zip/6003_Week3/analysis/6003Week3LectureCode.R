# Code for FISH 6003 Week 3 lecture

# Brett Favaro
# Started Jan 19, 2018

library(tidyverse)
source("./R/6003Functions.R")

terns <- read.csv("./data/6003_terns.csv")

# data from: https://peerj.com/articles/3287/

# wrecks = dead birds in a given two-week period
# hurricanes = # of hurricanes in a two week period

# Skip data verification because dataset is very simple

fit <- lm(wrecks ~ hurricanes, data=terns)
summary(fit)
terns$predicted <- predict(fit)
terns$residuals <- residuals(fit)

# Basic scatterplot
a <- ggplot(terns, aes(x = hurricanes, y = wrecks)) +
  geom_point() + theme_bw() 
a

# Add an lm

a + geom_smooth(method="lm", se=FALSE, color="darkgrey")

# Without lm, but with predicted values 

a + geom_point(aes(y=predicted), shape=1, color="blue")

# With a loess smoother

a + geom_smooth()

# with predicted values + residuals

a + geom_point(aes(y=predicted), shape=1, color="blue") +
  geom_segment(aes(xend=hurricanes, yend=predicted), alpha=0.5, color="red")

# WIth line and residuals

a + geom_segment(aes(xend=hurricanes, yend=predicted), alpha=0.5, color="red") +
  geom_smooth(method="lm", se=FALSE, color="blue")

# With residuals visualized as actual squares

x1 <- terns$hurricanes
x2 <- terns$hurricanes+terns$residuals
y1 <- terns$predicted
y2 <- terns$predicted+terns$residuals

a + geom_smooth(method="lm", se=FALSE, color="blue") +
  geom_rect(aes(xmin=x1, ymin=y1, xmax=x2, ymax=y2), alpha=0.5)

#Calculate residual sum of squares

rss <- sum(residuals(fit)^2)
rss

##################### 
# Model exploration #
#####################

summary(fit)

# plot model only

a <- ggplot(terns, aes(x = hurricanes, y = predicted)) +
  theme_bw() 
a

a + geom_point(shape=1, color="blue")
a + geom_smooth(method="lm", se=FALSE, color="darkgrey")

std <- sd(terns$residuals)

# Plot model, points, and an equation for the line

a <- ggplot(terns, aes(x = hurricanes, y = wrecks)) + 
  geom_point() +
  theme_bw() +
  geom_smooth(method="lm", se=FALSE, color="darkgrey") +
  geom_text(x = 8, y = 23, label=lm_eqn(fit), parse=TRUE, size=6) #This code puts the regression equation on the plot
a

# Plotting confidence intervals and prediction intervals

# 95% CI

CIs <- predict(fit, interval="confidence", level = 0.95)

lwr <- CIs[,2]
upr <- CIs[,3]

PIs <- predict(fit, interval="prediction", level=0.95)

plwr <- PIs[,2]
pupr <- PIs[,3]

# 95% CI
a <- ggplot(terns, aes(x = hurricanes, y = wrecks)) +
  theme_bw() + geom_smooth(method="lm", se=FALSE, color="darkgrey")

a + geom_line(aes(y=upr, x=terns$hurricanes), col="red") + 
  geom_line(aes(y=lwr, x=terns$hurricanes), col="red") + 
  geom_text(x=5, y=10, aes(label="95% CI"), size=8, color="red") + 
  geom_point(aes(y=terns$wrecks, x = terns$hurricanes))

# 95% PI

a + geom_line(aes(y=upr, x=terns$hurricanes), col="red") + 
  geom_line(aes(y=lwr, x=terns$hurricanes), col="red") + 
  geom_text(x=5, y=10, aes(label="95% CI"), size=8, color="red") + 
  geom_point(aes(y=terns$wrecks, x = terns$hurricanes)) +
  geom_line(aes(y=plwr, x=terns$hurricanes), col="blue") + 
  geom_line(aes(y=pupr, x=terns$hurricanes), col="blue") + 
  geom_text(x=5, y=20, aes(label="95% PI"), size=8, color="blue") 

#############
# Calculate spread of residuals 
#################

sqrt(sum(residuals(fit)^2) / df.residual(fit))

################
# Correlation
################

r <- cor(x = terns$hurricanes, y=terns$wrecks, method="pearson")
r^2

##############
# Anova      #
##############

anova(fit)

###############
# Residuals   #
###############

boxplot(residuals(fit), horizontal=TRUE)

hist(residuals(fit), breaks=10)

#################
# Simulating    #
#################

# Simple visualization of the model

plot(wrecks ~ hurricanes, 
      data=terns, pch=16,
     ylim=c(-10, 25))
abline(fit, col="darkgrey", lwd=2)


# Simulate and add to plot
md <- seq(0, 25, length = 12)
Beta <- coef(fit)
for (i in 1:12){
  mu <- Beta[1] + Beta[2] * md[i]
  yi <- rnorm(50, mean = mu, sd = summary(fit)$sigma)
  points(x = jitter(rep(md[i], 50)), 
         y = jitter(yi), 
         col = grey(0.5), 
         pch = 16, 
         cex = 1)
}
abline(h = 0, lty=2)

###############################
# Final model visualization   #
###############################

CIs <- predict(fit, interval="confidence", level = 0.95)

lwr <- CIs[,2]
upr <- CIs[,3]

a <- ggplot(data=terns, aes(x=hurricanes, y=wrecks)) +
  theme_bw() +
  geom_point() +
  geom_smooth(method="lm", se=FALSE, color="darkgrey") 

# Option 1: ggplot2 calculates CIs

a + geom_smooth(method=lm, se=TRUE) #se = confidence interval

# Option 2: Use our CI's plotted above

a + geom_line(aes(y=upr, x=terns$hurricanes), col="red") + 
  geom_line(aes(y=lwr, x=terns$hurricanes), col="red") 

############################
# Making a bunch of lines  #
############################

plot.new()
axis(1)
axis(2)
abline(a = 0, b = 1)

plot.new()
axis(1)
axis(2)
abline(a = 0.5, b = 1, col="blue")


plot.new()
axis(1)
axis(2)
abline(a = 0, b = 2, col="red")

plot.new()
axis(1)
axis(2)
abline(a = 0.5, b = 2, col="darkgreen")

################################
# Linear model of just a mean  #
################################

minimal <- lm(terns$wrecks ~ 1)
summary(minimal)

mean(terns$wrecks)

sd(terns$wrecks)/sqrt(length(terns$wrecks))

#############################################
# FICTION: Turn hurricanes into a category  #
#############################################
median(terns$hurricanes) # Split it into above and below 7

terns2 <- terns %>%
  mutate(numstorms = ifelse(hurricanes < 5, "Level 1 (<5)", 
                            ifelse(hurricanes < 13, "Level 2 (6-12)", "Level 3 (14-23)")))

terns2$numstorms <- as.factor(terns2$numstorms)

plot(wrecks~numstorms, 
     data=terns2, xlab="Number of storms (categorical)")

categorical_lm <- lm(wrecks ~ numstorms, data=terns2)

summary(categorical_lm)



