# FISH 6003: Week 1 Plots

# Started: Jan 14, 2018

# Note: 001DataSetup.R must be run prior to this script.

# This is a very limited dataset. Just do basic exploration.

# 1. Boxplot 

p <- ggplot(data=IntroData, aes(x=species, y = length_cm)) + 
  geom_boxplot() + coord_flip()

p

# What does a boxplot mean? Let's zoom in on just atlantic salmon

tempdata <- filter(IntroData, species=="atlantic_salmon")

r <- ggplot(data=tempdata, aes(x=species, y=length_cm)) +
  geom_boxplot() + coord_flip()

r

table(tempdata$length_cm)

# 2. Histogram

r <- ggplot(data = IntroData, aes(x = length_cm)) +
    geom_histogram(binwidth=5) + facet_grid(. ~ species, scales="free")
  
r

median(tempdata$length_cm)
summary(tempdata$length_cm)


IQR(tempdata$length_cm)
help(geom_boxplot)
