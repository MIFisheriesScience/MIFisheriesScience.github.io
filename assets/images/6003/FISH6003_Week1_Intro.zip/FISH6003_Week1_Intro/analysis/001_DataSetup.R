# FISH 6003: Week 1 Data Setup

# Started: Jan 14, 2018

library(tidyverse)

# Note the syntax below: "./data" means:
# [root]/[data]/filename.csv

IntroData <- read.csv("./data/6003-1-introdata.csv") 

# Did it load correctly?

head(IntroData)
str(IntroData)

# The variables are:
# fishid: One identifier per fish
# species: Common name of the species being measured
# length_cm: total length of fish being measured.

# One row --> one fish

############################
# FIRST: Verify data       #
############################
# Are data types what they should be?
# Are there impossible values (numbers) or incorrect factor levels? (factors?)

# fishid: Integer. One unique ID number per fish. 

range(IntroData$fishid) # Looks fine

# Check for duplicates (there shouldn't be any)

# Option 1: Look manually (okay for small datasets)
plot(IntroData$fishid) # Duplicates? 
table(IntroData$fishid) # Alternate way to check for duplicates
plot(table(IntroData$fishid)) # Yet another way

# Option 2: Look automatically for anything that appears more than once

IntroData %>% # Do stuff to IntroData
  group_by(fishid) %>% # 1. Group by the fish id
  filter(n() > 1) # 2. Return anything that occurs more than once

# Option 3: Option 2, but written in base R code

X <- as.data.frame(table(IntroData$fishid)) # Alternate presentation of same data
X

subset(X, X$Freq > 1) # Show only when there is more than 1 instance of something

# There are no duplicates. Life is good.

# fishid good

# species: Factor. Two levels

levels(IntroData$species) # Check factor levels. Make sure no spelling errors

# species good

# length_cm: integer. Check values

range(IntroData$length_cm) # Fish length 

# That's an awfully wide range. 

# Q: Why is range so wide? Could this be an error?
# A: There are two species. Need to check values across species

plot(IntroData$length_cm) # Can clearly see the two clusters

# Parse it out by species:
p <- ggplot(IntroData, aes(x = species, y = length_cm)) 

p + geom_jitter() 

# Another alternative
p + geom_violin() + coord_flip()

# Are these reasonable values?
# 1. If you collected the data - you know the answer
# 2. If you were GIVEN the data - ask the author, or check FishBase.org

# These values are fine

# Data verification complete. Move on to analysis
