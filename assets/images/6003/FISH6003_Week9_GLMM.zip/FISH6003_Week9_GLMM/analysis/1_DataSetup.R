# FISH 6003: Week 9 Data Setup
# Green crab bait choice study 
# Data setup

# Unpublished data collected by:
# Mary Alliston Butt
# Jonathan Bergshoeff

# Started: March 7, 2018

library(tidyverse)
library(lubridate)
library(raster)
library(maptools)
library(rgdal)
library(mapproj)

source("./R/6003Functions.R")

# Load the data files

Catch <- read.csv("./data/MAB_Overview.csv")

BodySizes <- read.csv("./data/MAB_BodySizes.csv")

Locations <- read.csv("./data/MAB_Positions.csv")

#################### 
# Check variables  #
####################
str(Catch)

# TrapID = ID number of each trap used in the study
# Bait = Bait type
# Block = Sampling block in the study
# Slot = Four pots were deployed per block. Within each block four "slots" were defined.
# Position = Redundant. It's just block and slot expressed as a single variable
# Date.In = Date of deployment
# Time.Set = Time of day deployment started
# Date.Out = Date of retrieval
# Time.Hauled = Time of retrieval
# Total.Catch = number of green crabs in the trap on retrieval
# Location = Fox Harbour (FH) or North Harbour (NH)

str(BodySizes)

# TrapID = Connection to Catch dataset. Same ID
# BaitType = Cod, mussels, squid, herring
# Block = A, B, C, D
# Sex = Male or female 
# CW = Carapace Width
# Eggs = Did the crab have eggs or not, if it was female?

str(Locations)
# This file gives us the GPS positions of each place the pots were deployed

# Position = A1 A2 etc. It's block plus slot
# Lat = Latitude
# Long = Longitude
# GPS.Mark = Not meaningful. Can be deleted.

#############################
# Verify all data           #
#############################

# Save the untidy data frames if we need to restore them later

CatchUntidy <- Catch
BodySizesUntidy <- BodySizes
LocationsUntidy <- Locations

# Are data types what they should be?
# Are there impossible values (numbers) or incorrect factor levels? (factors?)

# FIRST: Catch

str(Catch)

# TrapID
# It's an integer but should be a factor (it's a label, after all)

Catch$TrapID <- as.factor(Catch$TrapID)
length(levels(Catch$TrapID)) # 176 levels
levels(Catch$TrapID) # 1st level is 1, last level is 176. Seems good

# Make sure there are no duplicates
plot(table(Catch$TrapID)) #good

Catch %>% #Another way to check. Return only rows with the same code appearing more than once
  group_by(TrapID) %>%
  filter(n() > 1) # Nope

# Bait

levels(Catch$Bait) # Cool

# Block

levels(Catch$Block) # Cool

# Slot

levels(Catch$Slot) #Oops, it's not a factor
Catch$Slot <- as.factor(Catch$Slot)

levels(Catch$Slot) #Good

# Date.In, Time.Set, Date.Out, Time.Hauled
# All four of these are date and time units. 

# We want to give ourselves the option of including "soak time" as a covariate
# To do that, we will have to do some data manipulation

# First, let's create two variables; Start and End, which will include both
# the date and time of the start of the deployment, and the end of the deployment

# See: http://r4ds.had.co.nz/dates-and-times.html 

Catch <- Catch %>% 
  mutate(Start = paste(Date.In, Time.Set, sep = " ")) %>%
  mutate(End = paste(Date.Out, Time.Hauled, sep = " "))

# Next, let's turn these new variables into Lubridate objects

Catch$Start <- dmy_hm(Catch$Start, tz="America/St_Johns")
Catch$End <- dmy_hm(Catch$End, tz="America/St_Johns")

# Now, make a new variable called SoakTime - The time between start and end

# Quick aside. Note the difference between:

head(as.duration(Catch$End - Catch$Start))
head(Catch$End - Catch$Start)
head(as.numeric(Catch$End - Catch$Start))

# Let's use soak time as expressed by hours. 
Catch <- Catch %>%
  mutate(SoakTime = as.numeric(End - Start)) # Returns a precise value in seconds

# This will be useful later on, as a potential covariate in our model.

# BACK TO VERIFICATION

# Total.Catch

plot(Catch$Total.Catch) 
range(Catch$Total.Catch)

# No impossible values. No obvious entry errors

# Location

levels(Catch$Location) #All good

# VERIFICATION COMPLETE

### 
# Verify second data frame: BodySizes
###

str(BodySizes)

# Here, one row = one crab

# TrapID
BodySizes$TrapID <- as.factor(BodySizes$TrapID)
levels(BodySizes$TrapID) #Now, duplicates are okay

# Some TrapID levels may be missing. 
range(Catch$Total.Catch) # Recall that we have some traps that caught no crabs

# Therefore we would not expect all TrapIDs to be represented here.

# Block

levels(BodySizes$Block) # Nice

# Sex

levels(BodySizes$Sex) # oops. Entry errors

BodySizes$Sex <- recode(BodySizes$Sex, "M " = "M") 
# What's up with the blanks?

plot(BodySizes$Sex)
table(BodySizes$Sex) # Just one with missing sex. Get rid of it.

BodySizes <- filter(BodySizes, Sex != "") # Drops a single value
# Don't forget to include this in methods

# CW (Carapace Width)

range(BodySizes$CW) # Oh no, a factor! There must be a character in there somewhere

which(
  is.na(
    as.numeric(
      as.character(BodySizes$CW)
    )
  )
) # Uh oh, looks like lots of values include text. What's going on?

plot(BodySizes$CW) #Ah, there's something called "ND"

# These are values for which the carapace width data were lost.

# We will have no choice but to drop these.

BodySizes <- filter(BodySizes, CW != "ND") #drops 1311 values.
# No choice but to cop to this. We mishandled the last 1311 records of CW
# Alternate wording to use in the paper: "We recorded the CW of all crabs in the first 160 pots only"

# That statement is TRUE, does not emphasize that we INTENDED to record all data but didn't do so.

# Things happen in the field. Most people understand this.

# But don't make it a habit to lose data.

# Check again - did this fix our problem?
which(
  is.na(
    as.numeric(
      as.character(BodySizes$CW)
    )
  )
)
# Yup! Convert it to a character, and then a number

BodySizes$CW <- as.numeric(as.character(BodySizes$CW))

range(BodySizes$CW)
plot(BodySizes$CW) # Nice. Looks like a reasonable range of data

### 
# Verify third data frame: Locations
###

str(Locations)

#Position
levels(Locations$Position) #Fine

# Lat
range(Locations$Lat) #ok

# Long
range(Locations$Long) #ok

# GPS.Mark
range(Locations$GPS.Mark) #This doesn't mean anything. Let's get rid of it.

Locations <- select(Locations, -GPS.Mark) #Feels good to be tidy.

# One final check... do these lats and longs make sense?

plot(Locations$Lat ~ Locations$Long) # Doesn't tell us anything. 
# Put on your cartography hat because it's map time.

#########################################
# The rest of this code is for maps     #
#########################################

mapdata <- getData("GADM", country="CAN", level = 2)

region <- (mapdata[mapdata$NAME_1=="Newfoundland and Labrador",]) 

a <- ggplot() +
  geom_polygon(data=region, aes(long, lat, group=group)) +
  coord_map(xlim = c(-55,-53), ylim=c(47.25 ,47.9)) +
  geom_point(data=Locations, aes(x=Long,y=Lat), colour="yellow", size=6)

a

# Remember - we are still in the data setup step. 

# This tells me that the lats and longs are in reasonable places
# They do occur in NL, and appear to fall on the water

# This is NOT the map we would publish, nor would we make any inference based on it

# Data setup complete. We may proceed with analysis

