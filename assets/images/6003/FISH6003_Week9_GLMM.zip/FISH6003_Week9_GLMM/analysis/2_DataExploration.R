# FISH 6003: Week 9 Data Exploration
# Green crab bait choice study 
# Data Exploration

# Unpublished data collected by:
# Mary Alliston Butt
# Jonathan Bergshoeff

# Started: March 8, 2018

##########################################
# RUN EVERYTHING IN 1_DATASETUP.R FIRST  #
##########################################

##############
# Preamble   #
##############

# In this study we are interested in whether different baits
# produce different catch per unit effort (CPUE) of green crab

# We have two response variables:
# Y: Number of Green Crab caught per trap (Count)
# Y: Body size of green crab (continuous, zero-truncated)

# We have a number of covariates:
# Bait - our primary covariate of interest

# Also:
# Block, slot, location (Fox Harbour or North Harbour), soak duration, Dates and times, TrapID

##
# The simplest analysis would be a simple linear model:

 # Catch_i ~ Beta_0 + Bait

# But recall assumptions:
# - Normality (No. Catch is a count)
# - Homogeneity of variance (Need to explore)
# - Fixed X (yes)
# - Independence (No - catch nested within block/slot, and site)

# For body size:

# - Normality (Maybe, must test)
# - Homogeneity of variance (maybe, must test)
# - Fixed X (yes)
# - Independence (No. Crabs are nested within trap. Traps are nested within block/slot and site.)

##
# We will definitely need a model that incorporates nested structure of data

# We will definitely need different distributions for Y (GLMM Poisson for count, GLMM Gaussian for size)

############################
# Begin data exploration   #
############################

# 1. Outliers Y and X
# 2. Homogeneity Y
# 3. Normality Y
# 4. Zero trouble Y
# 5. Collinearity X
# 6. Relationships Y and X
# 7. Interactions
# 8. Independence Y

###########################
# 1. Outliers Y and X     #
###########################

# Y

dotchart(Catch$Total.Catch, main="Total Catch Per Deployment") 
dotchart(BodySizes$CW, main="Carapace Width (cm)")

# No obvious outliers in either

# X

# Bait

table(Catch$Bait) # ok

# Block 

table(Catch$Block) # hmm... fewer C and D

# Slot

table(Catch$Slot) # ok

# Location

table(Catch$Location) #more in Fox Harbour and North Harbour

# You should be getting uneasy about these site variables right now. 
# Hang on to that feeling. Come back to it at collinearity.

# Deployment date and time

plot(Catch$Start) # Recall that these are lubridate items, so R 
# is handling the data elegantly. 

# Those August dates are pretty far apart from the rest of the data. 
# Should we exclude them?
# Let's plot the total catch by date to see if that last clump of dates
# produced very different catch rates

plot(Catch$Total.Catch ~ Catch$Start, col=Catch$Location) 
# Colour is location (FH or NH)

# okay... This is a tricky situation. The gap between 1st and 2nd sampling periods
# is about the same as gap between 2nd and 3rd. That would be an argument to keep it

# However, if we are comparing catch vs. site, 
# then that date outlier will introduce significant complication

# Per Zuur: We can eliminate 5% of our dataset without much concern
# So what percent falls in that Aug sampling?

table(month(Catch$Start)) #There were only three august dates in the sampling 

24/sum(table(month(Catch$Start))) # 13% of our dataset is from August
# Shoot. Need a pretty good reason to eliminate it.

# One reason to exclude would be if the weather was very different in Aug vs July, 
# because we know a priori that temperature affects crab activity and catchability

# See:
# June: https://www.timeanddate.com/weather/@5956901/historic?month=6&year=2016 11 C
# July: https://www.timeanddate.com/weather/@5956901/historic?month=7&year=2016 15 C
# August: https://www.timeanddate.com/weather/@5956901/historic?month=8&year=2016  16 C

# Although the air temperature is similar, it's possible the water temperature was quite different

# My preference is to exclude those August dates because:
# - No temporal adjacency to the rest of the data
# - Y was quite different in Aug than in the rest of the data - both mean and variance

# Back to data exploration. Recall that we are looking for outliers. 

# Soak time

dotchart(Catch$SoakTime, main="Soak time (h)")

# We should drop anything with a soak time below 20 hrs

# Actions taken as a result of Outlier exploration:
# 1. Drop short sets
# 2. Drop August sets

Catch_Tidy <- Catch %>%
    filter(SoakTime > 22) %>% # 12 traps
    filter(month(Start) != 8) # 24 traps
# dropped 36/176 traps due to this decision. Remaining sample size = 140

# Reminder; We must drop the appropriate levels from BodySizes too

# First create a vector with only the traps that remain
RemainingTraps <- droplevels(Catch_Tidy$TrapID)

BodySizes_Tidy <- BodySizes %>%
  filter(TrapID %in% RemainingTraps) #select only the TrapIDs that occur in RemainingTraps

# We're down to 4143 CW's now.

# Use Catch_Tidy and BodySizes_Tidy going forward



###########################
# 2. Homogeneity Y        #
###########################

##############
# PAUSE!!    #
##############

# Let's simplify block, slot, etc. Let's just use Position 
# - A1, A2, A3, A4, B1, B2, B3, B4, etc.
# This study was done in a small bay. The positions aren't all that far from each other.
# Instead of A1, A2, A3, A4, B1, etc. we COULD have just called it 1, 2, 3, 4, 5, etc.

# The A's and B's are not replicated across sites. It's just a term of convenience
# So from now on we will use two variables to tell us about location:

# Location - FH or NH
# Position - A1-4 B1-4 in FH. C1-4 and D1-4 in NH

################
# RESUME       #
################

# Check variance of Y against all categorical covariates
# (Bait, Location, Position)

# Y: Total Catch

str(Catch_Tidy)

# Here's the simplest plot...

a <- ggplot(data=Catch_Tidy, aes(x=Bait, y=Total.Catch)) +
  geom_boxplot() 
a 

# Woohoo! We see a difference. Publish paper, call it a day!

# But let's dig just a bit deeper...
b <- ggplot(data=Catch_Tidy, aes(x=Position, y=Total.Catch, fill=Location)) +
  geom_boxplot() 
b 

# D3 seems to be highly productive. Was that the one where we used cod?

b2 <- ggplot(data=Catch_Tidy, aes(x=Position, y=Total.Catch, fill=Bait)) +
  geom_boxplot() 
b2 

c <- ggplot(data=Catch_Tidy, aes(x=Bait, y=Total.Catch)) +
  geom_boxplot() + facet_wrap(~Position)
c  

# Crap. D3 had only cod... 

# Each position did not necessarily experience each bait type
# This isn't great news

# It would be better if all sites had all bait types. We may 
# find weird residual patterns and poor model fit,
# especially if some sites are better than others

# Why did this happen? 
# The field scientist did randomize where they put gear within blocks
# But: Pure randomization of slot selection can lead to gaps, especially
# with small sample size

# Lesson: Randomization is good. But make sure that you get coverage
# across all covariate levels

# What do we do about this? 
# - Going to have to keep a close eye on leverage. If those D3 points have
# big leverage on the model then we could be in big trouble

# Y: Body Size

# Check variance of Y against all categorical covariates
# (Bait, Location, Position)

BodySizes_Tidy$TrapID <- as.factor(BodySizes_Tidy$TrapID)
BodySizes_Tidy$CW <- as.numeric(as.character(BodySizes_Tidy$CW))

BodySizes_Tidy <- left_join(BodySizes_Tidy, Catch_Tidy)

a <- ggplot(data=BodySizes_Tidy, aes(x=Bait, y=CW)) +
  geom_boxplot() + facet_wrap(~Position)
a 

# This reveals that there were some crabs measured in a group called "NA".
# Let's drop those, since we don't know what those are.

BodySizes_Tidy <- BodySizes_Tidy %>%
  filter(Position!="NA")

# CONCLUSIONS FROM HOMOGENEITY CHECK:
# - We discovered that not all positions experienced all baits - bad
# - We discovered some crabs' body sizes were measured but with no reported position

# - As for homogeneity itself, no serious problems observed, aside from D3 being 
# an overly good site (in which Cod were tested)


###########################
# 3. Normality  Y         #
###########################


# Is Y normally distributed?

# Catch

a <- ggplot(data=Catch_Tidy, aes(x=Total.Catch)) +
  geom_histogram(bins=20)
a 

# Not normal. Bound at zero. Looks like a distirbution you may have seen before...
# Hint: it's French for "Fish"

# Body Size

b <- ggplot(data=BodySizes_Tidy, aes(x=CW)) +
  geom_histogram(bins=20)
b 

# Yes - normal. Far away from zero, so while it is zero-truncated, that won't be an issue


###########################
# 4. Zero trouble Y       #
###########################

sum(BodySizes_Tidy$CW == 0) #No zeroes
sum(Catch_Tidy$Total.Catch == 0) #Only one pot caught nothing at all


###########################
# 5. Collinearity X       #
###########################

# X
#   Bait
#   Position
#   Location
#   Start
#   SoakTime

# There is end as well, but we know that's colinear with start so no point putting both in
     
pairs(~ Bait + Position + Location + Start + SoakTime, 
      lower.panel=panel.smooth, upper.panel=panel.cor, 
      data=Catch_Tidy) 

# We see that position and location are colinear. No surprise there. 

# But this confirms to us that position is a GROUPING variable. We do have to incorporate
# it, but not as a fixed effect. Position will have to be a random effect.

# Also: Notice Location and Start. You may not have noticed this if you had gone from correlation alone

# Location and start day are indeed colinear - because we don't do all locations on all days. 

# So we can only really incorporate one or the other in the model. 
# We could put start day as a random effect. (since replicates are nested within Start Day)

# Nothing else appears to be correlated. 

# DECICION: Incorporate Start Day as a random effect. 

#############################
# 6. Relationships Y and X  #
#############################

# Plot all covariates against Y

# Y: Catch

p <- ggplot(data=Catch_Tidy, aes(x=Bait, y=Total.Catch)) + geom_boxplot()
q <- ggplot(data=Catch_Tidy, aes(x=Position, y=Total.Catch)) + geom_boxplot()
r <- ggplot(data=Catch_Tidy, aes(x=Location, y=Total.Catch)) + geom_boxplot()
s <- ggplot(data=Catch_Tidy, aes(x=Start, y=Total.Catch)) + geom_point()
t <- ggplot(data=Catch_Tidy, aes(x=SoakTime, y=Total.Catch)) + geom_point()

multiplot(p,q,r,s,t, cols = 3)
# Cod and squid appear to be highest catches, herring second, mussels last
# NH had higher CPUE than FH
# Catch seemed to decrease with soak time? But not strongly?
# Position D3 was the best, all others were about the same
# No clear relationship between start date and catch


# Y: BodySize

p <- ggplot(data=BodySizes_Tidy, aes(x=Bait, y=CW)) + geom_boxplot()
q <- ggplot(data=BodySizes_Tidy, aes(x=Position, y=CW)) + geom_boxplot()
r <- ggplot(data=BodySizes_Tidy, aes(x=Location, y=CW)) + geom_boxplot()
s <- ggplot(data=BodySizes_Tidy, aes(x=Start, y=CW)) + geom_point()
t <- ggplot(data=BodySizes_Tidy, aes(x=SoakTime, y=CW)) + geom_point()

multiplot(p,q,r,s,t, cols = 3)

# No real trends at all between CW and anything, although
# there was a bit more variation in NH


##########
# Plot covariates against each other
##########

p <- ggplot(data=Catch_Tidy, aes(x=Bait, y=Position)) + geom_jitter()
q <- ggplot(data=Catch_Tidy, aes(x=Location, y=Position)) + geom_jitter()
r <- ggplot(data=Catch_Tidy, aes(x=Start, y=SoakTime)) + geom_point()
s <- ggplot(data=Catch_Tidy, aes(x=Location, y=SoakTime)) + geom_boxplot()
t <- ggplot(data=Catch_Tidy, aes(x=Position, y=Start)) + geom_point()
u <- ggplot(data=Catch_Tidy, aes(x=Bait, y=SoakTime)) + geom_boxplot()
v <- ggplot(data=Catch_Tidy, aes(x=Bait, y=Location)) + geom_jitter()

multiplot(p,q,r,s,t,u,v, cols = 3) # In a perfectly designed study each bait 
# would have been done in each position at least once. 

# Soak times were shorter in NH, but not by too much.

#############################
# 7. Interactions           #
#############################

# Y: Catch

# Is the relationship between Total Catch and Bait mediated by Location or Soak Time?

coplot(Total.Catch ~ Bait | SoakTime + Location,
       data=Catch_Tidy,
       panel=function(x,y,...) {
         panel.smooth(x,y,span=0.8,iter=5,...)
         abline(lm(y ~ x), col="blue") } )

# Nothing jumps out. There's no a priori reason to think that bait response would differ across
# locations or with longer soaks. Nice to see this laid out though.

# Check by start date too 

coplot(Total.Catch ~ Bait | Start + Location,
       data=Catch_Tidy,
       panel=function(x,y,...) {
         panel.smooth(x,y,span=0.8,iter=5,...)
         abline(lm(y ~ x), col="blue") } )

# Possible interaction with start date 
# - the blue line flattens out in some of those conditions

# Repeat investigation with Y: Carapace Width

coplot(CW ~ Bait | SoakTime + Location,
       data=BodySizes_Tidy,
       panel=function(x,y,...) {
         panel.smooth(x,y,span=0.8,iter=5,...)
         abline(lm(y ~ x), col="blue") } )

# Not too much of a trend... we could test the interaction just to be sure.

coplot(CW ~ Bait | Start + Location,
       data=BodySizes_Tidy,
       panel=function(x,y,...) {
         panel.smooth(x,y,span=0.8,iter=5,...)
         abline(lm(y ~ x), col="blue") } ) #doesn't work? 

#############################
# 8. Independence Y         #
#############################

# There's no magical test for 'independence.' We need to consider the structure of our data.

# Go back to our sketch of the study design. 

# Y: Total.Catch

# 1 row = 1 trap deployment
# Traps were always deployed within positions 
# (an essentially meaningless grouping variable with sixteen levels - eight per location)
# Positions were nested within Location (a meaningful label of a separate place, with two levels)

# We must include position as a random effect to account for dependence induced by geography
# Our full model will include Location as a fixed effect

# Y: Carapace Width:
# 1 row = 1 crab measured
# Crabs were all caught from traps. Therefore, replicates are nested within TrapID
# Trap deployments are nested within Positions. Include Position as a random effect
# Position was nested within Location. 

# Include random effect of TrapID nested within Position.
# Include Location as a fixed effect in full model.


###########################
# RECAP:
# 1. Outliers Y and X:
# - Some traps were deployed in Aug. Removed from dataset
# - Some traps were deployed for very short sets. Removed from dataset
# Remaining: 140 traps. This caused us to remove many crab measurements.

# 2. Homogeneity Y: We discovered that not all positions experienced all baits (bad)
# - We discovered some crabs' body sizes were measured but with no position. Dropped these
# - No serious homogeneity problems observed, but D3 seems to catch most. Beware its
# effect on leverage

# 3. Normality Y: 
# - Catch appears to be Poisson. Use Poisson GLMM 
# - CW appears to be normal. Use Gaussian GLMM.

# 4. Zero trouble Y: Nope
# 5. Collinearity X: Nothing obvious

# 6. Relationships Y and X: 
# - Cod and squid appear to be highest catches, herring second, mussels last
# - NH had higher CPUE than FH
# - Catch seemed to decrease with soak time? But not strongly?
# - Position D3 was the best, all others were about the same
# - No clear relationship between start date and catch
# - No real trends at all between CW and anything, although there was a bit more variation in NH

 
# 7. Interactions: Keep an eye on whether start date interacts with bait type.

# 8. Independence Y: Nesting structure described above. Mixed models essential for both Y's.

#################################
# One more step: Make a map     #
#################################

# Where data are explicitly geographical it's a good idea to make a map
# that clearly shows the geographic distribution of Y.

# If I have time before Tuesday, make a map showing this

###############################
# Data exploration complete

# Conclude that our full models should be:

# GLMM: Poisson
# Total.Catch ~ Bait + Location + SoakTime + (1|StartDay / Position)

# GLMM: Gaussian 
# CW ~ Bait + Location + SoakTime + (1|StartDay/Position/TrapID)

# Go to 3_Analysis
