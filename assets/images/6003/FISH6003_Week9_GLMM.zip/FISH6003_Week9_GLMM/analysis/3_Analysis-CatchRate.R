# FISH 6003: Week 9 Data Exploration
# Green crab bait choice study 
# Data Exploration

# Unpublished data collected by:
# Mary Alliston Butt
# Jonathan Bergshoeff

# Started: March 10, 2018

#library(MASS)
library(glmmTMB)
library(ggeffects)
library(sjstats)

##########################################
# RUN EVERYTHING IN 1_DATASETUP.R FIRST  #
# THEN RUN 2_DataExploration.R SECOND    #
##########################################

# Recall Zuur and Ieno's ten steps:

#1. State questions 

# What bait produces the highest CPUE of green crabs?

#2. Visualize experimental design - see lecture notes

#3. Conduct data exploration - see files 1 and 2

# 4. Identify dependency structure - See comments in exploration, and lecture

######################################
# 5. Present the statistical model. #
######################################

# Per the data exploration our full models should be:

# GLMM: Poisson
# Total.Catch ~ Bait * Start + Location + SoakTime + (1|StartDay/Position)

# GLMM: Gaussian 
# CW ~ Bait * Start + Location + SoakTime + (1|TrapID/Position)

# ***Focus only on the total.catch model***
 
# Catch

# Catch ~ Poisson(mu_ijk)
# E = mu_ijk 
# log(mu_ijk) = Beta_0 +
#               Beta_1*SoakTime_ijk+
#               Bait_ijk +
#               Location_ijk +
#               StartDay_i +
#               Position_Within_Day_ij
#              
# StartDay_i   ~ N(0, sigma^2_StartDay)
# Position_Within_StartDay_ij ~ N(0, Sigma^2_Position)



# Which package should we use? http://glmm.wikidot.com/pkg-comparison

# If we want to sue start date in our model we should make it be a regular number
# so as to avoid the possibility of the modelling package mishandling the value

# Use yday() to extract the Day of the Year of each start date.

Catch_Tidy$StartDay <- yday(Catch_Tidy$Start)

# Make first day of the study Day 1.

Catch_Tidy$StartDay <- Catch_Tidy$StartDay-min(Catch_Tidy$StartDay-1)

# Do the same for the Body Sizes dataset

BodySizes_Tidy$StartDay <- yday(BodySizes_Tidy$Start)
BodySizes_Tidy$StartDay <- BodySizes_Tidy$StartDay-min(BodySizes_Tidy$StartDay-1)


###
# Begin Modelling
###

mod <- glmmTMB(Total.Catch ~ Bait + 
                Location +
                SoakTime +
                (1 | StartDay / Position), 
              family = "poisson",
              data = Catch_Tidy)
summary(mod)

fixef(mod)

# Check for overdisperson

E1 <- residuals(mod, type = "pearson")
N  <- nrow(Catch_Tidy)
p  <- length(fixef(mod)) + 2 
# recall that p is the number of parameters
# length of fixef give us 6
# 2 for two random effects
sum(E1^2) / (N - p)




#################################################
# A brief aside: What if we DID NOT account for #
# the nested structure of our data?             # 
#################################################

mod2 <- glmmTMB(Total.Catch ~ Bait + 
                 Location +
                 SoakTime +
                 (1 | Position), 
               family = "poisson",
               data = Catch_Tidy)

E1 <- resid(mod2, type = "pearson")
N  <- nrow(Catch_Tidy)
p  <- length(fixef(mod2)) + 2
sum(E1^2) / (N - p)

# Hugely overdispersed

# Recall possible reasons for overdispersion: 
# - Zero inflation
# - Non-linear patterns
# - Missing interactions
# - Missing dependency
# - Or Poisson distribution is just wrong

# Here, we KNOW that we're missing a dependency structure. 
# If we didn't bear that in mind we may progress to a more complex model
# such as negative binomial, when the real problem is a mis-specified dependency 
# structure. Fortunately we were paying attention during data exploration
# and didn't make that mistake

# Also:

# In GLMMs you're allowed to specify an
# OBSERVATION LEVEL RANDOM EFFECT
# In other words, every row of data gets its own level of a grouping variable
# which is included as a random effect

# This can reduce overdispersion by adding more variance to the data distribution

# A poisson GLMM with observation-level random effect becomes similar to NB

###########################
# Back on track...        # 
###########################
 
# Our full model is:
mod <- glmmTMB(Total.Catch ~ Bait + 
                 Location +
                 SoakTime +
                 (1 | StartDay / Position), 
               family = "poisson",
               data = Catch_Tidy)
summary(mod) 


# Model selection. Backward stepwise reduction:

drop1(mod, test="Chi")

# We see that SoakTime, if dropped, does not make the model worse
# Drop SoakTime
 
mod2 <- glmmTMB(Total.Catch ~ Bait + 
                 Location +
              (1 | StartDay / Position), 
               family = "poisson",
               data = Catch_Tidy)
summary(mod2) 

# All terms are significant. Proceed with this model.

# Validation: 
# - Overdispersion 
E1 <- resid(mod2, type = "pearson")
N  <- nrow(Catch_Tidy)
p  <- length(fixef(mod2)) + 2
sum(E1^2) / (N - p)

# underdispersed, meaning that our data have less variance than predicted by the model

# - Patterns of residuals

###
# Histogram of residuals

hist(residuals(mod2, type="pearson"))# ok... slight deviance from normal

###
# Residuals vs. covariates in model

plot(residuals(mod2, type="pearson") ~ Catch_Tidy$Bait)
abline(h=0, lty=2)

plot(residuals(mod2, type="pearson") ~ Catch_Tidy$Location)
abline(h=0, lty=2)

# Good - nothing major

###
# Residuals vs. covariates NOT in model
plot(residuals(mod2, type="pearson") ~ Catch_Tidy$SoakTime)
abline(h=0, lty=2)

# A bit of a cone-shaped pattern... but it's fairly mild.
# Our evidence to drop soaktime was strong. I think we're okay.

###
# Residuals vs. time and space

#Time:
plot(residuals(mod2, type="pearson") ~ Catch_Tidy$StartDay)
abline(h=0, lty=2) # No problems here

#Space:
plot(residuals(mod2, type="pearson") ~ Catch_Tidy$Position)
abline(h=0, lty=2) 
# This concerns me. Definite heteroskedacitiy
 
table(Catch_Tidy$Position, Catch_Tidy$Location) 
# Our model performs worse in FH. But we have less data in NH.

# MAKE A MAP IF I HAVE TIME

###
# Residuals vs. levels of the random effect (Another way to say time and space)

plot(residuals(mod2, type="pearson") ~ Catch_Tidy$Position) # Massive heteroskedacitiy
abline(h=0, lty=2)


###############################
# Residuals vs. fitted values #
###############################
plot(residuals(mod2, type="pearson") ~ fitted(mod2))
abline(h=0, lty=2) 
lines(smooth.spline(fitted(mod2), residuals(mod2, type="pearson"))) #Smoother line

# A catastrophically bad fit!


# As fitted values increase, our residuals increase. Our model does a good 
# job at low catch rates, and a poor job at higher catch rates.

# This suggests model misspecification. We are missing a predictor.

# Perhaps there is an underlying dynamic
# we failed to capture in the study design

# Temperature? Something else? 

# Regardless, it's not clear to me that this is 
# a fixable problem in the context of this study. 
  
# Recall our concern earlier about the lack of all four bait types being in all positions:

b <- ggplot(data=Catch_Tidy, aes(x=Bait, y=residuals(mod2), fill=Location))
b + geom_boxplot() + facet_grid(~Position)

# This is a big problem. 

# Why didn't our overdispersion test catch this? 
# Hard to say... there are many ways to calculate overdispersion :(

###
# Let's try fitting as a negative binomial GLMM.

mod3 <- glmmTMB(Total.Catch ~ Bait + 
                  Location +
                  (1 | StartDay / Position), 
                family = "nbinom1",
                # Note: Nbinom1 - variance increases LINEARLY with mean
                # Nbinom2 - variance increases QUADRATICALLY with mean
                data = Catch_Tidy)
summary(mod3) 

###############################
# Residuals vs. fitted values #
###############################
plot(residuals(mod3, type="pearson") ~ fitted(mod3))
abline(h=0, lty=2) 
lines(smooth.spline(fitted(mod3), residuals(mod3, type="pearson"))) 

# Better, but still not great.


mod4 <- glmmTMB(Total.Catch ~ Bait + 
                  Location +
                  (1 | StartDay / Position), 
                family = "nbinom2",
                data = Catch_Tidy)
summary(mod4) 

plot(residuals(mod4, type="pearson") ~ fitted(mod4))
abline(h=0, lty=2) 
lines(smooth.spline(fitted(mod4), residuals(mod4, type="pearson"))) 
# That's way better

#######################################################
# Step 5: Present the above model:

# Catch ~ NB(mu_ijk, theta)
# E = mu_ijk 
# var = mu_ijk + (mu_ijk^2 / theta)

# log(mu_ijk) = Beta_0 +
#               Bait_ijk +
#               Location_ijk +
#               StartDay_i +
#               Position_Within_Day_ij
#              
# StartDay_i   ~ N(0, sigma^2_StartDay)
# Position_Within_StartDay_ij ~ N(0, sigma^2_Position)
#########################

######################################
# Step 6: Fit the Model
 
# Already done... To repeat:
mod4 <- glmmTMB(Total.Catch ~ Bait + 
                  Location +
                  (1 | StartDay / Position), 
                family = "nbinom2",
                data = Catch_Tidy)
#####################################
# Step 7: Validate the model

# Residuals vs. fitted values
plot(residuals(mod4, type="pearson") ~ fitted(mod4))
abline(h=0, lty=2) 
lines(smooth.spline(fitted(mod4), residuals(mod4, type="pearson"))) 

###
# Histogram of residuals

hist(residuals(mod4, type="pearson"))

###
# Residuals vs. covariates in model

plot(residuals(mod4, type="pearson") ~ Catch_Tidy$Bait)
abline(h=0, lty=2)

plot(residuals(mod4, type="pearson") ~ Catch_Tidy$Location)
abline(h=0, lty=2)

# Good - nothing major. NH underpredicted a bit.

###
# Residuals vs. covariates NOT in model
plot(residuals(mod4, type="pearson") ~ Catch_Tidy$SoakTime)
abline(h=0, lty=2)

# A bit of a cone-shaped pattern... but it's fairly mild.

###
# Residuals vs. time and space

#Time:
plot(residuals(mod4, type="pearson") ~ Catch_Tidy$StartDay)
abline(h=0, lty=2) # No problems here

#Space:
plot(residuals(mod4, type="pearson") ~ Catch_Tidy$Position)
abline(h=0, lty=2) 
# Still a bit of a problem where C block caught a bit less.

##############################################
# I think we can defensibly stick with mod4. #
##############################################

# Note:
# R squared is often reported for LM's (proportion of variance explained by model)
# For GLMMs...

# See: http://onlinelibrary.wiley.com/doi/10.1111/j.2041-210x.2012.00261.x/full

# Goodness-of-fit as defined by AIC is relative, whereas R2 is a standalone value

# For LMMs and GLMMs the values are marginal and conditional R2

# Marginal: Variance explained by fixed component only
# Conditional: Variance explained by fixed + random component together

# Problem: Would have to calculate these by hand because we modelled in glmmTMB.

# Ran out of time to code for this.

###############################################################
# Step 8: Interpret and present numerical output of model     #
###############################################################

# If we were using a more standard package we could automatically extract a nice looking
# table from the model output

# Sadly we are using glmmTMB so we do it manually

summary(mod4)

#                  Estimate   Std. Error z value P value
#(Intercept)       2.8762     0.1487  19.341  < 2e-16
#  Bait2_Mussels  -0.7370     0.1428  -5.161 2.46e-07
 # Bait3_Squid     0.4202     0.1428   2.942  0.00326
#  Bait4_Cod       0.5725     0.1356   4.221 2.43e-05
 # LocationNH      0.5997     0.1528   3.924 8.72e-05

#Usually you'd round this to three decimal places

#Recall, in assessing whether a factor is "significant" 

drop1(mod4, test="Chisq")

# Highlight key results in words:

summary(mod4)

exp(0.5725) # to get cod impact
exp(confint(mod4))

# "The use of cod as bait increased catch per deployment by 77% (95% CI = 36 - 131 %) 
# relative to traps baited with herring."

# Calculate an intraclass correlation 
icc(mod4) # ZERO!? Could we have done the whole damn thing as a regular glm.nb!?!

# No, because there IS dependency structure. Need to look into what happened here.



#############################################################
# Step 9: Create visual representation of model             #
#############################################################

###
# IMPORTANT TERM: MARGINAL EFFECT

# Marginal effect is the effect that a change in one explanatory variable
# has on the response variable

# So it's the change in Y attributable to a change in one covariate
a<-ggaverage(mod4, c("Bait", "Location"), typical="mean") 
plot(a)
# This plots the average effect across all groups

b<-ggpredict(mod4, c("Bait", "Location"), typical="mean") 
plot(b)
# This plots the effect at the "mean" value of random effect
# This is usually what you'd want.

# You could also use typical="median" weighted mean or mode

# you kids these days have it easy, thanks to ggeffects.
# back in MY day we had to code these BY HAND!!!

# See: https://strengejacke.wordpress.com/2017/05/24/ggeffects-create-tidy-data-frames-of-marginal-effects-for-ggplot-from-model-outputs-rstats/

# Let's make it publication-quality


labs <- c("Herring", "Mussels", "Squid", "Cod")

b$x <- as.factor(b$x)
PubPlot <- ggplot(b, aes(x, predicted, colour=group)) +
  theme_bw() +
  geom_pointrange(aes(x=x, y=predicted, ymin=conf.low, ymax=conf.high),
                  size=1.5, 
                  position=position_dodge(width=0.2)) +
  labs(x="Bait type", y="Predicted number of green crabs caught per deployment") +
  theme(text=element_text(size=16)) +
  guides(color=guide_legend("Location")) +
  scale_x_discrete(breaks=c(1,2,3,4), labels=labs) + 
  scale_color_manual(values=c("royalblue", "seagreen"))

# Colour list http://www.stat.columbia.edu/~tzheng/files/Rcolor.pdf

PubPlot

# Save it for your paper
ggsave("./figures/Figure1.png", width=6, height = 7,
       dpi=300)

###############################
# 10. Simulate from the model #
############################### 

# I ran out of time :(