# FISH 6003: Week 9 Data Exploration
# Green crab bait choice study 
# Data Exploration

# Unpublished data collected by:
# Mary Alliston Butt
# Jonathan Bergshoeff

# Started: March 10, 2018

library(MASS)

##########################################
# RUN EVERYTHING IN 1_DATASETUP.R FIRST  #
# THEN RUN 2_DataExploration.R SECOND    #
##########################################

# Per the data exploration our full models should be:

# GLMM: Poisson
# Total.Catch ~ Bait * Start + Location + SoakTime + (1|Position)

# GLMM: Gaussian 
# CW ~ Bait * Start + Location + SoakTime + (1|TrapID/Position)

# First: Catch

# Which package should we use? http://glmm.wikidot.com/pkg-comparison

# If we want to sue start date in our model we should make it be a regular number
# so as to avoid the possibility of the modelling package mishandling the value

# Use yday() to extract the Day of the Year of each start date.

Catch_Tidy$StartDay <- yday(Catch_Tidy$Start)

# Make first day of the study Day 1.

Catch_Tidy$StartDay <- Catch_Tidy$StartDay-min(Catch_Tidy$StartDay-1)

# Do the same for the Body Sizes dataset

BodySizes_Tidy$StartDay <- yday(BodySizes_Tidy$Start)
BodySizes_Tidy$StartDay <- BodySizes_Tidy$StartDay-min(BodySizes_Tidy$StartDay-1)


###
# Begin Modelling
###

mod <- glmmTMB(Total.Catch ~ Bait + 
                Location +
                SoakTime +
                (1 | StartDay / Position), 
              family = "poisson",
              data = Catch_Tidy)
summary(mod)

# Check for overdisperson

E1 <- resid(mod, type = "pearson")
N  <- nrow(Catch_Tidy)
p  <- length(fixef(mod)) + 3
sum(E1^2) / (N - p)

# Wow, very underdispersed. This is rare.

#################################################
# A brief aside: What if we DID NOT account for #
# the nested structure of our data?             # 
#################################################

mod2 <- glmmTMB(Total.Catch ~ Bait + 
                 Location +
                 SoakTime +
                 (1 | Position), 
               family = "poisson",
               data = Catch_Tidy)

E1 <- resid(mod2, type = "pearson")
N  <- nrow(Catch_Tidy)
p  <- length(fixef(mod2)) + 3
sum(E1^2) / (N - p)

# Hugely overdispersed

# Recall possible reasons for overdispersion: 
# - Zero inflation
# - Non-linear patterns
# - Missing interactions
# - Missing dependency
# - Or Poisson distribution is just wrong

# Here, we KNOW that we're missing a dependency structure. 
# If we didn't bear that in mind we may progress to a more complex model
# such as negative binomial, when the real problem is a mis-specified dependency 
# structure. Fortunately we were paying attention during data exploration
# and didn't make that mistake

# In GLMMs you're allowed to specify an
# OBSERVATION LEVEL RANDOM EFFECT
# In other words, every row of data gets its own level of a grouping variable
# which is included as a random effect

# This can reduce overdispersion by adding more variance to the data distribution

# A poisson GLMM with observation-level random effect becomes similar to NB

###########################
# Back on track...        # 
###########################
 
# Our full model is:
mod <- glmmTMB(Total.Catch ~ Bait + 
                 Location +
                 SoakTime +
                 (1 | StartDay / Position), 
               family = "poisson",
               data = Catch_Tidy)
summary(mod) 

# Model selection. Backward stepwise reduction:

drop1(mod, test="Chi")

# We see that SoakTime, if dropped, does not make the model worse
# Drop SoakTime
 
mod2 <- glmmTMB(Total.Catch ~ Bait + 
                 Location +
              (1 | StartDay / Position), 
               family = "poisson",
               data = Catch_Tidy)
summary(mod2) 

# All terms are significant. Proceed with this model.

# Validation: 
# - Overdispersion 
E1 <- resid(mod2, type = "pearson")
N  <- nrow(Catch_Tidy)
p  <- length(fixef(mod2)) + 3
sum(E1^2) / (N - p)

# Still underdispersed, meaning that our data have less variance than predicted by the model
# Our model will have wide confidence intervals - wider than necessary

# I think we can live with that here.

# - Patterns of residuals

# Histogram of residuals

hist(residuals(mod2))# ok

# Residuals vs. covariates in model

plot(residuals(mod2) ~ Catch_Tidy$Bait)
abline(h=0, lty=2)

plot(residuals(mod2) ~ Catch_Tidy$Location)
abline(h=0, lty=2)

# Good - nothing major

# Residuals vs. covariates NOT in model
plot(residuals(mod2) ~ Catch_Tidy$SoakTime)
abline(h=0, lty=2)

# A bit of a cone-shaped pattern... but it's fairly mild.
# Our evidence to drop soaktime was strong. I think we're okay.

# Residuals vs. time and space

#Time:
plot(residuals(mod2) ~ Catch_Tidy$StartDay)
abline(h=0, lty=2) # No problems here

#Space:
plot(residuals(mod2) ~ Catch_Tidy$Position)
abline(h=0, lty=2) 
# This concerns me. There is no pattern in a's and b's, but there IS a pattern in C's and D's.

# This suggests the model fits worse in the C and D sites. 
table(Catch_Tidy$Position, Catch_Tidy$Location) 
# By extension this means our model performs worse in NH. We also have less data in NH.

# MAKE A MAP IF I HAVE TIME

###############################
# Residuals vs. fitted values #
###############################
plot(residuals(mod2) ~ fitted(mod2))
abline(h=0, lty=2) 

# Catastrophe!!! 

# As fitted values increase, our residuals increase. Our model does a good 
# job at low catch rates, and a poor job at higher catch rates.

# This suggests model misspecification. We are missing a predictor.

# But we have not excluded a predictor. Perhaps there is an underlying dynamic
# we failed to capture in the study design

# Temperature? Something else? Regardless, it's not clear to me that this is 
# a fixable problem in the context of this study. 
  
# Recall our concern earlier about the lack of all four bait types being in all positions:

a <- ggplot(data=Catch_Tidy, aes(x=Position, y=Total.Catch))
a + geom_boxplot()

b <- ggplot(data=Catch_Tidy, aes(x=Bait, y=residuals(mod2), fill=Location))
b + geom_boxplot() + facet_grid(~Position)

# This alone isn't explaining the problem. 

summary(mod2)

# Still need to visualize the model, simulate, etc.
