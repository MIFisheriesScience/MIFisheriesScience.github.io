# FISH 6003: Week 9 Data Analysis 

# Continuous response GLMM
# i.e. Gaussian-distribution

# Green crab bait choice study 

# Unpublished data collected by:
# Mary Alliston Butt
# Jonathan Bergshoeff

# Started: March 19, 2018

##########################################
# RUN EVERYTHING IN 1_DATASETUP.R FIRST  #
# THEN RUN 2_DataExploration.R SECOND    #
# THEN 3_Analysis-CatchRate.R THIRD      #
##########################################

# Recall Zuur and Ieno's ten steps:

# 1. State questions 

# How does mean Carapace Width of green crabs change with bait used?
# (i.e. do certain baits catch bigger crabs?)

# See: https://en.wikipedia.org/wiki/Scylla_serrata#/media/File:CSIRO_ScienceImage_10696_Mud_crabs_are_caught_measured_tagged_and_released_as_part_of_the_research_into_the_effectiveness_of_green_zones_in_Moreton_Bay.jpg
# for a picture of someone measuring CW
 
# 2. Visualize experimental design - see lecture notes

# 3. Conduct data exploration - see files 1 and 2

# 4. Identify dependency structure - See comments in exploration, and lecture

#####################################
# 5. Present the statistical model. #
#####################################

# GLMM: Gaussian 
# CW ~ Bait + Location + SoakTime + (1|StartDay/Position/TrapID)

str(BodySizes_Tidy)

# CW ~ Normal(mu_ijkl, sigma^2)
# E = mu_ijkl 
# var = sigma^2
# 
# mu_ijkl = Beta_0 +
#               Beta_1*SoakTime_ijkl+
#               Bait_ijkl +
#               Location_ijk +
#               StartDay_i +
#               Position_Within_Day_ij + 
#               TrapID_Within_Position_ijk            
#              
# StartDay_i   ~ N(0, sigma^2_StartDay)
# Position_Within_StartDay_ij ~ N(0, Sigma^2_Position)
# TrapID_Within_Position_ijk ~ N(0, Sigma^2_TrapID)


# Housekeeping:
BodySizes_Tidy$StartDay <- as.factor(BodySizes_Tidy$StartDay)
# Drop unused TrapID's (recall some have no data)
BodySizes_Tidy$TrapID <- droplevels(BodySizes_Tidy$TrapID)

###########################
# Step 6: Fit the Model   #
###########################

mod <- glmmTMB(CW ~ Bait + 
                 Location +
                 SoakTime +
                 (1 | StartDay / Position / TrapID), 
               family = "gaussian",
               data = BodySizes_Tidy)
summary(mod) # Damn, didn't work

# see: https://cran.r-project.org/web/packages/glmmTMB/vignettes/troubleshooting.html

# Bottom line; We don't have enough data for this model.

# Which Random Effect is to blame?
# Drop StartDay (m1)
# Drop Position (m2)
# Drop Trap ID (m3)

m1 <- glmmTMB(CW ~ Bait + Location + SoakTime + (1 | Position / TrapID), family = "gaussian", data = BodySizes_Tidy)
m2 <- glmmTMB(CW ~ Bait +Location + SoakTime + (1 | StartDay / TrapID), family = "gaussian", data = BodySizes_Tidy)
m3 <- glmmTMB(CW ~ Bait + Location + SoakTime + (1 | StartDay / Position), family = "gaussian", data = BodySizes_Tidy)

# m1 - doesn't run
# m2 & m3 - runs

# No single obvious culprit

# To decide which to eliminate, combine data exploration
# with logic.

# - Don't get rid of position - we found it had a big impact on catch rates
# i.e. we know there is spatial dependency and should model it

# - Don't get rid of Start Day - We know that locations were not tested
# across all start days

# i.e. we know there is temporal dependency and should model it

# - DO get rid of TrapID. Recall:

plot(CW ~ TrapID, data=BodySizes_Tidy) 
# No single trap appear to be obviously different from other traps

# Fair to say we can ditch it.

# Proced with:

mod <- glmmTMB(CW ~ Bait + 
                 Location +
                 SoakTime +
                 (1 | StartDay / Position), 
               family = "gaussian",
               data = BodySizes_Tidy)
summary(mod)

# Commence model selection
drop1(mod, test="Chi")

# Drop SoakTime

mod2 <- glmmTMB(CW ~ Bait + 
                 Location +
                  (1 | StartDay / Position), 
               family = "gaussian",
               data = BodySizes_Tidy)
summary(mod2)

drop1(mod2, test="Chi") # Lovely

#################################
# STEP 7: VALIDATE THE MODEL    #
##################################

# - Normality
hist(resid(mod2, type = "pearson")) # a thing of unparallelled beauty

# - Homogeneity of variance

# Plot residuals vs. fitted values
plot(resid(mod2, type="pearson") ~ fitted(mod2))
abline(h=0, lty=2) # At higher fitted values, 
# Recall we're looking for even VARIANCE across range of fitted values
# We do have a slight cone-shaped pattern. Slight violation?

###
# Residuals vs. covariates in model

plot(residuals(mod2, type="pearson") ~ BodySizes_Tidy$Bait)
abline(h=0, lty=2) # wonderful

plot(residuals(mod2, type="pearson") ~ BodySizes_Tidy$Location)
abline(h=0, lty=2) # A little less wonderful. There is more variance at NH
# Not all that much though

###
# Residuals vs. covariates NOT in model
###

###
# Residuals vs. covariates NOT in model
plot(residuals(mod2, type="pearson") ~ BodySizes_Tidy$SoakTime)
abline(h=0, lty=2) # Soak time is not clearly 
# driving our very slight cone-shaped pattern

plot(residuals(mod2, type="pearson") ~ BodySizes_Tidy$TrapID)
abline(h=0, lty=2) # Confirms our decision to ignore TrapID

# Residuals vs. time and space: AKA:
# Residuals vs. levels of the random effect (Another way to say time and space)

#Time:
plot(residuals(mod2, type="pearson") ~ BodySizes_Tidy$StartDay)
abline(h=0, lty=2) # No problems here

#Space:
plot(residuals(mod2, type="pearson") ~ BodySizes_Tidy$Position)
abline(h=0, lty=2) # No problem

# MAKE A MAP IF I HAVE TIME


# - Independence
# No magic test. Random effects 

# - Fixed X
# Yes

# Model is verified. Our fitted model will be:

# CW ~ Normal(mu_ijk, sigma^2)
# E = mu_ijk 
# var = sigma^2
# 
# mu_ijk = Beta_0 +
#               Bait_ijk +
#               Location_ijk +
#               StartDay_i +
#               Position_Within_Day_ij
#              
# StartDay_i   ~ N(0, sigma^2_StartDay)
# Position_Within_StartDay_ij ~ N(0, Sigma^2_Position)

###############################################################
# Step 8: Interpret and present numerical output of model     #
###############################################################

summary(mod2)

#               Estimate Std. Error z value Pr(>|z|)    
#(Intercept)     51.8182     0.8278   62.60  < 2e-16 ***
#Bait2_Mussels   1.3538     0.9464    1.43  0.15256    
#Bait3_Squid     2.4201     0.8379    2.89  0.00388 ** 
#Bait4_Cod       1.9088     0.8425    2.27  0.02347 *  
#LocationNH      1.9953     0.9404    2.12  0.03385 *  

# Key results in words:

# 95% CI for cod
1.9088+ (1.96*0.8425)
1.9088- (1.96*0.8425)

# "Green crabs caught in traps baited with cod were 1.9 cm larger than those 
# caught in herring-baited traps (95% CI = 0.26 - 3.56 cm, Table 1)." 

# "Green crabs in North Harbour were 2.0 cm larger than those in FH (95% CI...)

# Use the results table in your paper to reduce need to keep writing P < 0.05.


# Calculate an intraclass correlation 
icc(mod2) # Intraclass correlatinon within start day is 0.02 (very low). 
# For position, within start day, it's 0.09 (less low).


#############################################################
# Step 9: Create visual representation of model             #
#############################################################

b<-ggpredict(mod2, c("Bait", "Location"), typical="mean") 

plot(b)

labs <- c("Herring", "Mussels", "Squid", "Cod")

b$x <- as.factor(b$x)
PubPlot <- ggplot(b, aes(x, predicted, colour=group)) +
  theme_bw() +
  geom_pointrange(aes(x=x, y=predicted, ymin=conf.low, ymax=conf.high),
                  size=1.5, 
                  position=position_dodge(width=0.75)) +
  labs(x="Bait type", y="Predicted carapace width (cm) of green crabs") +
  theme(text=element_text(size=16)) +
  guides(color=guide_legend("Location")) +
  scale_x_discrete(breaks=c(1,2,3,4), labels=labs) + 
  scale_color_manual(values=c("royalblue", "seagreen"))

# Colour list http://www.stat.columbia.edu/~tzheng/files/Rcolor.pdf

PubPlot

# Save it for your paper
ggsave("./figures/Figure2.png", width=6, height = 7,
       dpi=300)

# Alternate visualization: Model output with original data

# Bonus: Allows for visual inspection to see the model fit
PubPlot + geom_jitter(data = BodySizes_Tidy, aes(x=Bait, y=CW, colour=Location), 
                     position=position_dodge(width=0.4), alpha=0.4)

PubPlot + geom_boxplot(data = BodySizes_Tidy, aes(x=Bait, y=CW, colour=Location), 
                      position=position_dodge(width=0.4), alpha=0.4)
# Recall what a 95% C.I. means - just that the true population mean would fit within this
# range 95% of the time if this was repeated an infinite number of times
# It's not abnormal for the range of values to be wider than the 95% CI

# If you want an itnerval that says "95% of future values collected would fit within THESE bands"
# what would that be called?

###############################
# 10. Simulate from the model #
############################### 

# There are no zeroes in these data, so we can't test for zero-inflation.

# Option:
# Use the simulate command to create a bunch of datasets
Simulation <-  simulate(mod2, nsim = 5) 

# Compare against your actual dataset. To what extent is there overlap?

hist(BodySizes_Tidy$CW, col="darkgrey", ylim=c(0,800))
hist(Simulation$sim_1, add=T, col=alpha("lightblue", 0.2))
hist(Simulation$sim_2, add=T, col=alpha("lightblue", 0.2))
hist(Simulation$sim_3, add=T, col=alpha("lightblue", 0.2))
hist(Simulation$sim_3, add=T, col=alpha("lightblue", 0.2))
hist(Simulation$sim_5, add=T, col=alpha("lightblue", 0.2))

# Fin

