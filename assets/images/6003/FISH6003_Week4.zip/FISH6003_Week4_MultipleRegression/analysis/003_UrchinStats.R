# FISH 6003: Week 2 Data Exploration

# Started: Jan 16, 2018

# Note: 001_DataSetup.R must be run prior to this script.

library(visreg)
library(lsmeans)

urchins <- urchinsfull # Run only if you ran all of 002_Exploration.R


# Site: One of two places in Italy. Su Pallosu Bay 
# (high fishing area, not a Marine Protected Area, MPA) or Tavolara MPA (low fishing pressure).
# Bear in mind that Site is really Fishing/NoFishing
# Area: Two fishing areas within each site, labelled as A, B, C, D, respectively
# Size: Size of each urchin caught. CS = Commercial Size (Test Diameter, spines removed > 50 mm)
#                               US = Undersized (TD between 40 and 50 mm) 
#                               Small-US = Smaller undersized (TD between 30 and 40 mm)
# Code: A unique individual ID for each urchin. Should be one code per urchin

# Per the author, the way the code works was, for example:
# 6SA1G1 - June (6) 
#         - Zone Su Pallosu (S)
#         - Area (A)
#         - Station(1)
#         - Size - CS = G
#         - Sample #. Here, 1

# TD: Test Diameter in mm. The diameter of the round part of the urchin 
# TW: Total Wet Weight in g
# GW: Gonadal Wet Weight in g
# GSI: Gonadosomatic Index. Calculated as GSI = (GW / TW) * 100.
# Sex: M or F
# Month: 1-12, aka Jan - Dec. No sampling in Nov.

# In the paper, they did:

# Y: GSI
# X: Month, Zone, Size Class
# Random effect: Area <-- Definitely can't do this with only four levels of Area

# Simplest model: 
# GSI as a function of TD

workingdata <- urchins


mod1 <- lm(GSI ~ TD, data=workingdata) 
summary(mod1)

workingdata$predicted <- predict(mod1)
workingdata$residuals <- residuals(mod1)

a <- ggplot(data=workingdata, aes(x=TD, y=GSI)) +
  theme_bw() + stat_smooth(method=lm) + geom_point()
a

plot(residuals~predicted, data=workingdata)
abline(h=0)

##############################
# Simple model of GSI ~ Site #
##############################

workingdata <- urchins

mod2 <- lm(GSI ~ Site, data=workingdata)             
summary(mod2)

workingdata$predicted <- predict(mod2)
workingdata$residuals <- residuals(mod2)

#Raw data
plot(GSI ~ Site, data=workingdata) 

#Visualize the model
visreg(mod2, xvar="Site")# Blue is mean + coefficient. Grey adds 95% CI

####################
# GSI ~ TD + Site  #
####################

workingdata <- urchins

levels(workingdata$Site)

mod3 <- lm(GSI ~ TD + Site, data=workingdata)             
summary(mod3)

plot(GSI ~ TD, data=workingdata)

coefficients <- coef(mod3)

abline(a=coefficients[1], b=coefficients[2])
abline(a=(coefficients[1]+coefficients[3]), b=coefficients[2], col="blue")

# Zoom in

plot(GSI ~ TD, data=workingdata, ylim=c(3,4), xlim=c(50,58))
abline(a=coefficients[1], b=coefficients[2])
abline(a=(coefficients[1]+coefficients[3]), b=coefficients[2], col="blue")


#####################
# GSI ~ TD + Month  #
#####################

workingdata <- urchins

mod4 <- lm(GSI ~ TD + Month, data=workingdata)   
summary(mod4)
coefficients <- coef(mod4)

plot(GSI ~ TD, data=workingdata)

abline(a = coefficients[1], b=coefficients[2], lwd=4) # at month 1

for (i in 3:length(coefficients)) {
  abline(a = coefficients[1]+coefficients[i], b=coefficients[2], col=i, lwd=2)
} # all other months


# Better visualization:

plotlines <- workingdata %>%
  group_by(Month)%>%
  summarise(xmin = min(TD), xmax = max(TD)) %>%
  mutate(intercept = ifelse(Month=="1", coefficients[1],
                            ifelse(Month=="12", coefficients[1]+coefficients[12],
                           coefficients[1]+coefficients[as.numeric(as.character(Month))+1]))) %>%
  mutate(slope = coefficients[2])

plot(GSI ~ TD, data=workingdata)

for(i in 1:length(levels(workingdata$Month))){
  ablineclip(a = plotlines$intercept[i],
             b = plotlines$slope[i],
             x1 = plotlines$xmin[i],
             x2 = plotlines$xmax[i],
             col=i, lwd=2)
}



##########################################
# Check whether factor affects Y overall #
##########################################

summary(mod4)

#Get one p-value for the Month variable
drop1(mod4, test = "F")

#Output: <none> is with dropping nothing
#Output: TD is what would happen if you just drop TD
#Output: Month is if you just drop month

# What is this doing?

M0 <- lm(GSI ~ TD + Month, data = workingdata)
M1 <- lm(GSI ~      Month, data = workingdata)
M2 <- lm(GSI ~ TD            , data = workingdata)
anova(M0, M1)  #p-value for Month
anova(M0, M2)  #p-value for TD

# It's comparing how the model would fit with and without each term

# DANGER: multiple comparisons! Beware if you have lots of variables

# F = 29.537 (p < 0.001)

# How does site measure up:
drop1(mod3, test = "F")

#########################
# Intro to interactions #
#########################

workingdata <- urchins

mod5 <- lm(GSI ~ TD * Month, data=workingdata)   

summary(mod5) 
# Interaction is NS, but don't worry about that for now
# Let's pretend that it IS significant

coefficients <- coef(mod5)

plot(GSI ~ TD, data=workingdata)

#terrible code follows, but it seems to work:
plotlines <- workingdata %>%
  group_by(Month)%>%
  summarise(xmin = min(TD), xmax = max(TD)) %>%
  mutate(intercept = ifelse(Month=="1", coefficients[1],
                            ifelse(Month=="12", coefficients[1]+coefficients[12],
                                   coefficients[1]+coefficients[as.numeric(as.character(Month))+1]))) %>%
  
  mutate(slope = ifelse(Month=="1", coefficients[2],
                        ifelse(Month=="12", coefficients[2]+coefficients[22],
                               coefficients[2]+coefficients[2+9+as.numeric(as.character(Month))])))

plot(GSI ~ TD, data=workingdata)

for(i in 1:length(levels(workingdata$Month))){
  ablineclip(a = plotlines$intercept[i],
             b = plotlines$slope[i],
             x1 = plotlines$xmin[i],
             x2 = plotlines$xmax[i],
             col=i, lwd=2)
}

##########################################
# Bigger model: Month, Zone, AND TD      #
##########################################

workingdata <- urchins

mod6 <- lm(GSI ~ TD * Month * Site, data=workingdata)   

summary(mod6) 
# Interaction is NS, but don't worry about that 

drop1(mod6, test="F")

###############################################################
# Match the original paper by looking at size, rather than TD #
###############################################################

a <- ggplot(data = workingdata, aes(x=Size, y=GSI))

a + geom_boxplot() + facet_wrap(Site~Month)



mod7 <- lm(GSI ~ Size*Month*Site, data=workingdata)



summary(mod7)


