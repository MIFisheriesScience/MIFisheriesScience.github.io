# Week 4 - lecture code

# Started Jan 26, 2018

# Brett Favaro

plot.new()
axis(1)
axis(2)
abline(a = 0, b = 1)

plot.new()
axis(1)
axis(2)
abline(a = 0, b = 2, col="red") # Same as Y = 1(x)+1(x)+0


plot.new()
axis(1)
axis(2)
abline(a = 0.5, b = 1, col="blue")


plot.new()
axis(1)
axis(2)
abline(a = 0, b = 2, col="red")

plot.new()
axis(1)
axis(2)
abline(a = 0.5, b = 2, col="darkgreen")