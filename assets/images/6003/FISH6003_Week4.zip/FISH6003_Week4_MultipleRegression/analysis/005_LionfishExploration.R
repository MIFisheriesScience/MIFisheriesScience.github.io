# FISH 6003: Week 4 Data Setup
# Lionfish example
# Data from: Peiffer et al 2017
# https://peerj.com/articles/3818.pdf
# Started: Jan 25, 2018

# Note: You must run 00x_LionfishDataaSetup.R prior to this script.

# We will explore LF_Transects, since that's what we will run stats on
# We may call on AllData as needed

str(LF_Transects)

# Our data are:
# 
# TransectID: Unique identifier for Transect Number
# Site: Factor with six levels - WHERE the transects took place
# Culling: Were lionfish culled? Yes/no
# PercentageCover: Percentage hard coral cover
# SubstrateHEight: Metric of topographic complexity (in cm)
# Richness: # of PREY FISH species observed on a transect
# PreyDensity: Density in fish per hectare of prey fish species, as defined by being < 15 cm
# PredDensity: Density in fish per hectare of predator fish species. 
# Note - in the paper they used biomass. But we can't do that conversion without knowing 
# what growth curve they used. So we will use count

# LF_Density: Density in lionfish per hectare (invasive predator)

# ShannonW: The shannon-weiner index for that transect. Bigger = more diverse. 

###################
# THINKING TOPIC  #
###################

# What type of data are 'density' data?
# i.e. count? continuous measurement? Proportion?

# Remember that as much as possible we want to work with the thing that was actually measured
# What did we do to produce density?
# We... COUNTED
# and... divided by an AREA (and we, as data analysts, are assuming area was in fact fixed)

# So it's really just count data that we have done something to

# We can model this directly by incorporating an 'offset' into our model

# ...but we won't do that right now

# Stay tuned.

###############

# Primary Q:

# Does Culling drive an increase in prey density?

# So: Y = Prey Density

# Potential things to put on X:

# And how is that mediated by:
# - Percentage coral cover
# - Substrate Height
# - Site
# - Density of native predators
# - Density of lionfish
# - Species richness of Prey
# - Shannon Weiner diversity index (Maybe more diverse --> Culling does more? or less?)


# Begin data exploration
# 

# 1. Outliers Y and X
# 2. Homogeneity Y
# 3. Normality Y
# 4. Zero trouble Y
# 5. Collinearity X
# 6. Relationships Y and X
# 7. Interactions
# 8. Independence Y

###########################
# 1. Outliers Y and X     #
###########################

# Y

dotchart(LF_Transects$PreyDensity, main="PreyDensity")

# X
#   Site
table(LF_Transects$Site)

#   Culling
table(LF_Transects$Culling)
#   PercentageCover
dotchart(LF_Transects$PercentageCover, main="CoralCover")

#   SubstrateHeight
dotchart(LF_Transects$SubstrateHeight, main="SubstrateHeight")

#   Richness
dotchart(LF_Transects$Richness, main="Richness")

#   PreyDensity
dotchart(LF_Transects$PreyDensity, main="PreyDensity")

#   PredDensity
dotchart(LF_Transects$PredDensity, main="PredDensity")

#   LF_Density
dotchart(LF_Transects$LF_Density, main="LF_Density")
# Ooh, a lot of zeroes


#   ShannonW
dotchart(LF_Transects$ShannonW, main="ShannonW")

# No outliers 


###########################
# 2. Homogeneity Y        #
###########################

# Check variance of Y against all categorical covariates
# (Site and Culling)

p <- ggplot(data=LF_Transects, aes(x=Site, y=PreyDensity)) +
  geom_boxplot() + facet_wrap(~Culling)
p

# Culling did not occur at each site (Remember this for later)

# Looks like fairly similar variance. Maybe a bit less in the "no" category.


###########################
# 3. Normality  Y         #
###########################

# Is PredDensity normally distributed?

p <- ggplot(data=LF_Transects, aes(x=PreyDensity)) +
  geom_histogram(bins=10)
p 

#or, if you like:
hist(LF_Transects$PreyDensity)

# Not quite normal, but normal enough to proceed

# N.B. In reality, I'd start thinking Poisson-distributed GLM at this point
# but you don't know what that is yet. So just proceed.



###########################
# 4. Zero trouble Y       #
###########################

sum(LF_Transects$PreyDensity == 0) #No zeroes

###########################
# 5. Collinearity X       #
###########################

# X
#   Site
#   Culling
#   PercentageCover
#   SubstrateHeight
#   Richness
#   PredDensity
#   LF_Density
#   ShannonW


# No outliers 

pairs(~ Site + Culling + PercentageCover + SubstrateHeight + Richness + PredDensity + LF_Density + ShannonW, 
      lower.panel=panel.smooth, upper.panel=panel.cor, 
      #additional code to make function work
      data=LF_Transects) 

# Trouble spots:
# - Site x Culling - Because we didn't cull AND not cull in all sites
# (Note how the correlation coefficient didn't catch that)

# - Culling x LF_Density - This is a really tough one! What do we do here?

# Seems most plausible that: 
# culling --> reduced lionfish --> More prey

# But not NECESSARILY true. 

# Can't keep both in the model though, that's for sure

# - ShannonW x Richness

# This makes sense because Richness is a component of diversity and is part of ShannonW, sort of
# Here, put on your ecologist thinking cap
# What is a better metric - raw # of species? Or ShannonW? 

# - ShannonW x PercentCover and SubstrateHeight
# Not surprising that highly complex habitats are also more diverse

# It IS surprising that percentage cover and substrate height 
# are not strongly correlated with each other

###
# Also, weakly colinear:

# LF_Density x Site (did one site just have fewer lionfish all along? Or was it because of culling?)
# PercentageCover x Culling - More coral in culling zones. Is that a cause or effect? Can't know
# Substrate height x percentage cover
# Substrate height x richness


###
# Decisions *I* will make:

# - Eliminate Site. Retain Culling because it's what we want to measure

# Does this create a problem?  (think; independence)

# Could we have designed the study differently to avoid this problem?
# Note: The answer is not always 'yes we could have'
# But, in general, Hurlbert (1986) says:

# Always apply tratemetns WITHIN sites, not just across them.
# Could that have worked in a study like this?


# - Eliminate Richness. Retain ShannonW

# We really want to include a 'diversity' metric because that can drive ecosystem processes
# Richness is a tricky metric to interpret because many rare species can drive it up very far
# ShannonW accounts for this and gives a metric that balances impact of diversity AND abundance

# - Retain ShannonW and habitat metrics PercentageCover and SubstrateHeight

# We are very interested in these and they may not work the same way. 
# Risk: Could cause us to miss 'significant' impacts
# Reward: We get to measure their impact, if the model works

# - Retain Culling, remove LF_Density

# This is perhaps the trickiest decision. But I think we should remove LF_Density
# for two reasons.

# First, experimentally...

plot(LF_Density ~ Culling, data=LF_Transects)

# ... culled sites basically have no lionfish. 

# In the absence of a plausible explanation for this (and because the mechanism is
# explainable) let's assume that yes, culling --> reduces lionfish.

# Second reason to keep Culling:
# - it's what we want to measure! This is essentially a controlled experiment
# so we want to know whether OUR intervention worked

# Could do a second model with lionfish density on Y, culling on X (as we just did) and quantify
# impacts of culling.

#
# To Recap:
# - Remove Site, Richness, LF_Density 

pairs(~ Culling + PercentageCover + SubstrateHeight + PredDensity + ShannonW, 
      lower.panel=panel.smooth, upper.panel=panel.cor, 
      #additional code to make function work
      data=LF_Transects) 

# Still a lot of trouble. May want to reconsider our earlier plan...

# ShannonW may have to go.

# Moving on anyway

#############################
# 6. Relationships Y and X  #
#############################

# Plot all covariates against Y

p <- ggplot(data=LF_Transects, aes(x=Culling, y=PreyDensity)) + geom_boxplot()
q <- ggplot(data=LF_Transects, aes(x=PercentageCover, y=PreyDensity)) + geom_point()
r <- ggplot(data=LF_Transects, aes(x=SubstrateHeight, y=PreyDensity)) + geom_point()
s <- ggplot(data=LF_Transects, aes(x=PredDensity, y=PreyDensity)) + geom_point()
t <- ggplot(data=LF_Transects, aes(x=ShannonW, y=PreyDensity)) + geom_point()

multiplot(p,q,r,s,t, cols = 3)

# What do we see?

# A whole lot of nothing, except Culling

###
# Plot covariates against each other

p <- ggplot(data=LF_Transects, aes(x=Culling, y=PercentageCover)) + geom_boxplot()
q <- ggplot(data=LF_Transects, aes(x=Culling, y=SubstrateHeight)) + geom_boxplot()
r <- ggplot(data=LF_Transects, aes(x=Culling, y=PreyDensity)) + geom_boxplot()
s <- ggplot(data=LF_Transects, aes(x=Culling, y=PredDensity)) + geom_boxplot()
t <- ggplot(data=LF_Transects, aes(x=Culling, y=ShannonW)) + geom_boxplot()

multiplot(p,q,r,s,t, cols = 3)

# Odd - % Cover on Y looks pretty different from their paper

a <- ggplot(data=LF_Transects, aes(x=Culling, y=PercentageCover)) 
a + geom_bar(stat="identity")

plotmeans()


###
q <- ggplot(data=LF_Transects, aes(x=PercentageCover, y=SubstrateHeight)) + geom_point()
r <- ggplot(data=LF_Transects, aes(x=PercentageCover, y=PreyDensity)) + geom_point()
s <- ggplot(data=LF_Transects, aes(x=PercentageCover, y=PredDensity)) + geom_point()
t <- ggplot(data=LF_Transects, aes(x=PercentageCover, y=ShannonW)) + geom_point()
multiplot(q,r,s,t, cols = 2)



###

q <- ggplot(data=LF_Transects, aes(x=SubstrateHeight, y=PercentageCover)) + geom_point()
r <- ggplot(data=LF_Transects, aes(x=SubstrateHeight, y=PreyDensity)) + geom_point()
s <- ggplot(data=LF_Transects, aes(x=SubstrateHeight, y=PredDensity)) + geom_point()
t <- ggplot(data=LF_Transects, aes(x=SubstrateHeight, y=ShannonW)) + geom_point()
multiplot(q,r,s,t, cols = 2) # Negative: Shannon W on Y, Substrate on X



q <- ggplot(data=LF_Transects, aes(x=PredDensity, y=PercentageCover)) + geom_point()
r <- ggplot(data=LF_Transects, aes(x=PredDensity, y=PreyDensity)) + geom_point()
s <- ggplot(data=LF_Transects, aes(x=PredDensity, y=SubstrateHeight)) + geom_point()
t <- ggplot(data=LF_Transects, aes(x=PredDensity, y=ShannonW)) + geom_point()

multiplot(q,r,s,t, cols = 2)


q <- ggplot(data=LF_Transects, aes(x=ShannonW, y=PercentageCover)) + geom_point()
r <- ggplot(data=LF_Transects, aes(x=ShannonW, y=PreyDensity)) + geom_point()
s <- ggplot(data=LF_Transects, aes(x=ShannonW, y=SubstrateHeight)) + geom_point()
t <- ggplot(data=LF_Transects, aes(x=ShannonW, y=PredDensity)) + geom_point()

multiplot(q,r,s,t, cols = 2)
#############################
# 7. Interactions           #
#############################

# Is the relationship between TD and GSI mediated by month or site? 

coplot(PreyDensity ~ PercentageCover | Culling,
       data=LF_Transects,
       panel=function(x,y,...) {
         panel.smooth(x,y,span=0.8,iter=5,...)
         abline(lm(y ~ x), col="blue") } )

coplot(PreyDensity ~ SubstrateHeight | Culling,
       data=LF_Transects,
       panel=function(x,y,...) {
         panel.smooth(x,y,span=0.8,iter=5,...)
         abline(lm(y ~ x), col="blue") } )

coplot(PreyDensity ~ PredDensity | Culling,
       data=LF_Transects,
       panel=function(x,y,...) {
         panel.smooth(x,y,span=0.8,iter=5,...)
         abline(lm(y ~ x), col="blue") } )

coplot(PreyDensity ~ ShannonW | Culling,
       data=LF_Transects,
       panel=function(x,y,...) {
         panel.smooth(x,y,span=0.8,iter=5,...)
         abline(lm(y ~ x), col="blue") } )

# Does look to be some fairly different slopes, doing some very weird things

# As coral cover goes up, prey density GOES DOWN in culled sites!?
# 
# Perhaps complex habitat produces lower detection probaibility of tiny little prey fish?

# Predator density is associated with more prey at culled sites, but at unculled
# prey get LESS dense with more predators. Hard to interpret. Shallow slopes. Lots of noise

# Higher shannon W --> higher prey density at culled sites, but not unculled

# SO, interactions we should look carefully at:

# Culling*CoralCover, Culling*ShannonW

#############################
# 8. Independence Y         #
#############################

# There's no magical test for 'independence.' We need to consider the structure of our data.

# Go back to our sketch of the study design. 

# Each transect is now one row of data

# Transects were nested within sites. But we already decided we can't put both site and culling in the model

# We can't put "site" as a "random effect" Because there aren't enough levels (more on this later)

# Better hope for the best!


###########################
# RECAP:
# 1. Outliers Y and X: None
# 2. Homogeneity Y: Seems okay. A little less variance in 'no culling' condition.
# 3. Normality Y: Might be closer to poisson. Be aware we're being sketchy using 'density' here.
# 4. Zero trouble Y: Nope
# 5. Collinearity X: 
# - Lots
# - Removed Site, Richness, Lionfish density
# - Beware - shannon weiner x coral cover and shannon weiner x topographic complexity is bad too
# 
# 6. Relationships Y and X: 
# 
# - Most X's don't seem to affect Y 
# - Culling --> Way more prey density
# 
# 7. Interactions: Keep an eye on:
# - Culling x coral cover
# - Culling x ShannonW
#
# 8. Independence Y: Each transect is nested within Site. But can't keep Site in model due to #5.
