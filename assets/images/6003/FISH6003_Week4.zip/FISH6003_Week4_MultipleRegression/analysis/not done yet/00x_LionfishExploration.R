# FISH 6003: Week 4 Data Setup
# Lionfish example
# Data from: Peiffer et al 2017
# https://peerj.com/articles/3818.pdf
# Started: Jan 25, 2018

# Note: You must run 00x_LionfishDataaSetup.R prior to this script.

# Our data are:
# 
# Site: Factor: One of a number of distinct sites in which data were collected
# Transect: Number: A number specifying which transect an observation occurred on.
# Family: Factor: Family name
# Species: Factor: Common name
# Scientific.name: Factor: Scientific name of species
# Size: Integer: Total length of each fish (cm)
# Fish_type: Factor: Lionfish (i.e. an invasive predator), Native Predator, or prey fish
# Category: Type of coral cover being measured. Only one value: Hard Coral. 
# Percentage.cover: Percentage of coral cover as measured on each transect. Everything else is 'not coral'
# Culling: Factor: THE MAJOR THING THEY MANIPULATED. Culling was either occurring "yes" or not "no." 
# Substrate_height: A metric of topographic complexity. See data preparation above
# TransectID: Factor: A unique identifier for each transect. 

###############

# In their paper, they looked at diversity and abundance of prey species
# So, we have to do some additional math

# Core question: "Does culling increase both?"

# But there are lots of other possibilities. Maybe coral cover, substrate height, etc. drive these effects?

# 





# Site: One of two places in Italy. Su Pallosu Bay 
# (high fishing area, not a Marine Protected Area, MPA) or Tavolara MPA (low fishing pressure).
# Bear in mind that Site is really Fishing/NoFishing
# Area: Two fishing areas within each site, labelled as A, B, C, D, respectively
# Size: Size of each urchin caught. CS = Commercial Size (Test Diameter, spines removed > 50 mm)
#                               US = Undersized (TD between 40 and 50 mm) 
#                               Small-US = Smaller undersized (TD between 30 and 40 mm)
# Code: A unique individual ID for each urchin. Should be one code per urchin

# Per the author, the way the code works was, for example:
# 6SA1G1 - June (6) 
#         - Zone Su Pallosu (S)
#         - Area (A)
#         - Station(1)
#         - Size - CS = G
#         - Sample #. Here, 1

# TD: Test Diameter in mm. The diameter of the round part of the urchin 
# TW: Total Wet Weight in g
# GW: Gonadal Wet Weight in g
# GSI: Gonadosomatic Index. Calculated as GSI = (GW / TW) * 100.
# Sex: M or F
# Month: 1-12, aka Jan - Dec. No sampling in Nov.

# Note: In reality there will be two sources of measurement error inserted into GSI: 
# 1. Error associated with measuring GW
# 2. Error associated with measuring TW
# No need to obsess over that. Just be aware. 

# There are many X's:
#   Site
#   Area
#   Size
#   Test diameter TD
#   Sex
#   Month

# Q. Why am I not using TW or GW as an X value?
# A. Because GSI is calcualted from GW and TW. 

# Don't have the same thing on both X and Y. 
# THIS IS IMPORTANT whenever you're plotting an index. 
# Always know what goes into the index!!!

# We need to do a robust exploration before moving forward

# RECAP:
# 1. Outliers Y and X
# 2. Homogeneity Y
# 3. Normality Y
# 4. Zero trouble Y
# 5. Collinearity X
# 6. Relationships Y and X
# 7. Interactions
# 8. Independence Y

###########################
# 1. Outliers Y and X     #
###########################

# Y

dotchart(urchins$GW, main="GSI")

# X
#   Site
#   Area
#   Size
#   TD
dotchart(urchins$TD, main="TD") #Why is there banding?
#   Sex
#   Month

# One TD point is a little on the high side. 
# We already looked at this previously.

# What if you wanted to organize by some other variable?

dotchart(urchins$TD, groups=factor(urchins$Sex)) #By sex
dotchart(urchins$TD, groups=factor(urchins$Site)) # By Site

# What to do with outliers? 
# Totally depends on situation
# - Eliminate them
# - Correct entry errors

###########################
# 2. Homogeneity Y        #
###########################

# Let's check our Y against all X's

# Take care of sex, area, which also has Site 
# (Because A and B are only at Site 1... more on that later)

p <- ggplot(data=urchins, aes(x=Sex, y=GSI)) +
  geom_boxplot() + facet_wrap(~Area)
p

# Remaining: size, month

p <- ggplot(data=urchins, aes(x=Month, y=GSI)) +
  geom_boxplot() + facet_wrap(~Size)
p

# Big trouble. 

# So variation totally changes across levels.

###########################
# 3. Normality  Y         #
###########################

# Is GSI normally distributed?

p <- ggplot(data=urchins, aes(x=GSI)) +
  geom_histogram()
p #nope

# We don't know quite what this is yet because it's only week 2. (Looks to be Poisson)

# We could try to transform this. 
# But would we lose other variation in doing so?

# Let's have a look at some other variables

p <- ggplot(data=urchins, aes(x=GSI)) +
  geom_histogram() + facet_wrap(~Sex)
p

p <- ggplot(data=urchins, aes(x=GSI)) +
  geom_histogram() + facet_wrap(~Month)
p #check out month 2 and 3!

p <- ggplot(data=urchins, aes(x=GSI)) +
  geom_histogram() + facet_wrap(~Area)
p 

p <- ggplot(data=urchins, aes(x=GSI)) +
  geom_histogram() + facet_wrap(~Size)
p 

# Looks like they all share similar distributions for the most part.

# So NO, GSI is not normally distributed, 
# and we can't clearly explain it by a 
# relationship with another variable.

###########################
# 4. Zero trouble Y       #
###########################

plot(table(urchins$GSI)) # No zeroes at all
sum(urchins$GSI == 0) #No, really, there are no zeroes

###########################
# 5. Collinearity X       #
###########################

pairs(~ Area + Site + Size + TD + Sex + Month, 
      lower.panel=panel.smooth, upper.panel=panel.cor, 
      #additional code to make function work
      data=urchins) 

# A bunch of colinear things going on here:
# - Area vs Site
# - Size vs TD
# Site and TD are a bit dodgy too... 
# but probably not enough to exlude

# So which do we keep?

# - Area vs. Site
# Site is meaningful: MPA vs. Not MPA. 
# Do we care about Area? A priori I don't think so

plot(GSI ~ Area, data=urchins) #No areas are behaving wildly differently
plot(GSI ~ Site, data=urchins) 

# I vote we keep in Site and exclude area. What do you think?

# Well, I'm the one writing the code, so we're keeping site.

# - Size vs. TD
# Size is just a categorical version of TD. 

plot(TD ~ Size, data=urchins) 
# TD is biologically meaningful. 
# Size isn't (it's a just a legal size limit)
# Size has different variances across each category. 
# Could be trouble down the road

# Let's get rid of Size

# So our X's are now: 

pairs(~ Site + TD + Sex + Month, 
      lower.panel=panel.smooth, upper.panel=panel.cor, #additional code to make function work
      data=urchins) 

# Now that the matrix is smaller, Site X TD doesn't look great.
# Neither does TD X Sex. Sex is extra weird 

# Should we drop one, or should we press on? This time it's harder - they're two different things
# Think about the interpretation.

# What if we find that MPA's produce higher GSI's (good thing!)
# Try to imagine the mechanism:
# Is the MPA itself actually increasing GSI? 

# Or is it that MPA's actually produce higher TD's - and bigger urchins have higher GSI
# whether they're in an MPA or NOT?

# Executive decision: leave them both in, hope for the best.

#############################
# 6. Relationships Y and X  #
#############################

# Plot all covariates against Y

p <- ggplot(data=urchins, aes(x=Site, y=GSI)) + geom_boxplot()
q <- ggplot(data=urchins, aes(x=TD, y=GSI)) + geom_point()
r <- ggplot(data=urchins, aes(x=Sex, y=GSI)) + geom_boxplot()
s <- ggplot(data=urchins, aes(x=Month, y=GSI)) + geom_boxplot()

multiplot(p,q,r,s, cols = 2)



# What do we see?
# Slightly higher GSI in Tavolara
# Lower GSI in urchins with no data on sex. 
# Maybe n.d. ones are really small?

t <- ggplot(data=urchins, aes(x=Sex, y=TD)) + geom_boxplot()
t # Ahh... That makes ecological sense. Very small ones may be too small to accurately sex?

# Let's add a smoother 

# Looks like GSI increases with TD 
# but the variance certainly increases along with the mean
# Add a smoother

q + stat_smooth() #That dropoff on the right is a bit of a surprise.
# It this because of the X outlier?

# Let's check

temp <- urchins %>%
  filter(TD<80)

u <- ggplot(data=temp, aes(x = TD, y = GSI)) + geom_point() + stat_smooth()
u # Nope, still bends down.

# There's also some sort of a pattern by month. Seems Jan-March GSI values are higher. 
# Not a linear pattern. Generalized Additive Model may be needed
# Bear this in mind for later.

# One more thing... Good to plot covariates against each other too

p <- ggplot(data=urchins, aes(x=Site, y=TD)) + geom_boxplot()
q <- ggplot(data=urchins, aes(x=Month, y=Sex)) + geom_jitter()
r <- ggplot(data=urchins, aes(x=Sex, y=Site)) + geom_jitter()

multiplot(p,q,r, cols = 3) 
# A few things:
# 1. Urchins are slightly bigger in Tavolara. Warning: Is it the MPA, or the TD driving increased urchin size? 
# How do we know that it's the actual MPA that is causing GSI to increase? Maybe urchins are just bigger there?
# 2. Roughly equal number of M, F, and ND in both sites. That's good
# 3. While M and F are reasonably balanced across sexes, ND is a bit less in Months 1-3. Oh well.

#############################
# 7. Interactions           #
#############################

# Is the relationship between TD and GSI mediated by month or site? 

coplot(GSI ~ TD | Month * Site,
       data=urchins,
       panel=function(x,y,...) {
         panel.smooth(x,y,span=0.8,iter=5,...)
         abline(lm(y ~ x), col="blue") } )

# Uh oh. Our slope changes a lot across months and site. 
# There may be an interaction going on here.

# What about by sex?

coplot(GSI ~ TD | Month * Sex,
       data=urchins,
       panel=function(x,y,...) {
         panel.smooth(x,y,span=0.8,iter=5,...)
         abline(lm(y ~ x), col="blue") } )

# Can't really assess the n.ds due to low data. 
# Sign of slope even changes in March! Definitely going to need to investigate 

coplot(GSI ~ TD | Sex * Site,
       data=urchins,
       panel=function(x,y,...) {
         panel.smooth(x,y,span=0.8,iter=5,...)
         abline(lm(y ~ x), col="blue") } ) 

# Not much going on here. Happy to exlude Site by Sex interaction

# Need to consider Sex by Month, Month by Site interactions. 
# Do those make ecological sense?

# Should we test them?

#############################
# 8. Independence Y         #
#############################

# There's no magical test for 'independence.' We need to consider the structure of our data.

# Go back to our sketch of the study design. 

# We know there is a spatial structure. Think it through... All else being equal, would a random urchin taken from 
# inside the MPA be more likely to be similar to:
# - An urchin in the MPA?
# - An urchan at the other site?

# I think it's fair to say they're not totally independent, and "Site" would need to be modelled

# What about "Area?" We could use that in the model instead of Site if we want (recall, they are colinear. 
# We can use either. And we haven't actually done any stats yet)

# There's definitely temporal dependence... we have to account for the fact that GSI differs across months. 

###########################
# RECAP:
# 1. Outliers Y and X: Looks fine. There's one big TD but it doesn't do much. Leave it alone.
# 2. Homogeneity Y: Sex: N.D. has less variance than others. Massive changes in GSI variance across months.
# 3. Normality Y: Violations all over the place. This will either need a transformation or a GLM (come back later)
# 4. Zero trouble Y: No zeroes in dataset.
# 5. Collinearity X: 
# - Area A and B are only in Site 1, Area C and D are only in Site 2. Can't keep both in model. Pick one (probably site)
# - Size vs TD. Size is just calculated from TD. Keep TD, boot Size.
# Everything else seems fine
# 6. Relationships Y and X: 
# SLightly higher GSI in Tavolara. Females seem to have highest GSI. N.Ds have lowest. 
# GSI increases with TD linearly across most of data range, 
# but then something happens on the right where it drops. Possible non-linear pattern?
# Jan Feb March have much higher GSI than other months. 
#
# Plotting covariates against each other revealed that urchins in the MPA had higher TD.
# We had roughly equal numbers of F and M in and out of MPA, and across months.

# 7. Interactions: GSI ~ TD relationship does change across months and site. Interaction appears likely.
# 
# 8. Independence Y: See above. Must consider geographical and temporal structure of data. 
# Site and month must be in the model
