# FISH 6003: Week 4 Analysis

# Started: Jan 29, 2018

str(LF_Transects) # We're working with this Transect data frame

# Recall:
# 
# TransectID: Unique identifier for Transect Number
# Culling: Were lionfish culled? Yes/no
# PercentageCover: Percentage hard coral cover
# SubstrateHeight: Metric of topographic complexity (in cm)
# PreyDensity: Density in fish per hectare of prey fish species, as defined by being < 15 cm
# PredDensity: Density in fish per hectare of predator fish species. 
# ShannonW: The shannon-weiner index for that transect. Bigger = more diverse. 

# DO NOT USE:
# Site: Factor with six levels - WHERE the transects took place
# Richness: # of PREY FISH species observed on a transect
# LF_Density: Density in lionfish per hectare (invasive predator)

# Hypothesis: Culling --> higher prey density

# as mediated by:
# - ShannonW, PredDensity, PercentageCover, SubstrateHeight

# Here we go:

mod <- lm(PreyDensity ~ Culling + ShannonW + PredDensity + PercentageCover + SubstrateHeight + Culling*PercentageCover + Culling*ShannonW,
     data=LF_Transects)

summary(mod)

# But, recall that ShannonW is colinear with a couple things in the model.

# What impact does it have on results if we remove its interaction?

mod2 <- lm(PreyDensity ~ Culling + ShannonW + PredDensity + PercentageCover + SubstrateHeight + Culling*PercentageCover,
          data=LF_Transects)

summary(mod2)

# and if we remove it entirely?

mod3 <- lm(PreyDensity ~ Culling + PredDensity + PercentageCover + SubstrateHeight + Culling*PercentageCover,
           data=LF_Transects)

summary(mod3)

# Takeaway: Lines of code needed to run model: 2
# Lines of code needed to prep data for model; 923 (with comments, that is)

# Ponder this as you lay out your spreadsheets. 

#################################################################################
# Next week: Did this fit? How do we visualize more complex models like these?  #
# How should we pick what covariates stay in the model?                         #
#################################################################################


##########################################################################
# Students: you won't get this next part yet... just checking something  #
##########################################################################

# Best option: Convert density back to count, incorporate offset, use Poisson GLM
# Still need to check overdispersion tho

# Save for GLM-Poisson lecture

temp <- LF_Transects %>%
  mutate(PreyCount = PreyDensity*0.005) %>%
  mutate(area = 0.005)

mod8 <- glm(PreyCount ~ Culling + ShannonW + PredDensity + PercentageCover + SubstrateHeight + Culling*PercentageCover + Culling*ShannonW
           + offset(log(area)), data=temp)

summary(mod8)


mod9 <- glm(PreyCount ~ Culling + PredDensity + PercentageCover + SubstrateHeight + Culling*PercentageCover + 
            offset(log(area)), data=temp)

summary(mod9)

mod10 <- glm(PreyCount ~ Culling + PredDensity + SubstrateHeight + Culling*PercentageCover + 
              offset(log(area)), data=temp)

summary(mod10)

mod11 <- glm(PreyCount ~ Culling + PredDensity + SubstrateHeight +  
               offset(log(area)), data=temp)

summary(mod11) #worse

mod12 <- glm(PreyCount ~ Culling + SubstrateHeight + Culling*PercentageCover + 
               offset(log(area)), data=temp)

summary(mod12)

mod13 <- glm(PreyCount ~ Culling * PercentageCover + 
               offset(log(area)), data=temp)

summary(mod13) #equally supported, but way better than the original lm

plot(mod13)

