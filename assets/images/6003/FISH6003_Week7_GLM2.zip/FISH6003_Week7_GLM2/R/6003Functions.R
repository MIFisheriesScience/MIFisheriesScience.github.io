# FISH 6003 all functions

# Pair plot function, with correlations 

# Source unkonwon

panel.cor <- function(x, y, digits=2, prefix="", cex.cor) 
{
  usr <- par("usr"); on.exit(par(usr)) 
  par(usr = c(0, 1, 0, 1)) 
  r <- abs(cor(x, y)) 
  txt <- format(c(r, 0.123456789), digits=digits)[1] 
  txt <- paste(prefix, txt, sep="") 
  if(missing(cex.cor)) cex <- 0.8/strwidth(txt) 
  
  test <- cor.test(x,y) 
  # borrowed from printCoefmat
  #Signif <- symnum(test$p.value, corr = FALSE, na = FALSE, 
                  # cutpoints = c(0, 0.001, 0.01, 0.05, 0.1, 1),
                  # symbols = c("***", "**", "*", ".", " ")) 
  
  text(0.5, 0.5, txt, cex = cex * (r+.2)) 
  #text(.8, .8, Signif, cex=cex, col=2) 
}

###
# from http://www.cookbook-r.com/Graphs/Multiple_graphs_on_one_page_(ggplot2)/

# Multiple plot function
#
# ggplot objects can be passed in ..., or to plotlist (as a list of ggplot objects)
# - cols:   Number of columns in layout
# - layout: A matrix specifying the layout. If present, 'cols' is ignored.
#
# If the layout is something like matrix(c(1,2,3,3), nrow=2, byrow=TRUE),
# then plot 1 will go in the upper left, 2 will go in the upper right, and
# 3 will go all the way across the bottom.
#
multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  library(grid)
  
  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)
  
  numPlots = length(plots)
  
  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                     ncol = cols, nrow = ceiling(numPlots/cols))
  }
  
  if (numPlots==1) {
    print(plots[[1]])
    
  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))
    
    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))
      
      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}


############
# SUPER SCATTER###
##############

library(scatterplot3d) 
library(VGAM)

SuperScatter <- function(X, Y, ymin, ymax, fitted_model, distribution_type) {
  # distribution_type can be 
  # - Gaussian
  # - Poisson
  # - NegBin
  
  MyData <- data.frame(X = seq(from = min(X),
                               to = max(X),
                               length = 25))
  
  Matrix <- model.matrix(~ X, data=MyData)
  
  if(distribution_type=="Gaussian"){
    MyData$mu <- Matrix %*% coef(fitted_model)
  } else {
    MyData$mu <- exp(Matrix %*% coef(fitted_model))
  }
  
  x      <- MyData$X
  y      <- MyData$mu
  z      <- 0 * x
  
  par(mfrow = c(1, 1))
  rr<- scatterplot3d(X, 
                     Y,
                     rep(0, length(X)), 
                     highlight.3d = FALSE, 
                     col.axis = "black",
                     col.grid = "black", 
                     pch = 20,
                     zlim = c(0, 0.3),
                     ylim = c(ymin, ymax),
                     type="p",
                     grid = FALSE,
                     box = TRUE,
                     cex.lab = 1.5,
                     xlab = "X value",
                     ylab = "Possible values",
                     zlab = "Probability")
  
  if(distribution_type=="Gaussian"){
    model_colour <- 1
  } 
  if (distribution_type=="Poisson"){
    model_colour <- "blue"
  }
  if (distribution_type=="NegBin"){
    model_colour <- 2
  }
  
  rr$points3d(x, y, z, 
              lwd = 3, 
              col = model_colour,
              type = "l")
  
  MyDatai <- data.frame(X = seq(from = quantile(MyData$X, 0.15),
                                to   = 0.99 * max(MyData$X),
                                length = 8))
  
  K <- length(MyDatai$X)    
  
  for (i in 1:K){
    Xi   <- model.matrix(~ X, data = MyDatai)[i,]
    yseq <- round(seq(ymin, ymax, by = 1))
    
    if (distribution_type=="Gaussian") {
      mu.i <- Xi %*% coef(fitted_model)
      zi  <- dnorm(yseq, mean = mu.i, sd = summary(fitted_model)$sigma)
      
      rb = cbind(MyDatai$X[i], yseq, 0)
      rr$points3d(rb, col = "darkgrey", type = "l", pch = ".", lty = 2)
      
      rb = cbind(MyDatai$X[i]- 0.05, yseq, zi)
      rr$points3d(rb, col = model_colour, type = "h", pch = ".", lwd = 1)
    }
    if (distribution_type=="Poisson") {
      muPois.i <- exp(Xi %*% coef(fitted_model))
      zi  <- dpois(yseq, lambda = muPois.i)
      
      rb = cbind(MyDatai$X[i], yseq, 0)
      rr$points3d(rb, col = "darkgrey", type = "l", pch = ".", lty = 2)
      
      rb = cbind(MyDatai$X[i]- 0.05, yseq, zi)
      rr$points3d(rb, col = model_colour, type = "h", pch = ".", lwd = 1)  
      
    }
    if (distribution_type=="NegBin") {
      # theta <- summary(fitted_model)$theta
      
      muNB.i <- exp(Xi %*% coef(fitted_model))
      zi.nb  <- dnbinom(yseq, size=fitted_model$theta, mu=muNB.i)
      
      rb = cbind(MyDatai$X[i], yseq, 0)
      rr$points3d(rb, col = "darkgrey", type = "l", pch = ".", lty = 2)
      
      rb = cbind(MyDatai$X[i], yseq, zi.nb)
      rr$points3d(rb, col = model_colour, type = "h", pch = ".", lwd = 2)   
      
      
    }
    
    
  }
  
  
  
  
}
