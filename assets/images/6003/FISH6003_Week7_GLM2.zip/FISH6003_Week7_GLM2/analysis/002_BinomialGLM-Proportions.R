# Week 7: FISH 6003

#### 
source("./R/6003Functions.R")
library(tidyverse)
library(visreg)
library(betareg)

mag <- read.csv("./data/SharkMagnets.csv")

str(mag)

mag <- mag %>%
  mutate(NoCatch = Hooks-Catch)

mag

plot(magprop~Type, data=mag)

m <- glm(cbind(Catch, NoCatch) ~ Type, 
         family = binomial, 
         data = mag)


summary(m)
visreg(m, scale="response")

exp(coef(m))/(1+exp(coef(m)))

plot(m)

plot(m$residuals ~ m$fitted.values)

abline(h=0, lty=2)

E1 <- resid(m, type = "pearson")
N  <- nrow(mag)
p  <- length(coef(mag))
sum(E1^2) / (N - p)

########################
# Model rates directly #
########################

n <- betareg(CPUE ~ Type, data=mag)

summary(n)

visreg(n, scale="response") # Note Visreg doesn't work here

