#FISH 6003, week 7: GLMs part 2
# Exercise 3: Simulating from a model

# Started 21 Feb, 2018

# Simulation code from Zuur et al (2016) 

library(tidyverse)
library(MASS)

source("./R/6003Functions.R")

####################
# EXAMPLE 1: Terns #
####################

terns <- read.csv("./data/6003_terns.csv")

mod.nb <- glm.nb(wrecks ~ hurricanes, data=terns)

# SIMULATE
N <- nrow(terns)
gg <- simulate(mod.nb, 10000)


zeros <- vector(length = 10000)
for (i in 1:10000){
  zeros[i] <- sum(gg[,i] == 0) / N
}

par(mar = c(5,5,2,2), cex.lab = 1.5)
plot(table(zeros), 
     xlim = c(0, 0.5),
     axes = FALSE,
     xlab = "Percentage of zeros",
     ylab = "Frequency")
axis(2)
axis(1, at = c(0.05, .10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45),
     labels = c("5%", "10%", "15%", "20%", "25%", "30%", "35%", "40%", "45%"))     
points(x = sum(terns$wrecks==0) / N, y = 0, pch = 16, cex = 5, col = 2)

############################
# EXAMPLE 2: Shark magnets #
############################

mag <- read.csv("./data/SharkMagnets.csv")
mag <- mag %>%
  mutate(NoCatch = Hooks-Catch)

m <- glm(cbind(Catch, NoCatch) ~ Type, 
         family = binomial, 
         data = mag)

# SIMULATE
N <- nrow(mag)
gg <- simulate(m, 10000)

zeros <- vector(length = 10000)
for (i in 1:10000){
  zeros[i] <- sum(gg[,i] == 0) / N
}

par(mar = c(5,5,2,2), cex.lab = 1.5)
plot(table(zeros), 
     xlim = c(0, 0.5),
     axes = FALSE,
     xlab = "Percentage of zeros",
     ylab = "Frequency")
axis(2)
axis(1, at = c(0.05, .10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45),
     labels = c("5%", "10%", "15%", "20%", "25%", "30%", "35%", "40%", "45%"))     
points(x = sum(mag$Catch==0) / N, y = 0, pch = 16, cex = 5, col = 2)

