# FISH 6003: Week 2 Data Exploration

# Started: Jan 16, 2018

# Note: Run the following in their entirety prior to this script:
#       001_DataSetup.R 
#       002_Exploration.R

str(urchins) # Recall we retained only TD and GW. We are pretending we're super data-limited.

# Time to run the model

# RECAP:
# 1. Outliers Y and X: Some extreme values, but we chose not to eliminate. They seem fine.
# 2. Homogeneity Y: Skip
# 3. Normality Y: GW is very non-normal.
# 4. Zero trouble Y: No zeroes in dataset.
# 5. Collinearity X: N/A
# 6. Relationships Y and X: GW increases with TD. Variance appears to increase with mean (Poisson?)
# 7. Interactions: N/A
# 8. Independence Y: N/A

# Model:

# Recall from high school:
# Y = mx + B
# Y = GW
# X = TD
# B = ??
# m = ??

# Fit a linear model.



