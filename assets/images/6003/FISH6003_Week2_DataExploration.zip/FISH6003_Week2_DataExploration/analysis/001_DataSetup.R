# FISH 6003: Week 2 Data Setup

# Started: Jan 15, 2018

library(tidyverse)

source("./R/6003Functions.R")

# Load the data file
# It is not tidied, aside from it being saved as a CSV

urchin_untidy <- read.csv("./data/Supplemental_Dataset_S8.csv") 

# Let's see what we have

head(urchin_untidy)
str(urchin_untidy)

# Per the paper, variables are
#
# Site: One of two places in Italy. Su Pallosu Bay (A high fishing area, not a Marine Protected Area, MPA) or Tavolara MPA (low fishing pressure).
# Bear in mind that Site is really Fishing/NoFishing
# Area: Two fishing areas within each site, labelled as A, B, C, D, respectively
# Size: Size of each urchin caught. CS = Commercial Size (Test Diameter, spines removed > 50 mm)
#                               US = Undersized (TD between 40 and 50 mm) 
#                               Small-US = Smaller undersized (TD between 30 and 40 mm)
# Code: A unique individual ID for each urchin. Should be one code per urchin

# Per the author, the way the code works was, for example:
# 6SA1G1 - June (6) 
#         - Zone Su Pallosu (S)
#         - Area (A)
#         - Station(1)
#         - Size - CS = G
#         - Sample #. Here, 1

# TD: Test Diameter in mm. The diameter of the round part of the urchin 
# TW: Total Wet Weight in g
# GW: Gonadal Wet Weight in g
# GSI: Gonadosomatic Index. Calculated as GSI = (GW / TW) * 100.
# Sex: M or F
# X and X.1 - appears to be entry error. 

# One row = One urchin.

#####################
# Clean the data    #
#####################

urchins <- urchin_untidy # If we ever need to go back to original dataset we can

# Are data types what they should be?
# Are there impossible values (numbers) or incorrect factor levels? (factors?)

# Site: Should be a factor with two levels

levels(urchins$Site) # Looks fine

# Area: Factor with four levels A, B, C, D

levels(urchins$Area) # Good, but better also check to make sure A and B are only in SuPallosuBay, and C and D in the MPA

table(urchins$Site, urchins$Area) # Good

# Size: Factor with three levels CS, Small-US, US

levels(urchins$Size) # Good

# Code: It is a factor, but we must check unique levels

plot(table(urchins$Code)) # One way to check

urchins %>% #Another way to check. Return only rows with the same code appearing more than once
  group_by(Code) %>%
  filter(n() > 1) # Nope

# Code is good

# But, after emailing the author, we can get more info:
# Per the author, the way the code works was, for example:
# 6SA1G1 - June (6) 
#         - Zone Su Pallosu (S)
#         - Area (A)
#         - Station (1)
#         - Size - CS = G
#         - Sample #. Here, 1

# Let's pull out month, just so we have it. 
# Author said they didn't include 'station' so 
# let's forget about it.

# Problem: The codes aren't consistently spaced... 
# e.g. months 1-9 have different # of chars vs. 10, 11, 12.
# Sometimes months are 01, sometimes 1.
# But we know it goes NUMBER NUMBER LETTER or NUMBER LETTER
# So, let's pull out the first two characters of every code

temp <- urchins$Code

temp <- temp %>%
  substr(start=1, stop=2) #Take string positions 1 and 2

temp <- gsub("[^0-9]", "", temp) #drop letters

temp <- as.numeric(temp) # Make it a number to drop leading zeroes

temp <- as.factor(temp) # Turn it back into a factor. Don't forget - this is MONTH
  
urchins <- urchins %>%
  mutate(Month = temp) 

# Woohoo now we can work with month

# TD: should be an integer - they measured test diameter to nearest mm. 

plot(urchins$TD) # is a number, looks reasonable. Keep an eye on that high point maybe.

# TW: should be a number

plot(urchins$TW) # uh oh

# Save this code for later: It finds any non-numeric values in a factor

which(
  is.na(
    as.numeric(
      as.character(urchins$TW)
    )
  )
) # Trouble in row 141

urchins[141,6] # aha.

# What to do? 
# - Call the authors and find out true value
# - Drop the row
 
# We have lots of data, and I'm lazy. Dropping the row. 
# We could do it one row at a time, or just get rid of everything that is non-numeric:

urchins <- filter(urchins, TW!="na") #removes one row

# Make it a number again. When converting factor to number do it like this:

urchins$TW <- as.numeric(as.character(urchins$TW))

plot(urchins$TW) # Looks good

# GW: Gonadal wet weight.

plot(urchins$GW) # damn, again!?

which(
  is.na(
    as.numeric(
      as.character(urchins$GW)
    )
  )
) # Missing many this time
# Strangely, the paper says they ony incorporated 330 
# specimens into this part of the analysis

# Yet they seem to have data for way more. Unclear as to why

# Emailed the author.
# Discovered what was actually done:
# Within each area (2) catch 40 CS, 20 US, 20 Small-US, (80), in each of 11 months
# So: 2 * 80 * 11 = 880, with some missing values I guess

# Still not clear why only 330 used in the paper's ANOVA, but let's carry on.




# How many missing values are there for GW?

table(is.na(as.numeric(as.character(urchins$GW)))) 

# 319. 18% of the data!!

# Regardless, if we don't have it, we don't have it. Goodbye.

urchins <- filter(urchins, GW!="na") 

urchins$GW <- as.numeric(as.character(urchins$GW))

plot(urchins$GW) # Looks fine

# GSI: I never trust anything pre-calculated
# GSI = (GW / TW) * 100.

urchins <- urchins %>%
  mutate(BrettsGSI = (GW / TW) * 100)

# Check to see if new one is same as old
plot(urchins$GSI ~ urchins$BrettsGSI) 
#Almost a perfectly straight line. Looks like we can use THEIR GSI

urchins <- urchins %>%
  select(-BrettsGSI) %>% # Remove my new variable
  select(-X) %>% #Get rid of these while we're at it
  select(-X.1)

# Last one: Sex

levels(urchins$Sex) # oopsie

levels(urchins$Sex) <- list("F"=c("f", "F"), 
                                      "M"=c("m", "M"),
                                      "nd" = c("nd"))

levels(urchins$Sex) # that's better

###################
# ONE MORE THING  #
###################
# Let's make sure "Size" is classified right. i.e.:
#                               CS = Commercial Size (Test Diameter, spines removed > 50 mm)
#                               US = Undersized (TD between 40 and 50 mm) 
#                               Small-US = Smaller undersized (TD between 30 and 40 mm)
# 
# 

plot(urchins$TD ~ urchins$Size)
abline(h=50)
abline(h=40)

# I can sleep soundly.

# Data verification complete. Move on to exploration
