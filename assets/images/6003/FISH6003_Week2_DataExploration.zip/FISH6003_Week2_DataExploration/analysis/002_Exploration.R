# FISH 6003: Week 2 Data Exploration

# Started: Jan 15, 2018

# Note: 001_DataSetup.R must be run prior to this script.

str(urchins)

# Recall, vars are:

# Site: One of two places in Italy. Su Pallosu Bay (high fishing area, not a Marine Protected Area, MPA) or Tavolara MPA (low fishing pressure).
# Bear in mind that Site is really Fishing/NoFishing
# Area: Two fishing areas within each site, labelled as A, B, C, D, respectively
# Size: Size of each urchin caught. CS = Commercial Size (Test Diameter, spines removed > 50 mm)
#                               US = Undersized (TD between 40 and 50 mm) 
#                               Small-US = Smaller undersized (TD between 30 and 40 mm)
# Code: A unique individual ID for each urchin. Should be one code per urchin

# Per the author, the way the code works was, for example:
# 6SA1G1 - June (6) 
#         - Zone Su Pallosu (S)
#         - Area (A)
#         - Station(1)
#         - Size - CS = G
#         - Sample #. Here, 1

# TD: Test Diameter in mm. The diameter of the round part of the urchin 
# TW: Total Wet Weight in g
# GW: Gonadal Wet Weight in g
# GSI: Gonadosomatic Index. Calculated as GSI = (GW / TW) * 100.
# Sex: M or F
# Month: 1-12, aka Jan - Dec. No sampling in Nov.

###########################################

urchinsfull <- urchins

# For this exercise, let's imagine we ONLY had Gonadal Weight and Test Diameter.

urchins <- select(urchins, c("GW", "TD"))

# Hypothesis; wider urchins have bigger gonads

# Keep it simple:
# Y: Gonadal weight GW
# X: Diameter  TD

# Visualize experiment: See powerpoint

# Conduct data exploration:

#############################
# 1. Outliers, Y and X      #
#############################

# Two ways to check:

# Boxplot
par(mfrow=c(1,2))
boxplot(urchins$GW, main="GW")
boxplot(urchins$TD, main="TD")

# Dotchart

dotchart(urchins$GW, main="GW")
dotchart(urchins$TD, main="TD")
par(mfrow=c(1,1))

# A couple points to keep an eye on. 
# Key Q: Are these REAL outliers? Or are they entry errors?

# One way to check: We KNOW GW and TD should be somehow related
# If a high GW also has a fairly high TD, be more confident

filter(urchins, GW > 13) # Big GW also has TD of 69. Is that big?

hist(urchins$TD)
abline(v=69, col="red") # yes, that's big. 
# Conclude it's probably not an outlier

#Check big TD
range(urchins$TD)
filter(urchins, TD>75) # pick out the biggest value
# GW is 5.88. Is that big?

hist(urchins$GW) 
abline(v=5.88, col="red") # Yup, that's big. I am now relaxed.

# Conclude there are no outliers

################################
# 2. Homogeneity of variance Y #
################################

# Skip for now

##############################
# 3. Normality  Y            #
##############################

par(mfrow=c(1,1))
hist(urchins$GW) #Uh oh, not normal. Like, really not-normal.

# Another way to look at it:
qqnorm(urchins$GW)
qqline(urchins$GW)

# What would happen if we transformed?

qqnorm(log(urchins$GW)) 
qqline(log(urchins$GW)) # meh, better I guess?

# Reminder - what's the log of zero?
# - If you log transform and there are zeroes, must add a SMALL CONSTANT that is SMALL RELATIVE TO REST OF DATA
# - Also, there should be a small proportion of zeroes

# Options:
# - Do nothing. Simple linear regression is fairly robust to non-normality (though this is bad). Push on through.
# - Transform it some other way
# - Add another parameter to the model (to let the line curve)
# - Do a GLM (come back later)

# I choose: Do nothing.

##############################
# 4. Zero inflation Y        #
##############################

# Recall that we REMOVED all urchins with "NA" for gonadal weight in the data cleaning
# Was that wise? NA could have meant zero. It also could have meant "missing value"
# We'd need to ask author to be sure

# For now, carry on as if those were missing values. Assume all urchins do have gonads.

range(urchins$GW) # GW never hits zero. It IS bounded by zero (you can't have < zero GW).

# By definition, not zero. 

#How many low numbers? Another visualization:

plot(sort(urchins$GW),
     xlab = "Observed values", ylab = "GW")

# Let's plot a histogram anyway, to see data

hist(urchins$GW, breaks=10)
hist(urchins$GW, breaks=50)
hist(urchins$GW, breaks=100)
hist(urchins$GW, breaks=100, freq=FALSE)

lines(density(urchins$GW), col="blue", lwd=3) #interesting

# So, not zero inflated... but a lot of low numbers


################################
# 5. Collinearity X            #
################################

# Are X values colinear with one another?

# We only have one X in the model. Move on for now.

#################################
# 6. Relationships Y and X      #
#################################

# Plot Y against every covariate independently.

# We only have one covariate here (TD) so:

plot(GW ~ TD, 
     data=urchins)

# We're looking for:
# - General shape of the association (here, it's positive.)
# - Points that diverge from the relationship. Entry error? (none here)

# We can see an issue - variance increases with mean. This is Poisson-distributed (later)

# For now, carry on 

#################################
# 7. Interactions               #
#################################

# N/A - only using two variables

#################################
# 8. Independence Y             #
#################################

# Are our Y values truly independent from one another?

# With only two variables we can't really know.


# RECAP:
# 1. Outliers Y and X: Some extreme values, but we chose not to eliminate. They seem fine.
# 2. Homogeneity Y: Skip
# 3. Normality Y: GW is very non-normal.
# 4. Zero trouble Y: No zeroes in dataset.
# 5. Collinearity X: N/A
# 6. Relationships Y and X: GW increases with TD. Variance appears to increase with mean (Poisson?)
# 7. Interactions: N/A
# 8. Independence Y: N/A
