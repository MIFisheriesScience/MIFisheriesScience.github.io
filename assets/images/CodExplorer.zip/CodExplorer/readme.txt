Cod explorer (adapted for teaching purposes)

Last update: Nov 24, 2017

Brett Favaro

There are 

CodExplorer
|
|- CodExplorer.rproj - Project file
|
|- Documents - Contains the single Markdown file, with embedded R code, to build the Cod Explorer
|
|- Data 
 +- Rose2004Data.csv - contains data that I manually extracted from Rose, 2004
 +- DFO2016-CodAssessmentData.csv - Contains data on stock abundance taken directly from the 2016 DFO Stock Assessment document for Northern Cod

References: 

Rose, G.A., (2014). Reconciling overfishing and climate change with stock dyanmics of Atlantic cod (Gadus morhua) over 500 years. Canadian Journal of Fisheries and Aquatic Sciences, 61(9): 1553-1557.

DFO (2016). Stock assessment of northern cod (NAFO divs 2j3kl) in 2016. Available: http://waves-vagues.dfo-mpo.gc.ca/Library/365622.pdf