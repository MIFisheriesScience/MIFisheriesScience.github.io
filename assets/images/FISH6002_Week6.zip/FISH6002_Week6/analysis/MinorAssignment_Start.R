# R Code for Week 6: Displaying Data Visually, Part 2
# FISH 6002

# Started Oct 10, 2017
# Updated Oct 13, 2018
install.packages("tidyverse")

library(tidyverse)
library(lubridate)
library(ggplot2)
library(ggthemes)


#######################
# Load some data      #
#######################

# The dataset:
# My 2012 Chevrolet Volt plug-in hybrid has a tracker unit that records every trip the car takes
# Each row of data is one observation - one TRIP taken where a trip starts when the car is turned on, 
# and stops when the car is turned off.

# The data included in the spreadsheet are as follows, and are as outputted directly by the tracker's software:

# Date: The date and time at which the trip took place
# Duration: The duration, in h:mm:ss of the trip
# TripDistance_KM: The total linear distance of the trip, in km
# FuelConsumed_L: The number of liters of gasoline consumed on the trap
# FuelConsumption_Lper100KM: The number of liters of gasoline consumed per 100 km on that trip
# ElectricityConsumed_KWH: The number of kilowatt-hours of electricity consumed on that trip
# TotalEConsumed_Lper100KMeq: The liters per 100 km-equivalent of energy consumed, as calculated by the tracker
# StartSOC: State of Charge at the start of the trip, expressed as a % of total battery capacity
# EndSOC: State of Charge at the end of the trip, expressed as a % of total battery capacity
# AmbientTemperature_C: The average air temperature during the trip
# AverageSpeed_kmh: Mean speed during the trip
# MaxSpeed_kmh: Maximum speed achieved during the trip
# AuxiliaryLoad_KWH: The number of kilowatt-hours of electricity used to power the car's auxillary systems (e.g. heating)
# HardAccel_Percent: Percentage of all acceleration on the trip classified as "hard" (i.e. accelerating quickly)	
# HardBraking_Percent: Percentage of all braking on the trip classified as "hard" (i.e. braking intensely)
# TimeIdle_Percent: Percentage of time on that trip spent idling (i.e. not making forward progress)

####################
# DATA PREPARATION #
####################

CarData <- read.csv("./data/BrettsCar_FullDataset.csv")

# Remove % from time idle
CarData$TimeIdle_Percent <- as.numeric(
  sub("%", "", CarData$TimeIdle_Percent)
)
head(CarData$Date)
# Convert the date column to a Lubrdiate formatted date and time
CarData$Date <- mdy_hm(CarData$Date, tz="America/St_Johns")

# Read Durations as seconds
CarData$Duration <- hms(CarData$Duration)
CarData$Duration <- as.numeric(CarData$Duration)

# Make versions of Duration expressed as minutes or hours
CarData <- CarData %>%
  mutate(DurationM = Duration/60) %>%
  mutate(DurationH = Duration/3600) 

# Add IsItCold variable
CarData <- CarData %>%
  mutate(IsItCold = ifelse(AmbientTemperature_C <= 0, "Freezing", "Not freezing"))

CarData$IsItCold <- as.factor(CarData$IsItCold)

#######################
# YOUR CODE HERE:     #
#######################

##
# ADDITIONAL DATA TRANSFORMATION
##


##
# PLOTS
##


##
# CODE TO SAVE YOUR PLOT
##



