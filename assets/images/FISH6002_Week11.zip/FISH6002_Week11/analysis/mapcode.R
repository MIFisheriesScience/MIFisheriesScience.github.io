# Map for cod pot paper
#######################
# 26 Jan 2016
##########

library(tidyverse)
library(raster)


library(gridExtra)
library(dplyr)
library(maptools)
library(tidyr)
library(grid)  

?raster
################
setwd("C:/Users/bfavaro/Google Drive/MI SOF Courses/FISH 6002 - Data collection mgmt and display/Week 10 - Maps")

#CamDeploy <- read.csv("camdeploy.csv")
PotDeploy <- read.csv("potdata.csv")

# Decimal Degrees = Degrees + minutes/60 + seconds/3600
# Latitudes are positive. Longitudes are negative here, because they're W rather than E. 
#CamDeploy <- CamDeploy %>%
 # mutate(LatDecDeg = LatDegIn + (LatMinSecIn/60)) %>%
 # mutate(LongDecDeg = -1 * (LongDeg + (LongMinSec/60)))
                                 
PotDeploy <- PotDeploy %>%
  mutate(LatDecDeg = LatDegIn + (LatMinSecIn/60)) %>%
  mutate(LongDecDeg = -1 * (LongDeg + (LongMinSec/60)))

xmin <- min(PotDeploy$LongDecDeg)
xmax <- max(PotDeploy$LongDecDeg)
ymin <- min(PotDeploy$LatDecDeg)
ymax <- max(PotDeploy$LatDecDeg)

NL<-getData("GADM", country="CAN", level=1) # download CAN level 0 map for ucdavis site
Region<-getData("GADM", country="CAN", level=2) # download CAN level 2 map for ucdavis site

Province<-(NL[NL$NAME_1=="Newfoundland and Labrador",]) # subset province of NL from map

Fogo <-(Region[Region$NAME_1=="Newfoundland and Labrador",]) #See http://gadm.org/maps/CAN_2_5.html
Fogo <-(Fogo[Fogo$NAME_2=="Division No. 8",]) #See http://gadm.org/maps/CAN_2_5.html

#####################
longmin <- -54.35
longmax <- -53.95
latmin <- 49.5
latmax <- 49.75
#####################

p1<-ggplot()+
  #geom_polygon(data=Fogo, aes(long+0.008,lat-0.005, group=group), fill="#9ecae1")+
  geom_polygon(data=Fogo, aes(long,lat, group=group), colour="grey10",fill="#fff7bc") +
  coord_equal()+theme_bw()+xlab("")+ylab("") +
  scale_x_continuous(limits=c(longmin,longmax), breaks=seq(longmin,longmax, 0.1), labels=c(paste(seq(longmin,longmax, 0.1),"°W", sep="")))+
  scale_y_continuous(limits=c(latmin,latmax), breaks=seq(latmin,latmax, 0.1), labels=c(paste(seq(latmin,latmax, 0.1),"°N", sep="")))+
  xlab("Longitude")+
  ylab("Latitude")+
    
  theme(axis.text.y =element_text(angle = 90, hjust=0.5),
        axis.text=element_text(size=10),
        panel.grid.major=element_blank(), panel.grid.minor=element_blank()) +
  #geom_point(size=3, data=CamDeploy, aes(LongDecDeg, LatDecDeg)) +
  geom_point(size=3, data=PotDeploy, aes(LongDecDeg, LatDecDeg)) +
  geom_rect(aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax+0.005), alpha=0, colour="blue", size = 1, linetype=1)+#Adjust the top of the rectangle just a tad so it doesn't overlap with top points
  geom_point(size=3, aes(x=-54.173329, y=49.615394), size=2, colour="brown")+
  geom_text(label="Seldom", aes(x=-54.187, y=49.630394), colour="brown") +
  scaleBar(lon=longmin, lat=latmin, distanceLon=5, distanceLat=0.75, distanceLegend=1.4, dist.unit="km", 
           orientation=FALSE) +
  scaleBar(lon=longmax-0.01, lat=latmax-.06, distanceLon=0, distanceLat=0, distanceLegend=0, dist.unit="km", 
         orientation=TRUE, arrow.length=4, arrow.distance=2)
  
p1

#To get POINTS of all deployments: geom_point(data=PotDeploy, aes(LongDecDeg, LatDecDeg, size=2, colour="red"))
#inset
p2 <- ggplot() +
  geom_polygon(data=Province, aes(long,lat,group=group),colour="grey10",fill="#fff7bc") +
  geom_rect(aes(xmin = longmin-.35, xmax = longmax+.35, ymin = latmin-.35, ymax = latmax+.35), alpha=0, colour="red", size = 1, linetype=1)+
  coord_equal()+theme_bw()+xlab("")+ylab("") +
  theme(axis.text.x =element_blank(),axis.text.y= element_blank(), axis.ticks=element_blank(),axis.title.x =element_blank(),
  axis.title.y= element_blank(), panel.grid.major=element_blank(), panel.grid.minor=element_blank()) +
  theme(plot.margin=unit(c(0,0,0,0), "cm")) +
  labs(x=NULL, y=NULL) #Need to elminate the labels too

p2



png(file="FogoMap5.png",w=1800,h=2000, res=300)
grid.newpage()

v1<-viewport(width = 1, height = 1, x = 0.5, y = 0.5) #plot area for the main map
v2<-viewport(width = 0.21, height = 0.26, x = 0.82, y = 0.375) #plot area for the inset map
print(p1,vp=v1) 
print(p2,vp=v2)
dev.off()



p3<-ggplot()+
  geom_polygon(data=Province, aes(long,lat, group=group), colour="grey10",fill="#fff7bc") +
  coord_equal()+theme_bw()+xlab("")+ylab("") +
  scale_x_continuous(limits=c(-60,-52), breaks=seq(-60,-52, 2), labels=c(paste(seq(-60,-52, 2),"?W", sep="")))+
  scale_y_continuous(limits=c(46,52), breaks=seq(46,52, 2), labels=c(paste(seq(46,52, 2),"?N", sep="")))+
  xlab("Longitude")+
  ylab("Latitude")+
  
  theme(axis.text.y =element_text(angle = 90, hjust=0.5),
        axis.text=element_text(size=10),
        panel.grid.major=element_blank(), panel.grid.minor=element_blank()) +
 
  geom_point(size=5, aes(x=-52.7072, y=47.5675), size=2, colour="brown")+
  geom_text(label="St. John's", aes(x=-52.5, y=47.25), colour="brown", face="bold") +
  scaleBar(lon=-60, lat=46, distanceLon=150, distanceLat=15, distanceLegend=30, dist.unit="km", 
           orientation=TRUE, arrow.length=75, arrow.distance=50)

#p3
png(file="NLMap.png",w=1800,h=2000, res=300)
grid.newpage()
v1<-viewport(width = 1, height = 1, x = 0.5, y = 0.5) #plot area for the main map
print(p3,vp=v1) 
dev.off()

