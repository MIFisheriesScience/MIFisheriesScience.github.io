# Week 11: Maps
# Started Nov 13, 2017

# Updated 16 Nov 2018

install.packages("marmap")
#sf documentation: http://pebesma.staff.ifgi.de/pebesma_sfr.pdf

#marmap: http://journals.plos.org/plosone/article?id=10.1371/journal.pone.0073051

library(ggplot2)
library(raster)
library(maptools)
library(GISTools)
library(rgdal)
library(marmap)
library(grid)

source("./R/MapFunctions.R")

##############################################
# http://eriqande.github.io/rep-res-web/lectures/making-maps-with-R.html

# Simple map of NL
######################

NL <- getNOAA.bathy(lon1 = -60, lon2 = -52,
              lat1 = 46, lat2 = 52, resolution = 2) # reduce resolution number to get finer details

summary(NL)

png("./output/test.png") #Use these when you're ready to prep a figure for a paper
# Note, the R studio preview looks quite different from the plot saved to PNG

plot(NL, xlim=c(-60, -52), ylim=c(46, 52),
     deepest.isobath = 0, #Try: c(-500, -250, 0), 
     shallowest.isobath = 0, #Try: c(-500, -250, 0),
     col="black", # With above, try: c("grey80", "grey40", "black")
     step=1, # c(1,1,1),
     lty=1, #c(1,1,1), 
     lwd=0.6, # c(0.6,0.6,1.2), 
     drawlabels=F) #With above, try: c(T,T,F))

scaleBathy(NL, deg=2, y=46.5, x=-60) #add a scale
north.arrow(xb=-59, yb=49.5, len=0.22, lab="N") 

# Annotate some key reference points

text(x = -56, y = 48.5, "Newfoundland")
text(x = -52.35, y = 48, "St. John's")
points(x = -52.712, y = 47.56, pch=16)

rect(xleft = -54, xright = -52,
     ybottom = 50, ytop = 52, 
     col=NA,
     border="red")

# Invent some fishing sites and plot them 

lat <- c(50, 50.5, 52, 51)
lon <- c(-54, -53, -52.5, -54)
OffshoreSites <- data.frame(lon, lat)

points(OffshoreSites, col="blue")

dev.off()

###

plot(NL, xlim=c(-60, -52), ylim=c(46, 52),
     image=T,
     deepest.isobath = 0, #Try: c(-500, -250, 0), 
     shallowest.isobath = 0, #Try: c(-500, -250, 0),
     col="black", # With above, try: c("grey80", "grey40", "black")
     step=1, # c(1,1,1),
     lty=1, #c(1,1,1), 
     lwd=0.6, # c(0.6,0.6,1.2), 
     drawlabels=F) #With above, try: c(T,T,F))



###########################################################
# Figure 2: Zoomed in map, hypothetical Fogo Island study #
###########################################################

lat <- runif(20, 49.8, 50)
lon <- runif(20, -54.5, -53.9)
FogoSites <- data.frame(lon, lat)

FogoMap <- getNOAA.bathy(lon1 = -54.75, lon2 = -53.75,
                    lat1 = 49.25, lat2 = 50, resolution = 1) # reduce resolution number to get finer details


plot(FogoMap, xlim=c(-54.75, -53.75), ylim=c(49.25, 50),
     deepest.isobath = c(-200, -50, 0), 
     shallowest.isobath = c(-200, -50, 0),
     col= c("grey80", "grey60", "black"),
     step=c(1,1,1),
     lty=c(1,1,1), 
     lwd=c(0.6,0.6,1.2), 
     drawlabels=c(T,T,F))

scaleBathy(FogoMap, deg=0.25, y=49.25, x=-54.7) #add a scale
north.arrow(xb=-54.7, yb=49.9, len=0.025, lab="N") 

text(x = -54.2, y = 49.675, "Fogo Island")
text(x = -54.42, y = 49.52, "Farewell")
points(x = -54.469, y = 49.57, pch=16, cex=2)
rect(xleft = -54.5, xright = -53.9,
     ybottom = 49.8, ytop = 50, col=NA, border="red")

points(FogoSites, col="blue")

