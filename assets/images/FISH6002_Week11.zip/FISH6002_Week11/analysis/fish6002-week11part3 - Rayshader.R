# FISH 6002: Week 11
# Part 3: The Rayshader package
# Nov 19, 2018

##########

# From: http://www.tylermw.com/3d-maps-with-rayshader/

library(rayshader)
library(raster)
library(tidyverse)
library(sp)
library(rgdal)
library(marmap)

source("./R/MapFunctions.R")


library(rayshader)

# EXAMPLE FROM: https://github.com/tylermorganwall/rayshader 


#Here, I load a map with the raster package:
raster::raster("./data/dem_01.tif") -> localtif
#And convert it to a matrix:
elmat = matrix(raster::extract(localtif,raster::extent(localtif),buffer=1000),
               nrow=ncol(localtif),ncol=nrow(localtif))

#We use another one of rayshader's built-in textures:
elmat %>%
  sphere_shade(texture = "desert") %>%
  plot_map()

#sphere_shade can shift the sun direction:
elmat %>%
  sphere_shade(sunangle = 45, texture = "desert") %>%
  plot_map()

ambmat = ambient_shade(elmat)
raymat = ray_shade(elmat,lambert = TRUE)

#detect_water and add_water adds a water layer to the map:
elmat %>%
  sphere_shade(texture = "desert") %>%
  add_water(detect_water(elmat), color="desert") %>%
  plot_map()

elmat %>%
  sphere_shade(texture = "desert") %>%
  add_water(detect_water(elmat), color="desert") %>%
  add_shadow(raymat,0.7) %>%
  add_shadow(ambmat,0.7) %>%
  plot_map()

elmat %>%
  sphere_shade(texture = "desert",progbar = FALSE) %>%
  add_water(detect_water(elmat), color="desert") %>%
  add_shadow(ray_shade(elmat,zscale=3,maxsearch = 300,progbar = FALSE),0.7) %>%
  add_shadow(ambmat,0.7) %>%
  plot_3d(elmat,zscale=10,fov=0,theta=135,zoom=0.9,phi=45, windowsize = c(800,800))

# 
montshadow = ray_shade(montereybay,zscale=50,lambert=FALSE)
montamb = ambient_shade(montereybay,zscale=50)
montereybay %>% 
  sphere_shade(zscale=10,texture = "imhof1") %>% 
  add_shadow(montshadow,0.5) %>%
  add_shadow(montamb) %>%
  plot_3d(montereybay,zscale=50,fov=0,theta=-45,phi=45,windowsize=c(800,800),zoom=0.9,
          water=TRUE, waterdepth = 0, wateralpha = 0.5,watercolor = "lightblue",
          waterlinecolor = "white",waterlinealpha = 0.3)

# Apply post-processing effect
montereybay %>% 
  sphere_shade(zscale=10,texture = "imhof1") %>% 
  add_shadow(montshadow,0.5) %>%
  add_shadow(montamb) %>%
  plot_3d(montereybay,zscale=50,fov=30,theta=45,phi=25,windowsize=c(800,800),zoom=0.4,
          water=TRUE, waterdepth = 0, waterlinecolor = "white", waterlinealpha = 0.5,
          wateralpha = 0.5,watercolor = "lightblue")
render_depth(focus=0.5)
