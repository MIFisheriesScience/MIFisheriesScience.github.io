#
# This is the server logic of a Shiny web application. You can run the 
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#

library(shiny)

# Define server logic required to draw a scatterplot with a simple linear model
server <- function(input, output) {
  
  library(tidyverse)  
  
  MinimalExample <- read.csv("../Data/MinimalExample.csv")
  
  output$xyPlot <- renderPlot({
    
    datasubset <- MinimalExample %>%
      filter(X <= input$plotrange)
    
    model <- lm(Y~X, data=datasubset)
    
    plot(Y~X, data=datasubset)
    abline(model)
  })
}