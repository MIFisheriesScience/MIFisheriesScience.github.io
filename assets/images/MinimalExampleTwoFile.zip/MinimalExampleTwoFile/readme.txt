Interactive plot Minimal example (for teaching purposes)

Last update: Nov 24, 2017

Brett Favaro

This is a minimial example of interactive plotting using a two-file method in R Shiny, which reads in a data file for use in plotting.

It makes a simple XY plot, whose plot range goes from 1 to a value specified by the user (up to 100)

MinimalExample
|
|- MinimalExample.rproj - Project file
|
|- Documents 
  +-ui.R - contains UI code
  +-server.R - contains server code
|
|- Data 
 +- MinimalExample.csv - A bunch of randomly-generated X and Y numbers for plotting

