# Week 9: Displaying Data Visually Part 3
# Brett Favaro
# Oct 23, 2019

# RUN 001_datasetup.R first

#################
# COLOURS       #
#################

library(RColorBrewer)

old_par <- par() #This becomes important later

# Base plot

plot(log10(weight) ~ log10(length), data=perch,xlim=c(1.4,2.5), pch=16)

# Default colour is black

# In R, you can spell out the colour name (try: colors() )
# or use a colour number
# OR type out a hex code 

# name: colors()
plot(log10(weight) ~ log10(length), data=perch,xlim=c(1.4,2.5), pch=16,
     col="red") # col changes the fill colour of points

# number
plot(log10(weight) ~ log10(length), data=perch,xlim=c(1.4,2.5), pch=16,
     col=2) 

# hex https://www.rapidtables.com/web/color/RGB_Color.html
plot(log10(weight) ~ log10(length), data=perch,xlim=c(1.4,2.5), pch=16,
     col="#FF0000") 


# In some cases you might need to change "bg"

plot(log10(weight) ~ log10(length), data=perch,xlim=c(1.4,2.5), pch=24,
     col="red", bg="blue")

# Changing all colours with par()

# Put par() with modifications here, and then 
# every plot after will have those modifications

par(col.axis = "darkgreen", 
    col.lab = "purple",
    bg = "cyan")

plot(log10(weight) ~ log10(length), data=perch,xlim=c(1.4,2.5), pch=24,
     col="red", bg="black")

par(old_par) #Restore default settings

###
# Increase data:ink ratio by making colours meaningful
###

# Switch to ggplot2
# Recall:
a <- ggplot(data = perch, aes(x = length, y = weight)) +
  geom_point(shape=1) + #Use an open circled
  scale_y_log10() +
  scale_x_log10(limits = c(25, 300),
                breaks= seq(from=25, to=300, by=75)) +
  labs(x = "Length (mm)", y = "Weight (g)") +
  theme_bw() +
  theme(axis.text = element_text(size=16),
        axis.title = element_text(size=18)) 
 
print(a)

# Let's re-do it, colouring points by "combined gear"

a <- ggplot(data = perch, aes(x = length, y = weight)) +
  geom_point(aes(col=combinedgear)) +
  scale_y_log10() +
  scale_x_log10(limits = c(25, 300),
                breaks= seq(from=25, to=300, by=75)) +
  labs(x = "Length (mm)", y = "Weight (g)") +
  theme_bw() +
  theme(axis.text = element_text(size=16),
        axis.title = element_text(size=18)) 

a

# This isn't a great plot - there's overplotting
# Hold that thought.

# Let's clean up that legend:

a + scale_colour_manual(name="Gear type", 
                        labels=c("Beach seine", 
                                 "Crayfish trap",
                                 "Electrofishing",
                                 "Fyke net",
                                 "Minnow trap",
                                 "Trammel net",
                                 "Vertical gillnet"),
                        values=c(1:7))
  
# Because gear type is unordered discrete data
# let's select a qualitative palette

display.brewer.pal("Set1", n=7) #lovely

mypal <- brewer.pal("Set1", n=7)

mypal

# Try out some other palettes
mypal2 <- brewer.pal("Set2", n=7)
mypal3 <- brewer.pal("Set3", n=7)
mypal4 <- brewer.pal("Pastel1", n=7)
mypal5 <- brewer.pal("Accent", n=7)

a + scale_colour_manual(name="Gear type", 
                        labels=c("Beach seine", 
                                 "Crayfish trap",
                                 "Electrofishing",
                                 "Fyke net",
                                 "Minnow trap",
                                 "Trammel net",
                                 "Vertical gillnet"),
                        values=mypal4)

#####################
# NEW SUBJECT: Using colour ramps and colourblind-safe
# palettes
######################

b <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point() + 
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  )

b

# Add weight as a third variable

b <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=4) + #also make the points a little bigger
  scale_colour_gradient(high="red", low="green") +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  )

b

########
# COLOURBLINDNESS DEMO
a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high="darkred", low="green") +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Unmodified")

b <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high=dichromat("darkred", type = "deutan"), low=dichromat("green", type = "deutan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Deutan - Insensitive to red")

c <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high=dichromat("darkred", type = "protan"), low=dichromat("green", type = "protan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Protan - insensitive to green")

d <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high=dichromat("darkred", type = "tritan"), low=dichromat("green", type = "tritan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Tritan - blue appears green")

multiplot(a,b,c,d, cols=2)


# Same as above, but colourblind-safe
a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high="red", low="blue") +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Unmodified")

b <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high=dichromat("red", type = "deutan"), low=dichromat("blue", type = "deutan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Deutan - Insensitive to red")

c <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high=dichromat("red", type = "protan"), low=dichromat("blue", type = "protan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Protan - insensitive to green")

d <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high=dichromat("red", type = "tritan"), low=dichromat("blue", type = "tritan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Tritan - blue appears green")

multiplot(a,b,c,d, cols=2)


######
# Let's colour the stream using a qualtiative palette
######


a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_brewer(palette = "Set1") +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Unmodified")

a

# Colourblind-check

a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_brewer(palette = "Set1") +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Unmodified")

b <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_manual(values = dichromat(brewer.pal(4, "Set1"), type="deutan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Deutan - Insensitive to red")

c <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_manual(values = dichromat(brewer.pal(4, "Set1"), type="protan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Protan - insensitive to green")

d <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_manual(values = dichromat(brewer.pal(4, "Set1"), type="tritan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("tritan - blue appears green")

multiplot(a,b,c,d, cols=2)

####
# Try again with a different palette
####

a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_brewer(palette = "Dark2") +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Unmodified")

b <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_manual(values = dichromat(brewer.pal(4, "Dark2"), type="deutan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Deutan - Insensitive to red")

c <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_manual(values = dichromat(brewer.pal(4, "Dark2"), type="protan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Protan - insensitive to green")

d <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_manual(values = dichromat(brewer.pal(4, "Dark2"), type="tritan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("tritan - blue appears green")

multiplot(a,b,c,d, cols=2)

###############
# END DEMO
################
d <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high=dichromat("darkred", type = "tritan"), low=dichromat("green", type = "tritan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Tritan - blue appears green")

# Showing what the dichromat function outputs
dichromat("red", type = "tritan")

# Colour by location



###########################
# Adding additional data density: Adding shape size
############################

a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc, size=w)) + 
  scale_colour_brewer(palette = "Dark2") +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  )

a

###########################
# Adding EVEN MORE data density: Adding shape size
############################

a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc, size=w, shape=status)) + 
  scale_colour_brewer(palette = "Dark2") +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  )

# Add a letter - for example, if you have multiple plots
a + annotate("text", x = 900, 
             y = 1400,
             label="A", 
              size=12)
  
# Add a shape... e.g. to highlight an area on the plot

a + annotate("text", x = 900, 
             y = 1400,
             label="A", 
             size=12)

# try: segment, arrow, rectangle

a + annotate("segment", 
             x = 1200, 
             xend = 1400, 
             y = 900, 
             yend = 1000, 
             colour = "red", 
             size=3, alpha=0.6)

#Arrow
a + annotate("rect", 
             xmin =  1200, 
             xmax = 1400, 
             ymin = 900, 
             ymax = 1000, 
             colour = "red", 
             size=3, alpha=0) +
  annotate("rect", 
           xmin =  1200, 
           xmax = 1400, 
           ymin = 750, 
           ymax = 800, 
           colour = "blue", 
           size=3, alpha=1, 
           fill="black")# Note the fill colour

# Add horizontal or vertical lines
a + geom_hline(yintercept=1100, color="orange", size=1) + 
    geom_vline(xintercept=1400, color="red", size=1)

# Add rasters

deadfish <- readPNG("./icons/deadfish.png")
deadfish_raster <- rasterGrob(deadfish, interpolate=TRUE)

livefish <- readPNG("./icons/HappyFishLogo.png")
livefish_raster <- rasterGrob(livefish, interpolate=TRUE)

frozenfish <- readPNG("./icons/Froze.png")
frozenfish_raster <- rasterGrob(frozenfish, interpolate=TRUE)

a + 
  annotation_custom(deadfish_raster, xmin=900, xmax=1000, ymin=1400, ymax=Inf) +
  annotation_custom(livefish_raster, xmin=900, xmax=1000, ymin=1250, ymax=Inf) +
  annotation_custom(frozenfish_raster, xmin=900, xmax=1000, ymin=1100, ymax=Inf) 

# Adding the date to each dot
a + geom_text(label=year(pallid$date))
# :(

a + geom_text_repel(label=year(pallid$date))

#######################
# MULTIPANEL PLOTS    #
#######################

a <- ggplot(data = perch, aes(x = length, y = weight)) +
  geom_point(aes(col=combinedgear)) +
  scale_y_log10() +
  scale_x_log10(limits = c(25, 300),
                breaks= seq(from=25, to=300, by=75)) +
  labs(x = "Length (mm)", y = "Weight (g)") +
  theme_bw() +
  theme(axis.text = element_text(size=16),
        axis.title = element_text(size=18)) +
 scale_colour_manual(name="Gear type", 
                        labels=c("Beach seine", 
                                 "Crayfish trap",
                                 "Electrofishing",
                                 "Fyke net",
                                 "Minnow trap",
                                 "Trammel net",
                                 "Vertical gillnet"),
                        values=c(1:7))

# Let's break this up into two plots

# Put them in columns
a + facet_grid(cols=vars(combinedgear))

# Doing it this way allows us to drop colours
# Remake the plot

a <- ggplot(data = perch, aes(x = length, y = weight)) +
  geom_point() +
  scale_y_log10() +
  scale_x_log10(limits = c(25, 300),
                breaks= seq(from=25, to=300, by=75)) +
  labs(x = "Length (mm)", y = "Weight (g)") +
  theme_bw() +
  theme(axis.text = element_text(size=16),
        axis.title = element_text(size=18)) 

a + facet_grid(cols=vars(combinedgear))
a + facet_grid(rows=vars(combinedgear))

#######################
# MULTIPANEL PLOTTING
# Multiplot allows you to plot more than one figure in a single plot. 
###################
# Let's make a simple dot plot connected by lines
# on X: Removal #
# on Y: Total removed

# Problem: The data are wide format. First, must manipulate

# when doing removals, scientists do several "passes" through a river. So let's organize by a variable called
# "removalpass"
a <- ggplot(LongTrout, aes(x = removalpass, y = catch, colour = species, group = species)) +
  geom_point() + geom_line() +
  theme_bw() +
  xlab("Removal pass") + 
  ylab("No. individuals caught per pass") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  )

print(a)
# First problem: Fourth should be on the right.

# Explicitly order the factors
LongTrout$removalpass <- factor(LongTrout$removalpass, levels= c("first", "second", "third", "fourth"))

# It's still wrong. 

# The problem is that one species can occur in more than one stream - meaning you've got multiple dots of the same colour
# Lines, therefore, aren't being plotted correctly.

# Wrap by stream

a <- ggplot(LongTrout, aes(x = removalpass, y = catch, colour = species, group = species)) +
  geom_point() + geom_line() +
  theme_bw() +
  xlab("Removal pass") + 
  ylab("No. individuals caught per pass") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) + facet_wrap(~stream) 
a

# Log scale
a <- ggplot(LongTrout, aes(x = removalpass, y = catch, colour = species, group = species)) +
  geom_point() + geom_line() +
  theme_bw() +
  xlab("Removal pass") + 
  ylab("No. individuals caught per pass") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) + facet_wrap(~stream) + scale_y_log10()
a

# Allow scales to vary
a <- ggplot(LongTrout, aes(x = removalpass, y = catch, colour = species, group = species)) +
  geom_point() + geom_line() +
  theme_bw() +
  xlab("Removal pass") + 
  ylab("No. individuals caught per pass") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) + facet_wrap(~stream, scales = "free") 
a


# Wrap by species
a <- ggplot(LongTrout, aes(x = removalpass, y = catch, colour = stream, group = stream)) +
  geom_point() + geom_line() +
  theme_bw() +
  xlab("Removal pass") + 
  ylab("No. individuals caught per pass") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) + facet_wrap(~species) 
a
# Let's make two plots.

# 1) Boxplot comparing population sizes across streams

a <- ggplot(LongTrout, aes(x = stream, y = pop.cs)) +
  geom_boxplot() + 
  theme_bw() +
  xlab("stream") + 
  ylab("Carle-Strub population estimate") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

a

# 2) Boxplot comparing population size of each species across stream

b <- ggplot(LongTrout, aes(x = species, y = pop.cs)) +
  geom_boxplot() + 
  theme_bw() +
  xlab("species") + 
  ylab("Carle-Strub population estimate") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

b

# Plot these together with multiplot()

multiplot(a,b)

multiplot(b,a)

multiplot(a,b, cols=2)

# 3-panel plot:

multiplot(a,b,a, cols=2)




#################################

a <- ggplot(data = perch, aes(x =
                                fct_relevel(
                                  fct_reorder(combinedgear, length),
                                  "ELFISH"),
                              
                              y=length)) +
  geom_jitter(colour="grey", alpha=0.5) +
  geom_boxplot(alpha=0.8) +
  labs(x = "Gear ID", y = "Length (mm)") + 
  theme_bw() +
  theme(axis.text.x = element_text(angle=90, hjust=1),
        axis.text = element_text(size=16),
        axis.title = element_text(size=18)
  )
