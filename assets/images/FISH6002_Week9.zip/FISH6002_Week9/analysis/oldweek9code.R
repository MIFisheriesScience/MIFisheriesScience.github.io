# Week 8: Data Display 3
# FISH 6002
# 

# Major update: Oct 31, 2019
# Updated Nov 2, 2018
# Started Oct 26, 2017

library(tidyverse)
library(lubridate)
library(RColorBrewer)
library(png)
library(grid)
library(devtools)
library(dichromat)

#############
# Load data #
#############

##########################
# 1. Colours and Symbols #
##########################

# RColorBrewer

display.brewer.all()

# Sequential:
display.brewer.pal(n = 6, name="OrRd")

# Divergent:
display.brewer.pal(n = 8, name="RdGy")

# Note that an even number doesn't work quite right for divergent

display.brewer.pal(n = 9, name="RdGy")

#install.packages("dichromat")
#library(dichromat)

#dichromat()


# All good
# Begin plots:

a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point() + 
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  )

a

# Heavier fish are red

a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high="red", low="blue") +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  )

a

# Red-green colourblindness demo

a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high="darkred", low="green") +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Unmodified")

b <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high=dichromat("darkred", type = "deutan"), low=dichromat("green", type = "deutan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Deutan - Insensitive to red")

c <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high=dichromat("darkred", type = "protan"), low=dichromat("green", type = "protan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Protan - insensitive to green")

d <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high=dichromat("darkred", type = "tritan"), low=dichromat("green", type = "tritan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Tritan - blue appears green")

multiplot(a,b,c,d, cols=2)

# Same as above, but colourblind-safe
a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high="red", low="blue") +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Unmodified")

b <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high=dichromat("red", type = "deutan"), low=dichromat("blue", type = "deutan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Deutan - Insensitive to red")

c <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high=dichromat("red", type = "protan"), low=dichromat("blue", type = "protan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Protan - insensitive to green")

d <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(colour=w), size=8) + 
  scale_colour_gradient(high=dichromat("red", type = "tritan"), low=dichromat("blue", type = "tritan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Tritan - blue appears green")

multiplot(a,b,c,d, cols=2)

######
# Let's colour the stream using a qualtiative palette
######


a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_brewer(palette = "Set1") +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Unmodified")

a

# Colourblind-check

a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_brewer(palette = "Set1") +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Unmodified")

b <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_manual(values = dichromat(brewer.pal(4, "Set1"), type="deutan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Deutan - Insensitive to red")

c <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_manual(values = dichromat(brewer.pal(4, "Set1"), type="protan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Protan - insensitive to green")

d <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_manual(values = dichromat(brewer.pal(4, "Set1"), type="tritan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("tritan - blue appears green")

multiplot(a,b,c,d, cols=2)

####
# Try again with a different palette
####

a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_brewer(palette = "Dark2") +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Unmodified")

b <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_manual(values = dichromat(brewer.pal(4, "Dark2"), type="deutan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Deutan - Insensitive to red")

c <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_manual(values = dichromat(brewer.pal(4, "Dark2"), type="protan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("Protan - insensitive to green")

d <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc), size=8) + 
  scale_colour_manual(values = dichromat(brewer.pal(4, "Dark2"), type="tritan")) +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) +
  ggtitle("tritan - blue appears green")

multiplot(a,b,c,d, cols=2)

####################################
# Scale point size by fish weight  #
####################################


a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc, size=w)) + 
  scale_colour_brewer(palette = "Dark2") +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  )

a

#########################################################
# Scale point size by fish weight, AND symbol = status  #
#########################################################

a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc, size=w, shape=status)) + 
  scale_colour_brewer(palette = "Dark2") +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  )

a


### Add images

deadfish <- readPNG("./icons/deadfish.png")
deadfish_raster <- rasterGrob(deadfish, interpolate=TRUE)

livefish <- readPNG("./icons/HappyFishLogo.png")
livefish_raster <- rasterGrob(livefish, interpolate=TRUE)

frozenfish <- readPNG("./icons/Froze.png")
frozenfish_raster <- rasterGrob(frozenfish, interpolate=TRUE)

a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point(aes(color=loc, size=w, shape=status)) + 
  scale_colour_brewer(palette = "Dark2") +
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14),
        title = element_text(size=16)
  ) + 
  annotation_custom(deadfish_raster, xmin=900, xmax=1000, ymin=1400, ymax=Inf) +
  annotation_custom(livefish_raster, xmin=900, xmax=1000, ymin=1250, ymax=Inf) +
  annotation_custom(frozenfish_raster, xmin=900, xmax=1000, ymin=1100, ymax=Inf) 
  
a


#################################
# 2. Multipanel plots           #
#################################


###################
# Begin plotting  #
###################

# Let's make a simple dot plot connected by lines
# on X: Removal #
# on Y: Total removed

# Problem: The data are wide format. First, must manipulate

# when doing removals, scientists do several "passes" through a river. So let's organize by a variable called
# "removalpass"

LongTrout <- gather(TroutRemoval, key = removalpass, value = "catch", 3:6) 


a <- ggplot(LongTrout, aes(x = removalpass, y = catch, colour = species, group = species)) +
  geom_point() + geom_line() +
  theme_bw() +
  xlab("Removal pass") + 
  ylab("No. individuals caught per pass") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  )

print(a)
# First problem: Fourth should be on the right.

# Explicitly order the factors
LongTrout$removalpass <- factor(LongTrout$removalpass, levels= c("first", "second", "third", "fourth"))

# It's still wrong. 

# The problem is that one species can occur in more than one stream - meaning you've got multiple dots of the same colour
# Lines, therefore, aren't being plotted correctly.

# Wrap by stream

a <- ggplot(LongTrout, aes(x = removalpass, y = catch, colour = species, group = species)) +
  geom_point() + geom_line() +
  theme_bw() +
  xlab("Removal pass") + 
  ylab("No. individuals caught per pass") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) + facet_wrap(~stream) 
a

# Log scale
a <- ggplot(LongTrout, aes(x = removalpass, y = catch, colour = species, group = species)) +
  geom_point() + geom_line() +
  theme_bw() +
  xlab("Removal pass") + 
  ylab("No. individuals caught per pass") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) + facet_wrap(~stream) + scale_y_log10()
a

# Allow scales to vary
a <- ggplot(LongTrout, aes(x = removalpass, y = catch, colour = species, group = species)) +
  geom_point() + geom_line() +
  theme_bw() +
  xlab("Removal pass") + 
  ylab("No. individuals caught per pass") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) + facet_wrap(~stream, scales = "free") 
a


# Wrap by species
a <- ggplot(LongTrout, aes(x = removalpass, y = catch, colour = stream, group = stream)) +
  geom_point() + geom_line() +
  theme_bw() +
  xlab("Removal pass") + 
  ylab("No. individuals caught per pass") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) + facet_wrap(~species) 
a

#################
# Next plot     #
#################

# What are population sizes across streams?

a <- ggplot(LongTrout, aes(x = stream, y = pop.cs)) +
  geom_point() + 
  theme_bw() +
  xlab("stream") + 
  ylab("Carle-Strub population estimate") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) 
a

# Not enough info. Let's add colour


a <- ggplot(LongTrout, aes(x = stream, y = pop.cs, colour=species, group=species)) +
  geom_point() + 
  theme_bw() +
  xlab("stream") + 
  ylab("Carle-Strub population estimate") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))
a

# Still too busy

#Next:

a <- ggplot(LongTrout, aes(x = stream, y = pop.cs)) +
  geom_point() + 
  theme_bw() +
  xlab("stream") + 
  ylab("Carle-Strub population estimate") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) + 
  facet_wrap(~species) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

a

# Next

a <- ggplot(LongTrout, aes(x = species, y = pop.cs)) +
  geom_point() + 
  theme_bw() +
  xlab("stream") + 
  ylab("Carle-Strub population estimate") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) + 
  facet_wrap(~stream) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

a

# Also colour code species:
a <- ggplot(LongTrout, aes(x = species, y = pop.cs, colour=species, group=species)) +
  geom_point() + 
  theme_bw() +
  xlab("stream") + 
  ylab("Carle-Strub population estimate") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) + 
  facet_wrap(~stream) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

a

######################################################
# Next example: multipanel with two separate figures #
######################################################

# Multiplot allows you to plot more than one figure in a single plot. 

# Let's make two plots.

# 1) Boxplot comparing population sizes across streams

a <- ggplot(LongTrout, aes(x = stream, y = pop.cs)) +
  geom_boxplot() + 
  theme_bw() +
  xlab("stream") + 
  ylab("Carle-Strub population estimate") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

a

# 2) Boxplot comparing population size of each species across stream

b <- ggplot(LongTrout, aes(x = species, y = pop.cs)) +
  geom_boxplot() + 
  theme_bw() +
  xlab("species") + 
  ylab("Carle-Strub population estimate") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

b

# Plot these together with multiplot()

multiplot(a,b)

multiplot(b,a)

multiplot(a,b, cols=2)

# 3-panel plot:

multiplot(a,b,a, cols=2)

####################################
# Plotting model output in ggplot2 #
####################################

# Let's figure out a line of best fit
# base plot

plot(sl ~ tl, data = pallid)

fit <- lm(sl ~ tl, data = pallid)

abline(fit)


# Using the pallid dataset:

a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point() + 
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) +
  stat_smooth(method = "lm", col="red") 

a

# Specify the confidence interval
a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point() + 
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) +
  stat_smooth(method = "lm", col="red", level=0.95) 

a

# Specify the confidence interval
a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point() + 
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) +
  stat_smooth(method = "lm", col="red", level=0.95) 

a

#Try to plot outside the range

a <- ggplot(pallid, aes(x = tl, y = sl)) +
  geom_point() + 
  theme_bw() +
  xlab("Total length (mm)") + 
  ylab("Standard length (mm)") +
  theme(axis.text=element_text(size=12),
        axis.title = element_text(size=14)
  ) +
  stat_smooth(method = "lm", col="red", level=0.95) + #Disable CI by going se=FALSE
  xlim(0, 1700)

a


