# Week 8: Displaying Data Visually Part 3
# Brett Favaro
# Nov 1, 2019

library(tidyverse)
library(lubridate)
library(RColorBrewer)
library(dichromat)
library(png)
library(ggrepel)

perch <- read.csv("data/YPerchTL.csv")
pallid <- read.csv("./data/Pallid.csv")
troutremoval <- read.csv("./data/SimonsonLyons.csv")

# FUNCTION - MUST RUN

multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  library(grid)
  
  plots <- c(list(...), plotlist)
  
  numPlots = length(plots)
  
  if (is.null(layout)) {
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                     ncol = cols, nrow = ceiling(numPlots/cols))
  }
  
  if (numPlots==1) {
    print(plots[[1]])
    
  } else {
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))
    
    for (i in 1:numPlots) {
      
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))
      
      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}

###################################################
# Data are from: http://derekogle.com/fishR/data/data-html/YPerchTL.html
# obtained 23 Oct 2019

# This section contains *all* data preparation, if you want to skip the verification steps

perch$sampledate <- mdy(perch$sampledate)

perch <- perch %>%
  select(-lakeid) %>%
  select(-spname) %>% 
  select(-year4)

perch <- perch %>%
  mutate(combinedgear = as.factor(
    case_when(
      gearid == "FYKNED" ~ "FYK",
      gearid == "FYKNEL" ~ "FYK",
      gearid == "FYKNET" ~ "FYK",
      gearid == "VGN019" ~ "VGN",
      gearid == "VGN025" ~ "VGN",
      gearid == "VGN032" ~ "VGN",
      gearid == "VGN038" ~ "VGN",
      gearid == "VGN089" ~ "VGN",
      gearid == "BSEINE" ~ "BSEINE",
      gearid == "CRAYTR" ~ "CRAYTR",
      gearid == "ELFISH" ~ "ELFISH",
      gearid == "MINNOW" ~ "MINNOW",
      gearid == "TRAMML" ~ "TRAMML",
      TRUE ~ "missing")
  )) 


# Mods to pallid dataset
pallid$date <- dmy(pallid$date)


# Can go onto 002_advancedplots.R


LongTrout <- gather(troutremoval, key = removalpass, value = "catch", 3:6) 


#########################
# FILE 1

#Data
#lakeid: Lake name (all TR=Trout Lake)
#year4: Year of capture
#sampledate: Date of capture
#gearid: Capture gear type – beach seine (BSEINE), crayfish trap (CRAYTR), electrofishing (ELFISH), fyke net (FYKNET), trammel net (TRAMML), vertical gillnets of different mesh sizes (VBN0XX), and different types of fyke nets (FYKNED and FYKNEL)
#spname: Species name (all YELLOWPERCH)
#length: Total Length (nearest mm) at capture
#weight: Weight (nearest 0.1 or 1 g) at capture

#Skipping verification steps because we already did them in week 8

#One row = one fish

###################################################
# FILE 2,  verification steps

# http://derekogle.com/fishR/data/data-html/Pallid.html

# A data frame with 30 observations on the following 7 variables:

#date: Date of collection
#sl: Standard length (mm)
#fl: Fork length (mm)
#tl: Total length (mm)
#w: Weight (g)
#status: Living status of fish at time of collection (Frozen, Live, Dead).
#loc: Location of fish collection (NB=Nebraska, SD=South Dakota, ND=North Dakota, MT=Montana)

# 1. Did it load?

head(pallid)
tail(pallid)

# 2. Check data types

sapply(pallid, class)

# Convert date to a lubridate object
pallid$date <- dmy(pallid$date)

# 3. Check for missing or impossible values 

plot(pallid$sl)
plot(pallid$fl)
plot(pallid$tl) 
plot(pallid$w) 
plot(pallid$date) 

# 4. Check for typos and broken factors 

levels(pallid$status)
levels(pallid$loc) 

######################################
# FILE 3 VERIFICATION STEPS
# http://derekogle.com/fishR/data/data-html/SimonsonLyons.html

#A data frame of 58 observations on the following 7 variables:

#species: Species of fish.
#stream: Stream name.
#first: Catch on the first removal pass.
#second: Catch on the second removal pass.
#third: Catch on the third removal pass.
#fourth: Catch on the fourth removal pass.
#pop.cs: Population estimate by Carle-Strub method.

# 1. Did it load?

head(TroutRemoval)
tail(TroutRemoval)

# 2. Check data types

sapply(TroutRemoval, class)

# 3. Check for missing or impossible values 

plot(TroutRemoval$first)
plot(TroutRemoval$second)
plot(TroutRemoval$third) # One value is a bit of an outlier. Investigate

TroutRemoval %>% 
  filter(third>100) # Third pass is consistent with other passes. Probably fine

plot(TroutRemoval$fourth)
plot(TroutRemoval$pop.cs)

# There are some NA's but that's okay - they don't always do all four passes.

# 4. Check for typos and broken factors 

levels(TroutRemoval$species)
levels(TroutRemoval$stream) # all good
