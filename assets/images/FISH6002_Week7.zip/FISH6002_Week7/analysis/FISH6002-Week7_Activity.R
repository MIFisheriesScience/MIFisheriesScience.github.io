# Fish 6002 - Week 7 assignment
# Solution

# Oct 14, 2017
# Updated 22 Oct 2018

library(lubridate)
library(ggplot2)
library(dplyr)
library(ggthemes)
library(tidyr)

InchLake <- read.csv("./data/InchLake2-Broken.csv")

##############################
# 1. Did it load correctly?  #
##############################

#netID: A unique identifier for the sampling event (more than one can share)
#fishID: A unique identifier for the individual fish (can't be duplicated)
#species: Species name
#length: Total length (inches to nearest 0.1)
#weight: Wet weight (grams to nearest 0.1)
#year: Year of capture


##############################
# 2. Are data types correct?  #
##############################




##################################
# 3. Check for impossible values #
##################################




##################################################
# STEP 4: Are factor levels correct?             #
##################################################





################################################
# Final check for correctness                  #
################################################



