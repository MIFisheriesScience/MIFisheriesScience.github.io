# R Code for Week 5: Displaying Data Visually
# FISH 6002

# 5 Oct, 2018
# Total revision Oct 18, 2019

# Please run 001_DataSetup.R first

plot(whitefish$catch ~ whitefish$state)


## PLOT ONE VARIABLE - BASE

# One variable, X = Discrete
# Y can only be count

table(whitefish$state)

barplot(table(whitefish$state))

plot(table(whitefish$state))


# PLOT ONE VARIABLE
# Continuous X

plot(whitefish$catch) 
# no

hist(whitefish$catch) #yes

?hist

hist(whitefish$catch, breaks=10)
hist(whitefish$catch, breaks=20)
hist(whitefish$catch, breaks=30)

hist(whitefish$catch, breaks=c(0,500000,1000000,1500000, 2000000))
hist(whitefish$catch, breaks=c(0,100000,200000,300000,400000,500000,1000000,1500000,2000000))

# Many calculations are conducted by the hist function prior to plotting
# and you can extract those values
histinfo <- hist(whitefish$catch)

histinfo

# Making a point about data density... let's plot mean by state

temp <- whitefish %>%
  group_by(state) %>%
  summarise(avg = mean(catch))

plot(temp$avg ~ temp$state)

# Now, let's switch to...

###########
# GGPLOT2 #
###########

# Formulation is different

ggplot(data = whitefish,
       aes(state)) +
  geom_bar()

#ggplot(data = DATA,
#       aes(WHAT YOU WANT TO PLOT)) +
#  GRAPHICAL ELEMENTS, ADDED ONE BY ONE

a <- ggplot(data = whitefish,
       aes(state)) +
  geom_bar()

print(a)

# Demonstrate how things can be layered
a <- ggplot(data = whitefish,
            aes(state))

a

# ONE VARIABLE CONTINUOUS

a <- ggplot(data=whitefish,
            aes(catch))

a + geom_area(stat="bin")
a + geom_density()
a + geom_dotplot()
a + geom_freqpoly()
a + geom_histogram()

a + geom_histogram(bins=10)
a + geom_histogram(bins=20)
a + geom_histogram(bins=30)
a + geom_histogram(bins=40)

a + geom_histogram(bins = 10) + coord_flip()

#########################
# Plotting TWO variable #
#########################

# Base plots

plot(value ~ catch, data=whitefish)

# 
plot(catch ~ value, data=whitefish)


plot(catch ~ year, data=whitefish)
abline(lm(catch~year, data=whitefish))

plot(year ~ catch, data=whitefish)


# won't work
# clear the plot space

abline(lm(catch~year, data=whitefish))

# in GGPLOT #

a <- ggplot(data=whitefish, aes(x = year, y = catch))

a + geom_point()

a <- ggplot(data=whitefish, aes(x = year, y = catch)) +
  geom_point() +
  geom_smooth(method="lm", level=0.5)

a

?geom_smooth()

ggplot(data=whitefish, aes(x = year, y = catch)) +
  geom_point() +
  geom_smooth(span=100)

# Discrete X, continuous Y

plot(catch ~ state, data=whitefish)

ggplot(data=whitefish, aes(x = state, y = catch)) +
  geom_jitter() +
  geom_boxplot(alpha=0.7)

a <- ggplot(data=whitefish, aes(x = state, y = catch))

a + geom_boxplot()
a + geom_col()# cumulative amount
a + geom_dotplot()
a + geom_violin() 
# There are problems with each of these, in this case

# Discrete vs. discrete

whitefish <- whitefish %>%
  mutate(BigState = ifelse(state=="MI", "Y", "N"))

ggplot(data=whitefish, aes(x=state, y = BigState)) +
  geom_count()
