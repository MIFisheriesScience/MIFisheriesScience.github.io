# R Code for Week 7: Displaying Data Visually
# FISH 6002

# Started March 13, 2017
# Major revision, Sept 29, 2017
# Second major revision, 5 Oct, 2018
# Complete re-write Oct 17, 2019

# This file loads all the packages and data necessary to conduct our first graphing lecture
# Please run this *entire script* first, before running the next script

######################
# LOAD PACKAGES      #
######################

library(tidyverse)
library(lubridate)

#####################
# Dates             #
#####################
# List of time zones:
#  OlsonNames()

date_df <- read.csv("./data/DateExample.csv")

head(date_df)

sapply(date_df, class)

# I want to calculate the duration of each soak

# We need to create date-times. But date and time are in two separate columns!
 
head(date_df$Time)
head(hms(date_df$Time))

# Remember, if we use hms to look at times, we get TIME PASSED SINCE 0
# and AM/PM is ignored. No good!

# use mutate to concatenate Date and Time 
date_df <- date_df %>%
  unite(Date, Time, col="DateTime", sep=" ")

date_df

date_df$DateTime <- mdy_hms(date_df$DateTime, tz="America/St_Johns")

# Make it wide format, so we can have a start and end column

date_wide <- date_df %>%
  spread(key = action, value = DateTime)

date_wide

# Now calculate durations

date_wide <- date_wide %>%
  mutate(SoakTime = as.duration(set %--% haul))

date_wide

mean(date_wide$SoakTime)
median(date_wide$SoakTime)

# Note - you could have done all this above with very little code:

date_df <- read.csv("./data/DateExample.csv")

date_df %>%
  unite(Date, Time, col="DateTimeRaw", sep=" ") %>%
  mutate(DateTime = mdy_hms(DateTimeRaw, tz="America/St_Johns")) %>%
  select(-DateTimeRaw) %>%
  spread(key=action, value=DateTime) %>%
  mutate(SoakTime = as.duration(set %--% haul))
  
#######################
# Whitefish example   # 
#######################

whitefish <- read.csv("./data/WhitefishLS.csv")

#Data
#year: Year of catch.
#state: State of catch (MI, MN, or WI).
#catch: Catch in lbs.
#value: Value of catch in dollars.

head(whitefish) #STEP 1: Did it load?

sapply(whitefish, class) #STEP 2: Are the data types right?

#appears fine, except we do have a date-type variable here.

# Where only year is given, we can't use ymd
# Closest thing is:

whitefish$year <- date_decimal(whitefish$year)

sapply(whitefish, class) 

##################################################
# STEP 3: Check for missing or impossible values #
##################################################

range(whitefish$year) #k, lines up with http://derekogle.com/fishR/data/data-html/WhitefishLS.html

range(whitefish$catch) #nothing jumps out as wrong. I guess it's a big fishery
plot(whitefish$catch)

range(whitefish$value) #nothing impossible
plot(whitefish$value)

# Step 4: Factor levels

levels(whitefish$state)
# All good!

# Let's move on to file #2!