# R Code for Week 3: Introduction to R - Part 2
# FISH 6002

#lets plot
plot(DiceData_long) #Doesn't work!

plot(DiceData_long$Value) #The $ specifies a variable WITHIN a data frame

plot(DiceData_long$Value ~ DiceData_long$RollNum)

# DATA TYPES:

#What do rolls look like across dice?
plot(DiceData_long$Value ~ DiceData_long$DiceName)

#Why isn't this working? Let's start by seeing what all the data types are in our data frame
sapply(DiceData_long, class)
?sapply #Hmm... DiceName is a character

#Compare the two outputs. What's different?
DiceData_long$DiceName 
as.factor(DiceData_long$DiceName) #Express this variable as a factor

#Factors use text to describe something that is basically just numbered levels.
#Die 1 is the first level. Die 2 is the second level. And so on. The default
#levelling is done alphabetically.

# If we were to eliminate the text labels:
as.numeric(as.factor(DiceData_long$DiceName))

# Seen this way, Die1 = 1. Die2 = 2. This is essentially how R treats the factor

#If you want to see what the levels are of a given factor, use levels()
#This is really important for error-checking!

levels(as.factor(DiceData_long$DiceName)) 

#Okay, enough fooling around. Let's reclassify DiceName as a factor

DiceData_long$DiceName <- as.factor(DiceData_long$DiceName)

#Did it work?
is.factor(DiceData_long$DiceName)
#great

plot(DiceData_long$Value ~ DiceData_long$DiceName)

#############
# Scenario 2: bringing DiceData in from a CSV
#############

#Let's assume that, instead of using R to generate the Dice data, we entered
#it into an external spreadsheet and want to bring it into R

DiceData <- read.csv("./data/DiceData.csv")

#DiceData <- read.csv("DiceData.csv", stringsAsFactors=F) #Use this version if you want 
# to disable the automatic assignment of strings as factors

head(DiceData)

sapply(DiceData, class) #woohoo, it worked!

plot(DiceData$Value ~ DiceData$DiceName)

#Fun!