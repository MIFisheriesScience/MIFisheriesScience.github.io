# R Code for Week 5: Displaying Data Visually
# FISH 6002

# 5 Oct, 2018

# Please run 001_DataSetup.R first



# Going forward, we will replicate some plots in base and ggplot2.

#########################
# Plotting ONE variable #
#########################

#By default, the plot command will pick a plot type for you based on the variables you include
plot(CarData$AverageSpeed_kmh)

hist(CarData$AverageSpeed_kmh)

hist(CarData$AverageSpeed_kmh, breaks=20)

hist(CarData$AverageSpeed_kmh, breaks=20, right=FALSE) 

#What does this do?

hist(CarData$AverageSpeed_kmh, breaks=c(0,10,20,30,40,50,60,70,80,90,100,110))

hist(CarData$AverageSpeed_kmh, breaks=c(0,10,20,30,40,50,60,70,80,90,100))
hist(CarData$AverageSpeed_kmh, breaks=c(0,1,2,3,4,5,6,7,8,9,10,20,30,40,50,60,70,80,90,100))

hist(CarData$AverageSpeed_kmh, breaks=20)

# how is hist calculating things?
HistInfo <- hist(CarData$AverageSpeed_kmh)
HistInfo

hist(CarData$AverageSpeed_kmh)

# Okay, now it's GGPLOT2 time!

a <- ggplot(CarData, aes(AverageSpeed_kmh)) +
  geom_histogram()

a

a <- ggplot(CarData, aes(AverageSpeed_kmh)) +
  geom_histogram() +
  coord_flip()

a

#Other one-variable plots

a <- ggplot(CarData, aes(AverageSpeed_kmh)) +
  geom_density() 

a

a <- ggplot(CarData, aes(AverageSpeed_kmh)) +
  geom_dotplot() 

a

a <- ggplot(CarData, aes(AverageSpeed_kmh)) +
  geom_freqpoly() 

a
###
# Let's plot one variable, where that variable is discrete
###

# How often was it cold, versus not cold? First, base plot

head(CarData$IsItCold)

plot(CarData$IsItCold) 
#This won't work. Why?

table(CarData$IsItCold) #Returns count in each level
barplot(table(CarData$IsItCold)) 

class(CarData$IsItCold) #oh right, it's a character

plot(as.factor(CarData$IsItCold))

# GGplot is easier, let's use that instead

a <- ggplot(CarData, aes(IsItCold)) +
  geom_bar()

a

# Let's MISuse a barplot

# Data prep:

# Perform an operation on CarData
temp <- CarData %>%
  #First, group by the variable IsItCold
  group_by(IsItCold) %>%
  #Next, summarize both groups as specified 
  #(here, we want the average top speed per trip).
  # Call this calculated variable AverageMaxSpeed
  # Also calculate standard error
  summarize(AverageMaxSpeed = mean(MaxSpeed_kmh), 
            SE = (sd(MaxSpeed_kmh)/sqrt(length(MaxSpeed_kmh))) )
temp
# Store the output in temp

a <- ggplot(temp, aes(x=IsItCold, y=AverageMaxSpeed)) +
  geom_bar(stat="identity") 
#Stat = identity tells us to use the VALUE not the count

a

# 

# Really, only the height matters
a <- ggplot(temp, aes(x=IsItCold, y = AverageMaxSpeed)) +
  geom_point() +
  scale_y_continuous(limits = c(0,70))

a

# Emphasizing contrast
a <- ggplot(temp, aes(x=IsItCold, y = AverageMaxSpeed)) +
  geom_point() 

a
# add information

a + geom_errorbar(aes(ymax = AverageMaxSpeed+SE, ymin = AverageMaxSpeed-SE))#,position = "dodge")

## Okay, let's move into a formal exploration of two-variable plots.

###########################
# Two-variable plots      # 
###########################

# X: Is it cold? DISCRETE
# Y: Average max speed CONTINUOUS
# Go back to the full dataset)

a <- ggplot(CarData, aes(x=IsItCold, y=MaxSpeed_kmh)) +
  geom_boxplot()
a

# Boxplot with raw dots overlaid, with jitter

a <- ggplot(CarData, aes(x=IsItCold, y=MaxSpeed_kmh)) +
  geom_boxplot(outlier.colour="NA") + # Do not show outliers
  geom_jitter(width=0.2, alpha=0.6) #What happens if we use geom_point?

a

# Other variants

a <- ggplot(CarData, aes(x=IsItCold, y=MaxSpeed_kmh))

a + geom_violin()
a + geom_dotplot(binaxis="y", stackdir="center", dotsize=0.3)

#Base plot version

boxplot(MaxSpeed_kmh ~ IsItCold, data=CarData)

#########################################
# TWO VARIABLE CONTINUOUS VS CONTINUOUS #
#########################################


#Let's see if effiency is related to temperature
plot(TotalEConsumed_Lper100KMeq ~ AmbientTemperature_C, data=CarData)

#ggplot2 version
a <- ggplot(CarData, aes(y=TotalEConsumed_Lper100KMeq, x=AmbientTemperature_C))
a + geom_point()

#This is a continuous variable by a continuous variable. Default is a SCATTERPLOT

plot(TotalEConsumed_Lper100KMeq ~ TripDistance_KM, data=CarData)

plot(TotalEConsumed_Lper100KMeq ~ ElectricityConsumed_KWH, data=CarData)

#What if you want to compare several scatterplots?
pairs(~TotalEConsumed_Lper100KMeq+
        TripDistance_KM+
        AmbientTemperature_C+
        AverageSpeed_kmh, data=CarData)

