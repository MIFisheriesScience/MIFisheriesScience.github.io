# R Code for Week 5: Displaying Data Visually
# FISH 6002

# Started March 13, 2017
# Major revision, Sept 29, 2017
# Second major revision, 5 Oct, 2018

# This file loads all the packages and data necessary to conduct our first graphing lecture
# Please run this *entire script* first, before running the next script


######################
# LOAD PACKAGES      #
######################

#install.packages("lubridate") #Run if needed
#install.packages("tidyverse")
library(tidyverse)
library(lubridate)


#######################
# Load some data      #
#######################

# The dataset:
# My 2012 Chevrolet Volt plug-in hybrid has a tracker unit that records every trip the car takes
# Here, we have a subset of data from Aug 3, 2017, to Sept 29, 2017 of nearly every use of our car
# Each row of data is one observation - one TRIP taken where a trip starts when the car is turned on, 
# and stops when the car is turned off.

# The data included in the spreadsheet are as follows, and are as outputted directly by the tracker's software:

# Date: The date and time at which the trip took place
# Duration: The duration, in h:mm:ss of the trip
# TripDistance_KM: The total linear distance of the trip, in km
# FuelConsumed_L: The number of liters of gasoline consumed on the trap
# FuelConsumption_Lper100KM: The number of liters of gasoline consumed per 100 km on that trip
# ElectricityConsumed_KWH: The number of kilowatt-hours of electricity consumed on that trip
# TotalEConsumed_Lper100KMeq: The liters per 100 km-equivalent of energy consumed, as calculated by the tracker
# StartSOC: State of Charge at the start of the trip, expressed as a % of total battery capacity
# EndSOC: State of Charge at the end of the trip, expressed as a % of total battery capacity
# AmbientTemperature_C: The average air temperature during the trip
# AverageSpeed_kmh: Mean speed during the trip
# MaxSpeed_kmh: Maximum speed achieved during the trip
# AuxiliaryLoad_KWH: The number of kilowatt-hours of electricity used to power the car's auxillary systems (e.g. heating)
# HardAccel_Percent: Percentage of all acceleration on the trip classified as "hard" (i.e. accelerating quickly)	
# HardBraking_Percent: Percentage of all braking on the trip classified as "hard" (i.e. braking intensely)
# TimeIdle_Percent: Percentage of time on that trip spent idling (i.e. not making forward progress)

CarData <- read.csv("./data/BrettsCar_PartialDataset.csv")

head(CarData) #Did it load?

sapply(CarData, class) #Are the data types right?
# could also do str(CarData)

# A few problems here:
# First, mixed characters in TimeIdle_Percent

plot(TimeIdle_Percent ~ TripDistance_KM, data=CarData) 
# oh no!

# Need to get rid of the percent sign.
# Can we just turn it into a number?

temp <- as.numeric(CarData$TimeIdle_Percent)

head(temp)
head(CarData$TimeIdle_Percent)

# Didn't work. What's going on?
# Have a look at the first value of "temp" which is now 18. Why is it 18?

# It's 18 because when we loaded the data, TimeIdle_Percent was a FACTOR
# FACTORS have LEVELS
# When you apply as.numeric to a FACTOR, it returns that factor's LEVEL

levels(CarData$TimeIdle_Percent)[18]
# Since "24%" was the 18th LEVEL, R returns 18

# To make changes to the factor you need to do a bit more work:
# Can use the sub() function 

sub("%", "", CarData$TimeIdle_Percent)
# Note that sub() COERCES the factor into a "character"

is.character(CarData$TimeIdle_Percent)
is.character(sub("%", "", CarData$TimeIdle_Percent))

# SUBSTITUTION CODE

CarData$TimeIdle_Percent <- sub("%", "", CarData$TimeIdle_Percent)
# 1. SUBSTITUTE all instances of the "%" character, with nothing (as expressed by "")*
# 2. Assign the output of this function into TimeIdle_Percent, thereby overwriting its previous value
# * Note again, that sub() COERCES the factor into a character. 

CarData$TimeIdle_Percent <- as.numeric(CarData$TimeIdle_Percent)

# 1. Convert CarData$TimeIdle_Percent (which is currently a character) into a NUMERIC VALUE
# 2. Assign the output of this function into TimeIdle_Percent, thereby overwriting its previous value

# You also could have done this with one line:

# CarData$TimeIdle_Percent <- as.numeric(
#                                     sub("%", "", CarData$TimeIdle_Percent)
#                                     )



head(CarData$TimeIdle_Percent) #phew
class(CarData$TimeIdle_Percent)

plot(TimeIdle_Percent ~ TripDistance_KM, data=CarData) 


# Second, there are missing values in TotalEConsumed_Lper100KMeq. Let's just leave that alone for now

# Third, Date and Duration are both factors. What happens when we try to plot date vs. temperature, for example?

plot(AmbientTemperature_C ~ Date, data=CarData) 
# Yuck

# This is a very common problem. Fix with the lubridate package:


#Lubridate converts date and time items into usable data types in R

head(CarData$Date)


#Here we see that our dates are expressed as Month, Day, Year, followed by Hour, Minute, Second.

#Convert it to a Lubridate object as follows:
CarData$Date <- mdy_hms(CarData$Date, tz="America/St_Johns")

# Lubridate is smart enough to interpret September, Sept, or 08 all as the eighth month of the year.
# Furthermore, by setting the time zone (tz) it retains the correct time zone (data were collected here in St. John's)
# If you needed to convert to another time zone, you could do so by going with_tz(VARIABLE, tz = "OTHER TIMEZONE")
# To see all locales, type OlsonNames()

#Let's see what R says the data type is now: 
class(CarData$Date) 
CarData$Date

plot(AmbientTemperature_C ~ Date, data=CarData) #Much better!
# Now it's treating the date and time like an actual continuous variable.

# You can do a LOT with the data in this format: https://rpubs.com/davoodastaraky/lubridate

# It's an even bigger problem with dateless durations:

plot(ElectricityConsumed_KWH ~ Duration, data=CarData) 

# It's treating each individual duration as a factor. When there is more than one occurence at a specific
# duration it makes a little boxplot :(

# Let's fix it
CarData$Duration <- hms(CarData$Duration)
CarData$Duration

plot(ElectricityConsumed_KWH ~ Duration, data=CarData) #wee much better!
# Lubridate was great because it interpreted a weird text format correctly for us
# But mathematically it would be nice to just deal in seconds
# So let's convert it from a Lubridate item to a standard numeric value:

CarData$Duration <- as.numeric(CarData$Duration)

head(CarData$Duration)
# Each value is now the number of seconds the car was operating for.
# This enables easy calculation of the duration in minutes and hours:

CarData <- CarData %>%
    mutate(DurationM = Duration/60) %>%
    mutate(DurationH = Duration/3600) 


# Recall that 'mutate' ADDS a new variable and populates it as specified
 #Note use of pipes to build two variables as above

plot(ElectricityConsumed_KWH ~ DurationM, data=CarData) # Minutes
plot(ElectricityConsumed_KWH ~ DurationH, data=CarData) # Hours

sapply(CarData, class) #Are the data types right?

# Let's add one more variable, which we will use later

CarData <- CarData %>%
  mutate(IsItCold = ifelse(AmbientTemperature_C <= 11, "Cold", "Not cold"))

#IsItCold: It's cold if it's less than or equal to 11 C, otherwise not cold.       


