#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

# Define UI for application that draws a scatterplot
ui <- fluidPage(
   
   # Application title
   titlePanel("Minimal Example"),
   
   # Sidebar with a slider input for x range
   sidebarLayout(
      sidebarPanel(
         sliderInput("plotrange",
                     "Maximum X value:",
                     min = 1,
                     max = 100,
                     value = 50)
      ),
      
      # Create a plot for the XY data
      mainPanel(
         plotOutput("xyPlot")
      )
   )
)

# Define server logic required to draw a scatterplot with a simple linear model
server <- function(input, output) {

library(tidyverse)  
    
MinimalExample <- read.csv("../Data/MinimalExample.csv")

   output$xyPlot <- renderPlot({
      
      datasubset <- MinimalExample %>%
          filter(X <= input$plotrange)
        
      model <- lm(Y~X, data=datasubset)
      
      plot(Y~X, data=datasubset)
      abline(model)
   })
}

# Run the application 
shinyApp(ui = ui, server = server)

