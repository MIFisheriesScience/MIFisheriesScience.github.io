# FISH 6003: Major Assignment Data Exploration

# Note: 001_DataSetup.R must be run prior to this script.

# Visualize experiment

# Conduct data exploration:

#############################
# 1. Outliers, Y and X      #
#############################




################################
# 2. Homogeneity of variance Y #
################################





##############################
# 3. Normality  Y            #
##############################




##############################
# 4. Zero inflation Y        #
##############################

 


################################
# 5. Collinearity X            #
################################




#################################
# 6. Relationships Y and X      #
#################################




#################################
# 7. Interactions               #
#################################





#################################
# 8. Independence Y             #
#################################






# RECAP:

# Re-state what you found, and what decisions you made

# 1. Outliers Y and X: 
# 2. Homogeneity Y: 
# 3. Normality Y: 
# 4. Zero trouble Y: 
# 5. Collinearity X:
# 6. Relationships Y and X: 
# 7. Interactions: 
# 8. Independence Y: 
