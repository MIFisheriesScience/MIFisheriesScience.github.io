# FISH 6003: Major Assignment Data Setup

# YOUR NAME HERE

library(tidyverse)

source("./R/6003Functions.R")

# Load the data file
# It is not tidied, aside from it being saved as a CSV

mydata <- read.csv("./data/YOURFILE.csv") 

# DESCRIBE THE VARIABLES

# What does the dataset contain?

#####################
# Clean the data    #
#####################

mydata_untidy <- mydata #If ever need to go back to original dataset we can

# Did it load correctly?
# - Look for extra columns or rows

# Are data types what they should be?
# - Look for numbers that are factors, etc.

# Are there impossible values (numbers) 
# - Check each numerical value one by one

# Are there incorrect factor levels? (factors?)
# - Check levels of all factors one by one

# In all cases, make appropriate decision as you go through. 

# Data verification complete. Move on to exploration

