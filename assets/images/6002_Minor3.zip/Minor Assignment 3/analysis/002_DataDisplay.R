
# FISH 6002: Minor Assignment 3
# Developed by Brett Favaro, 4 Nov 2019

# MUST RUN 001_DataSetup.R FIRST

###################################################
# Data are from: 
# http://derekogle.com/fishR/data/data-html/AfricanRivers.html
# obtained 4 Nov 2019

#A data frame of 39 observations on the following 6 variables:

#  river: name of the river.
#richness: fish species richness.
#surface: surface area in km^2.
#disch: mean annual discharge in \frac{m^3}{s}.
#vegdiv: terrestrial vegetation diversity (Shannon's diversity index of vegetation in drainage).
#forperc: percentage of drainage area covered by lowland rain forest.

##########################
# TASK                   #
###########################

# MAKE A PLOT with base plot or GGPLot that:

# Is an appropriate type of TWO-VARIABLE PLOT
# - where the type is appropriate to the data 
# Uses colours and/or multipanel (either different plots, or a faceted plot)
# Is publication-quality

a <- ggplot(data = rivers, aes(x = ,
                               y =))
# Consider:
# col = 
# shape =
# size =

ggsave("./plots/LASTNAME_Figure.tiff", # save in the /plots subfolder
       dpi=300, #300 DPI
       width = WIDTH, height = HEIGHT, #SELECT WIDTH AND HEIGHT
       device = "tiff", #export as tiff
       compression = "lzw",
       units = "SELECT A UNIT")

# Use the PACE system to turn this TIFF into a PDF.

# Save the PDF outputted by PACE and upload that PDF to Teams

# Also, write a figure caption as a text document and upload that.