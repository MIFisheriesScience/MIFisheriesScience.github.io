# 6002: Minor Assignment 3- Data prep
# Brett Favaro
# Nov 4, 2019

library(tidyverse)
library(lubridate)
library(RColorBrewer)
library(dichromat)
library(png)
library(ggrepel)

rivers <- read.csv("./data/AfricanRivers.csv")

# FUNCTION - MUST RUN

multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  library(grid)
  
  plots <- c(list(...), plotlist)
  
  numPlots = length(plots)
  
  if (is.null(layout)) {
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                     ncol = cols, nrow = ceiling(numPlots/cols))
  }
  
  if (numPlots==1) {
    print(plots[[1]])
    
  } else {
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))
    
    for (i in 1:numPlots) {
      
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))
      
      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}

###################################################
# Data are from: 
# http://derekogle.com/fishR/data/data-html/AfricanRivers.html
# obtained 4 Nov 2019

#A data frame of 39 observations on the following 6 variables:
  
#  river: name of the river.
#richness: fish species richness.
#surface: surface area in km^2.
#disch: mean annual discharge in \frac{m^3}{s}.
#vegdiv: terrestrial vegetation diversity (Shannon's diversity index of vegetation in drainage).
#forperc: percentage of drainage area covered by lowland rain forest.

# NO MODIFICATIONS MADE AS A RESULT OF DATA EXPLORATION

# 1. Did it load?

head(rivers)
tail(rivers)

# 2. Check data types

sapply(rivers, class)

# 3. Check for missing or impossible values 

plot(rivers$richness)
plot(rivers$surface)
plot(rivers$disch) 
plot(rivers$vegdiv) 
plot(rivers$forperc) 

# 4. Check for typos and broken factors 

levels(rivers$river) # seems fine
 
